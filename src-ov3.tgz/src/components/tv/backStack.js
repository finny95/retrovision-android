import { createContext, useContext, useEffect, useRef } from "react";

// "Back" (controller B, Escape, Android back) is offered to the newest handler
// first: an open picker, then a sub-screen (channel editor, show page), then
// the menu itself.
export function createBackStack() {
  const stack = [];
  return {
    push(fn) {
      stack.push(fn);
      return () => {
        const i = stack.lastIndexOf(fn);
        if (i >= 0) stack.splice(i, 1);
      };
    },
    run() {
      for (let i = stack.length - 1; i >= 0; i--) if (stack[i]()) return true;
      return false;
    },
  };
}

export const BackStackContext = createContext(null);

// Registers fn while `active`. fn returns true when it handled Back.
export function useBackHandler(fn, active = true) {
  const stack = useContext(BackStackContext);
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    if (!active || !stack) return undefined;
    return stack.push(() => ref.current());
  }, [active, stack]);
}
