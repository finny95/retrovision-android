import React, { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { Check, X } from "lucide-react";
import { useBackHandler } from "@/components/tv/backStack";
import { focusEl } from "@/lib/spatialNav";

// Full-screen-ish pop-up list in the pay-TV style.
export function Modal({ title, subtitle, onClose, wide = false, actions, footer, top, children, bodyRef }) {
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-[#020a24]/80 p-3 backdrop-blur-[2px]" onClick={onClose}>
      <div
        data-nav-modal
        role="dialog"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        className={`ps-panel flex max-h-[92vh] w-full flex-col overflow-hidden ${wide ? "max-w-xl" : "max-w-md"}`}
      >
        <div className="ps-titlebar flex items-center gap-3 rounded-t-[13px] px-4 py-2.5">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold uppercase tracking-wide text-white">{title}</p>
            {subtitle && <p className="truncate text-[11px] text-[#d4e3ff]">{subtitle}</p>}
          </div>
          {actions}
          <button tabIndex={-1} onClick={onClose} className="rounded-full p-1 text-white/80 hover:text-white" aria-label="Close">
            <X size={16} />
          </button>
        </div>
        {top && <div className="shrink-0 px-2.5 pt-2.5">{top}</div>}
        <div ref={bodyRef} className="flex min-h-0 flex-col gap-1.5 overflow-y-auto overscroll-contain p-2.5">
          {children}
        </div>
        {footer && <div className="border-t border-[#2d5bb8] px-4 py-2 text-[10px] font-bold uppercase tracking-wider text-[#8fc4ff]">{footer}</div>}
      </div>
    </div>,
    document.body
  );
}

// Full list of choices for a setting, opened from a Cycler. Controller: Up/Down
// to move, A to choose, B to close.
export default function Picker({ title, options, value, onPick, onClose }) {
  const listRef = useRef(null);
  useBackHandler(() => {
    onClose();
    return true;
  });

  useEffect(() => {
    const el = listRef.current?.querySelector('[aria-selected="true"]') || listRef.current?.querySelector("button");
    focusEl(el);
  }, []);

  return (
    <Modal title={title} onClose={onClose} bodyRef={listRef} footer="A: choose · B: close">
      {options.map((o) => {
        const on = o.value === value;
        return (
          <button
            key={String(o.value)}
            role="option"
            aria-selected={on}
            data-on={on || undefined}
            onClick={() => onPick(o.value)}
            className="ps-row flex min-h-11 items-center justify-between gap-3 px-3 py-2 text-left text-sm"
          >
            <span className="ps-label truncate">{o.label}</span>
            {on && <Check size={15} className="shrink-0" />}
          </button>
        );
      })}
    </Modal>
  );
}

// Pick several (e.g. which shows a channel plays). A toggles, B or Done closes.
export function MultiPicker({ title, hint, options, values, onChange, onClose }) {
  const listRef = useRef(null);
  useBackHandler(() => {
    onClose();
    return true;
  });
  useEffect(() => {
    focusEl(listRef.current?.querySelector('[role="option"]') || listRef.current?.querySelector("button"));
  }, []);
  const toggle = (v) => onChange(values.includes(v) ? values.filter((x) => x !== v) : [...values, v]);

  return (
    <Modal
      title={`${title} · ${values.length} picked`}
      subtitle={hint}
      onClose={onClose}
      bodyRef={listRef}
      footer="A: pick / unpick · B: done"
      actions={
        <button tabIndex={-1} onClick={onClose} className="ps-btn-primary shrink-0 px-3 py-1 text-[11px] uppercase">
          Done
        </button>
      }
    >
      {options.length === 0 && <p className="p-4 text-center text-sm text-[#a9c3ee]">Nothing to pick yet. Add shows in Library first.</p>}
      {options.map((o) => {
        const on = values.includes(o.value);
        return (
          <button
            key={String(o.value)}
            role="option"
            aria-selected={on}
            data-on={on || undefined}
            onClick={() => toggle(o.value)}
            className="ps-row flex min-h-11 items-center gap-3 px-3 py-2 text-left text-sm"
          >
            <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border-2 ${on ? "border-white bg-[#0a1a40] text-[#ffd21f]" : "border-white/70"}`}>
              {on && <Check size={13} strokeWidth={3} />}
            </span>
            <span className="min-w-0 flex-1">
              <span className="ps-label block truncate">{o.label}</span>
              {o.hint && <span className="ps-hint block truncate text-[11px]">{o.hint}</span>}
            </span>
          </button>
        );
      })}
    </Modal>
  );
}
