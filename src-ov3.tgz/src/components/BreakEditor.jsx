import React, { useEffect, useRef, useState } from "react";
import { Play, Pause, Rewind, FastForward, Plus, Minus, X, Scissors } from "lucide-react";
import { Modal } from "@/components/tv/Picker";
import { useBackHandler } from "@/components/tv/backStack";
import { SectionLabel, Stepper, ConfirmButton } from "@/components/tv/controls";
import { getPlayable } from "@/lib/linkedFolder";
import { evenBreaks } from "@/lib/episodeMeta";
import { focusEl, refocus } from "@/lib/spatialNav";
import { formatClock } from "@/lib/schedule";

const iconBtn = "ps-btn flex h-10 min-w-10 items-center justify-center gap-1 px-2 text-xs";

// Mark where an episode's ad breaks go. Play or scrub the episode, then "Add
// break here". Saved straight away, per episode; channels play ads at each mark.
export default function BreakEditor({ record, seasonFiles, onSave, onClose }) {
  const videoRef = useRef(null);
  const bodyRef = useRef(null);
  const [src, setSrc] = useState(null);
  const [failed, setFailed] = useState(false);
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [list, setList] = useState(() => (record.manualBreaks ? [...record.breaks] : []));
  const [spread, setSpread] = useState(2);
  const duration = record.duration || 0;

  useBackHandler(() => {
    onClose();
    return true;
  });
  // The TV keeps playing behind; quiet it while previewing (see Home).
  useEffect(() => {
    window.dispatchEvent(new CustomEvent("rv-preview", { detail: true }));
    return () => window.dispatchEvent(new CustomEvent("rv-preview", { detail: false }));
  }, []);

  useEffect(() => {
    let url = null;
    let alive = true;
    getPlayable(record).then((p) => {
      if (!alive) return;
      if (!p) return setFailed(true);
      url = typeof p === "string" ? null : URL.createObjectURL(p);
      setSrc(url || p);
    });
    requestAnimationFrame(() => focusEl(bodyRef.current?.querySelector("[data-break-add]")));
    return () => {
      alive = false;
      if (url) URL.revokeObjectURL(url);
    };
  }, [record]);

  const save = (next) => {
    const tidy = [...new Set(next.map((s) => Math.round(s)))].filter((s) => s > 5 && s < duration - 5).sort((a, b) => a - b);
    setList(tidy);
    onSave(record, tidy);
  };
  const seek = (s) => {
    const v = videoRef.current;
    const to = Math.max(0, Math.min(duration - 0.5, s));
    if (v) v.currentTime = to;
    setT(to);
  };
  const toggle = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play().catch(() => {});
    else v.pause();
  };
  const nudge = (i, d) => {
    const next = [...list];
    next[i] = Math.max(6, Math.min(duration - 6, next[i] + d));
    save(next);
    seek(next[i]);
  };
  const remove = (i) => {
    save(list.filter((_, k) => k !== i));
    refocus(`[data-break-row="${Math.min(i, list.length - 2)}"] [data-act="go"]`, "[data-break-add]");
  };

  const pct = duration ? (t / duration) * 100 : 0;
  const preview = (
      <div className="ps-inset relative overflow-hidden">
        {src ? (
          <video
            ref={videoRef}
            src={src}
            playsInline
            preload="metadata"
            className="aspect-video max-h-[30vh] w-full bg-black object-contain"
            onTimeUpdate={(e) => setT(e.currentTarget.currentTime)}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            onError={() => setFailed(true)}
          />
        ) : (
          <div className="flex aspect-video max-h-[30vh] w-full items-center justify-center text-xs text-[#a9c3ee]">{failed ? "Can't open this file" : "Loading…"}</div>
        )}
        {/* Break marks on a mini timeline */}
        <div className="relative h-2 bg-black/60">
          <div className="absolute inset-y-0 left-0 bg-[#ffd21f]/70" style={{ width: `${pct}%` }} />
          {list.map((b) => (
            <span key={b} className="absolute top-[-3px] h-[14px] w-[3px] bg-[#e2231a]" style={{ left: `${(b / duration) * 100}%` }} />
          ))}
        </div>
      </div>
  );
  const name = String(record.name || "").replace(/\.[a-z0-9]{2,4}$/i, "");

  return (
    <Modal
      wide
      title={`Breaks · ${name}`}
      subtitle={[record.show, record.season].filter(Boolean).join(" · ")}
      onClose={onClose}
      bodyRef={bodyRef}
      footer="Breaks play ads from the channel's ad folders · B: done"
      top={preview}
    >
      <div className="flex items-center justify-between gap-1">
        <button onClick={() => seek(t - 30)} className={iconBtn} aria-label="Back 30 seconds"><Rewind size={14} />30</button>
        <button onClick={() => seek(t - 5)} className={iconBtn} aria-label="Back 5 seconds"><Rewind size={14} />5</button>
        <button onClick={toggle} className={`${iconBtn} min-w-14`} aria-label={playing ? "Pause" : "Play"}>{playing ? <Pause size={16} /> : <Play size={16} />}</button>
        <button onClick={() => seek(t + 5)} className={iconBtn} aria-label="Forward 5 seconds">5<FastForward size={14} /></button>
        <button onClick={() => seek(t + 30)} className={iconBtn} aria-label="Forward 30 seconds">30<FastForward size={14} /></button>
      </div>
      <label className="ps-row flex flex-col gap-1.5 px-3 py-2.5">
        <span className="flex items-center justify-between">
          <span className="ps-label text-sm">Position</span>
          <span className="ps-num text-xs">{formatClock(t)} / {formatClock(duration)}</span>
        </span>
        <input type="range" min={0} max={Math.max(1, Math.floor(duration))} step={1} value={Math.floor(t)} onChange={(e) => seek(Number(e.target.value))} aria-label="Position" className="tv-range w-full" style={{ "--pct": `${pct}%` }} />
      </label>
      <button data-break-add onClick={() => save([...list, t])} disabled={!duration} className="ps-btn-primary flex min-h-11 items-center justify-center gap-2 text-sm">
        <Scissors size={15} /> Add break at {formatClock(t)}
      </button>

      <SectionLabel hint={!list.length && record.breaks?.length ? `Using the show's automatic breaks (${record.breaks.map(formatClock).join(", ")}) until you add your own.` : undefined}>
        Breaks · {list.length}
      </SectionLabel>
      {list.map((b, i) => (
        <div key={b} data-break-row={i} className="flex items-stretch gap-1.5">
          <button data-act="go" onClick={() => seek(b)} className="ps-row flex min-h-11 flex-1 items-center gap-2 px-3 text-left">
            <span className="ps-label text-sm">Break {i + 1}</span>
            <span className="ps-value ml-auto text-sm tabular-nums">{formatClock(b)}</span>
          </button>
          <button onClick={() => nudge(i, -5)} className={iconBtn} aria-label={`Break ${i + 1} 5 seconds earlier`}><Minus size={13} />5s</button>
          <button onClick={() => nudge(i, 5)} className={iconBtn} aria-label={`Break ${i + 1} 5 seconds later`}><Plus size={13} />5s</button>
          <button data-act="remove" onClick={() => remove(i)} className={iconBtn} aria-label={`Remove break ${i + 1}`}><X size={14} /></button>
        </div>
      ))}

      <SectionLabel>Quick fill</SectionLabel>
      <Stepper label="Breaks to spread evenly" value={spread} min={1} max={6} onChange={setSpread} />
      <button onClick={() => save(evenBreaks(duration, spread))} disabled={!duration} className="ps-btn flex min-h-10 items-center justify-center text-sm">
        Spread {spread} {spread === 1 ? "break" : "breaks"} evenly
      </button>
      {seasonFiles?.length > 1 && (
        <ConfirmButton
          label={`Use these times for all of ${record.season || "this show"}`}
          confirmLabel={`Press again: ${seasonFiles.length} episodes`}
          onConfirm={() => onSave(seasonFiles, list)}
          className="ps-btn flex min-h-10 items-center justify-center px-3 text-sm"
        />
      )}
      {list.length > 0 && (
        <ConfirmButton label="Clear breaks" confirmLabel="Press again to clear" onConfirm={() => save([])} className="ps-btn flex min-h-10 items-center justify-center text-sm" />
      )}
    </Modal>
  );
}
