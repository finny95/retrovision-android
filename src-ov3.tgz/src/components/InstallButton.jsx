import React, { useSyncExternalStore } from "react";
import { Download, Loader2 } from "lucide-react";
import { getInstallSnapshot, subscribeInstall, requestInstall } from "@/components/installation/installPrompt";

export default function InstallButton({ panel = false }) {
  const { installed, pending, message } = useSyncExternalStore(subscribeInstall, getInstallSnapshot);
  if (installed) return null;

  return (
    <div className={`flex flex-col gap-2 ${panel ? "items-start" : "items-end"}`}>
      <button
        onClick={requestInstall}
        disabled={pending}
        className="ps-btn flex min-h-10 items-center gap-2 px-3 text-xs uppercase disabled:opacity-50"
      >
        {pending ? <Loader2 size={13} className="animate-spin" /> : <Download size={13} />}
        {pending ? "Opening…" : "Install app"}
      </button>
      {message && (
        <p role="status" className={`max-w-xs font-mono text-xs leading-relaxed text-neutral-400 ${panel ? "text-left" : "text-right"}`}>
          {message}
        </p>
      )}
    </div>
  );
}