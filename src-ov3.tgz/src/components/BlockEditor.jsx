import React, { memo, useMemo } from "react";
import { ArrowUp, ArrowDown, X, Plus, Dices, Megaphone } from "lucide-react";
import { showSeasons, blockPool } from "@/lib/schedule";
import { Cycler, SectionLabel } from "@/components/tv/controls";
import { refocus } from "@/lib/spatialNav";

const iconBtn = "ps-btn flex h-9 w-9 items-center justify-center !rounded-lg disabled:opacity-25";

// One block per card. Show and season each get their own full-width row, so
// Left/Right changes them and Up/Down always moves on (never sideways traps).
function BlockEditor({ blocks, shows, media, onChange }) {
  const showOptions = useMemo(() => shows.map((s) => ({ value: s, label: s })), [shows]);
  const set = (i, patch) => onChange(blocks.map((b, k) => (k === i ? { ...b, ...patch } : b)));
  const remove = (i) => {
    onChange(blocks.filter((_, k) => k !== i));
    refocus(`[data-block="${Math.min(i, blocks.length - 2)}"] [data-act="remove"]`, "[data-add-block]");
  };
  const move = (i, dir) => {
    const j = i + dir;
    if (j < 0 || j >= blocks.length) return;
    const next = [...blocks];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
    refocus(`[data-block="${j}"] [data-act="${dir < 0 ? "up" : "down"}"]`);
  };
  const add = (kind) => onChange([...blocks, { show: shows[0] || "", season: "", kind }]);

  return (
    <div className="flex flex-col gap-2">
      <SectionLabel hint="Blocks play top to bottom, then repeat. Each block airs a random episode from its show, a different one every pass.">
        Blocks · {blocks.length}
      </SectionLabel>

      {blocks.length === 0 && (
        <p className="ps-inset p-3 text-center text-xs text-[#a9c3ee]">No blocks yet. Add one below.</p>
      )}

      {blocks.map((b, i) => {
        const seasons = showSeasons(media, b.show);
        const count = blockPool(b, media).length;
        const ad = b.kind === "ad";
        return (
          <div key={i} data-block={i} className="ps-inset flex flex-col gap-1.5 p-2">
            <div className="flex items-center gap-2 px-1">
              <span className="text-xs font-bold text-[#ffd21f]">{i + 1}</span>
              {ad ? <Megaphone size={13} className="text-sky-300" /> : <Dices size={13} className="text-[#ffd21f]" />}
              <span className="flex-1 truncate text-[11px] text-[#a9c3ee]">
                {ad ? "Ad block" : "Show block"} · {count} {count === 1 ? "file" : "files"}
              </span>
              <button data-act="up" onClick={() => move(i, -1)} disabled={i === 0} className={iconBtn} aria-label={`Move block ${i + 1} up`}>
                <ArrowUp size={15} />
              </button>
              <button data-act="down" onClick={() => move(i, 1)} disabled={i === blocks.length - 1} className={iconBtn} aria-label={`Move block ${i + 1} down`}>
                <ArrowDown size={15} />
              </button>
              <button data-act="remove" onClick={() => remove(i)} className={iconBtn} aria-label={`Remove block ${i + 1}`}>
                <X size={15} />
              </button>
            </div>
            <Cycler label={ad ? "Ad folder" : "Show"} value={b.show} options={showOptions} onChange={(v) => set(i, { show: v, season: "" })} />
            <Cycler
              label="Season"
              value={b.season}
              options={[{ value: "", label: "Any season" }, ...seasons.map((s) => ({ value: s, label: s }))]}
              onChange={(v) => set(i, { season: v })}
            />
          </div>
        );
      })}

      <div className="grid grid-cols-2 gap-2">
        <button
          data-add-block
          onClick={() => add("show")}
          disabled={!shows.length}
          className="ps-btn flex min-h-11 items-center justify-center gap-1.5 px-3 text-sm"
        >
          <Plus size={14} /> Show block
        </button>
        <button
          onClick={() => add("ad")}
          disabled={!shows.length}
          className="ps-btn flex min-h-11 items-center justify-center gap-1.5 px-3 text-sm"
        >
          <Plus size={14} /> Ad block
        </button>
      </div>
    </div>
  );
}

// Skips redrawing every block while you type the channel name.
export default memo(BlockEditor);
