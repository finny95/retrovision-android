import React, { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { guideTimeline, programmeTitle, formatTimeOfDay } from "@/lib/schedule";
import { useNow } from "@/components/menu/ChannelsTab";
import { focusEl } from "@/lib/spatialNav";

const SLOT = 30 * 60 * 1000;
const pad2 = (n) => String(n).padStart(2, "0");
const episodeLine = (m) => (m ? [m.season, String(m.name || "").replace(/\.[a-z0-9]{2,4}$/i, "")].filter(Boolean).join(" · ") : "");

// The TV guide: channels down the side, half-hour slots across, what's on in
// each. Up/Down changes channel row, Left/Right moves through programmes and
// pages the time window at the edges. A tunes to that channel.
export default function GuideTab({ channels, media, activeId, onTune, pig = false, wide = false }) {
  const now = useNow(30000);
  const [page, setPage] = useState(0);
  const [focused, setFocused] = useState(null); // { channel, prog }
  const gridRef = useRef(null);
  const pendingFocus = useRef(null);
  const slots = wide ? 4 : 3;
  const start = Math.floor(now / SLOT) * SLOT + page * SLOT;
  const end = start + slots * SLOT;
  const span = end - start;

  const rows = useMemo(
    () => channels.map((c) => ({ c, progs: guideTimeline(c, media, start, end).filter((p) => p.endMs > start) })),
    [channels, media, start, end]
  );

  // Page the window when Left/Right runs off the edge of the grid.
  useEffect(() => {
    const el = gridRef.current;
    const onEdge = (e) => {
      const row = document.activeElement?.closest?.("[data-guide-row]")?.dataset.guideRow;
      if (e.detail === "right" && page < 24) {
        pendingFocus.current = { row, at: "first" };
        setPage((p) => p + 1);
      } else if (e.detail === "left" && page > 0) {
        pendingFocus.current = { row, at: "last" };
        setPage((p) => p - 1);
      }
    };
    el?.addEventListener("nav-edge", onEdge);
    return () => el?.removeEventListener("nav-edge", onEdge);
  }, [page]);

  useEffect(() => {
    const want = pendingFocus.current;
    if (!want) return;
    pendingFocus.current = null;
    requestAnimationFrame(() => {
      const cells = gridRef.current?.querySelectorAll(`[data-guide-row="${want.row}"] [data-prog]`);
      if (cells?.length) focusEl(want.at === "first" ? cells[0] : cells[cells.length - 1]);
    });
  }, [start]);

  const info = focused || (() => {
    const r = rows.find((x) => x.c.id === activeId) || rows[0];
    const p = r?.progs.find((x) => x.startMs <= now && now < x.endMs) || r?.progs[0];
    return r && p ? { channel: r.c, prog: p } : null;
  })();
  const live = info && info.prog.startMs <= now && now < info.prog.endMs;

  return (
    <div className="flex flex-col gap-2">
      <div className="flex gap-3">
        <div className={`ps-inset flex min-w-0 flex-1 flex-col justify-center gap-1 px-3 py-2 ${pig ? "min-h-[22.5vw]" : "min-h-[5.5rem]"}`}>
          {info ? (
            <>
              <p className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-[#8fc4ff]">
                <span className="ps-btn-primary px-1.5 text-xs">{pad2(info.channel.number)}</span>
                <span className="truncate">{info.channel.name}</span>
                {live && <span className="rounded bg-[#e2231a] px-1.5 py-px text-[9px] text-white">On now</span>}
              </p>
              <p className="truncate text-lg font-bold leading-tight text-white">{programmeTitle(info.prog)}</p>
              <p className="text-xs font-bold text-[#ffe14d]">
                {formatTimeOfDay(info.prog.startMs)} - {formatTimeOfDay(info.prog.endMs)}
              </p>
              {info.prog.media && <p className="truncate text-xs text-[#a9c3ee]">{episodeLine(info.prog.media)}</p>}
            </>
          ) : (
            <p className="text-sm text-[#a9c3ee]">No channels yet. Make one in Channels.</p>
          )}
        </div>
        {pig && <div data-pig-slot className="aspect-video w-[40vw] shrink-0 rounded-lg border-2 border-[#4a7bd4] bg-black shadow-[inset_0_0_0_1px_rgba(0,0,0,0.6)]" />}
      </div>

      {/* Time header */}
      <div className="flex items-stretch gap-1">
        <div className="ps-titlebar flex w-24 shrink-0 items-center justify-center rounded-md text-[11px] font-bold uppercase text-white">
          {new Date(start).toLocaleDateString(undefined, { weekday: "short", day: "numeric" })}
        </div>
        <div className="ps-titlebar relative flex flex-1 overflow-hidden rounded-md">
          {Array.from({ length: slots }, (_, k) => (
            <span key={k} className="flex-1 border-l border-[#0a1f55] px-1.5 py-1 text-[11px] font-bold text-white first:border-l-0">
              {formatTimeOfDay(start + k * SLOT)}
            </span>
          ))}
          {page > 0 && <ChevronLeft size={14} className="absolute left-0 top-1/2 -translate-y-1/2 text-[#ffd21f]" />}
          <ChevronRight size={14} className="absolute right-0 top-1/2 -translate-y-1/2 text-[#ffd21f]" />
        </div>
      </div>

      <div ref={gridRef} className="flex flex-col gap-1">
        {rows.length === 0 && <p className="ps-inset p-3 text-center text-xs text-[#a9c3ee]">The guide fills in once you have channels.</p>}
        {rows.map(({ c, progs }) => (
          <div key={c.id} data-guide-row={c.id} data-nav-row className="flex items-stretch gap-1">
            <div className={`ps-inset flex w-24 shrink-0 items-center gap-1.5 px-1.5 ${c.id === activeId ? "!border-[#ffd21f]" : ""}`}>
              <span className="text-sm font-bold tabular-nums text-[#ffe14d]">{pad2(c.number)}</span>
              <span className="min-w-0 truncate text-[11px] font-bold text-white">{c.name}</span>
            </div>
            <div className="relative h-12 flex-1 overflow-hidden rounded-md bg-[#061436]">
              {progs.length === 0 && <span className="absolute inset-0 flex items-center px-2 text-[11px] text-[#6f8cc4]">No programmes</span>}
              {progs.map((p) => {
                const left = (Math.max(p.startMs, start) - start) / span;
                const right = (Math.min(p.endMs, end) - start) / span;
                const isNow = p.startMs <= now && now < p.endMs;
                return (
                  <button
                    key={p.startMs}
                    data-prog
                    data-on={isNow || undefined}
                    data-nav-default={(isNow && (c.id === activeId || (!activeId && c === rows[0].c))) || undefined}
                    onFocus={() => setFocused({ channel: c, prog: p })}
                    onClick={() => onTune(c)}
                    className="ps-row absolute inset-y-0 flex min-w-0 flex-col justify-center overflow-hidden !rounded-md px-1.5 text-left"
                    style={{ left: `${left * 100}%`, width: `calc(${(right - left) * 100}% - 2px)` }}
                    aria-label={`${c.name}: ${programmeTitle(p)} at ${formatTimeOfDay(p.startMs)}`}
                  >
                    <span className="ps-label truncate text-xs leading-tight">{programmeTitle(p)}</span>
                    <span className="ps-hint truncate text-[10px] leading-tight">{formatTimeOfDay(p.startMs)}</span>
                  </button>
                );
              })}
              {now >= start && now < end && (
                <span className="pointer-events-none absolute inset-y-0 w-0.5 bg-[#e2231a] shadow-[0_0_6px_#e2231a]" style={{ left: `${((now - start) / span) * 100}%` }} />
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
