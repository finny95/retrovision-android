import React, { memo } from "react";
import { RotateCcw } from "lucide-react";
import { Cycler, SliderRow, Stepper, Toggle, SectionLabel, ConfirmButton } from "@/components/tv/controls";
import { BROADCAST_DEFAULTS } from "@/lib/prefs";

const CORNERS = [
  { value: "tl", label: "Top left" },
  { value: "tr", label: "Top right" },
  { value: "bl", label: "Bottom left" },
  { value: "br", label: "Bottom right" },
];
const CARD = [
  { value: "off", label: "Off" },
  { value: "m", label: "M and above" },
  { value: "all", label: "All rated shows" },
];
const STRIP = [10, 20, 30, 45, 60].map((s) => ({ value: s, label: `Last ${s}s` }));
const secs = (v) => `${v}s`;

// Everything that makes a channel feel like early-2000s pay TV, in one place.
function BroadcastTab({ settings, onChange }) {
  const set = (patch) => onChange({ ...settings, ...patch });
  return (
    <div className="flex flex-col gap-2">
      <SectionLabel hint="What airs between one show and the next">Between shows</SectionLabel>
      <Toggle label="Coming up next" hint="Card with the next show and what follows" checked={settings.upNext} onChange={(v) => set({ upNext: v })} />
      {settings.upNext && <Stepper label="Coming up next length" value={settings.upNextSecs} min={3} max={15} onChange={(v) => set({ upNextSecs: v })} format={secs} />}
      <Toggle label="Channel ident" hint="Short animated channel logo before it" checked={settings.ident} onChange={(v) => set({ ident: v })} />
      {settings.ident && <Stepper label="Ident length" value={settings.identSecs} min={2} max={10} onChange={(v) => set({ identSecs: v })} format={secs} />}
      <Cycler label="Classification card" hint="Set a show's rating in Library" value={settings.ratingCard} options={CARD} onChange={(v) => set({ ratingCard: v })} />
      {settings.ratingCard !== "off" && <Stepper label="Card length" value={settings.ratingCardSecs} min={3} max={10} onChange={(v) => set({ ratingCardSecs: v })} format={secs} />}

      <SectionLabel hint="Mark breaks per episode in Library (open a show, then Breaks), or give a show automatic breaks. Channels play their ad folders in each break.">
        Ad breaks
      </SectionLabel>
      <Toggle label="We'll be right back" hint="Cards before and after each break" checked={settings.breakBumpers} onChange={(v) => set({ breakBumpers: v })} />
      {settings.breakBumpers && <Stepper label="Card length" value={settings.breakBumperSecs} min={2} max={8} onChange={(v) => set({ breakBumperSecs: v })} format={secs} />}

      <SectionLabel>On screen</SectionLabel>
      <Toggle label="Channel logo" hint="Watermark in the corner during shows" checked={settings.dog} onChange={(v) => set({ dog: v })} />
      {settings.dog && (
        <>
          <Cycler label="Logo corner" value={settings.dogCorner} options={CORNERS} onChange={(v) => set({ dogCorner: v })} />
          <SliderRow label="Logo strength" value={settings.dogOpacity} min={0.2} max={1} step={0.05} display={`${Math.round(settings.dogOpacity * 100)}%`} onChange={(v) => set({ dogOpacity: v })} />
        </>
      )}
      <Toggle label="Classification in corner" hint="As each episode starts" checked={settings.ratingBug} onChange={(v) => set({ ratingBug: v })} />
      {settings.ratingBug && <Stepper label="Shown for" value={settings.ratingBugSecs} min={3} max={30} onChange={(v) => set({ ratingBugSecs: v })} format={secs} />}
      <Toggle label="Next strip" hint="'Next:' banner near the end of an episode" checked={settings.nextStrip} onChange={(v) => set({ nextStrip: v })} />
      {settings.nextStrip && <Cycler label="Strip appears" value={settings.nextStripSecs} options={STRIP} onChange={(v) => set({ nextStripSecs: v })} />}

      <SectionLabel>Sound</SectionLabel>
      <Toggle label="Bumper chime" hint="Station chime with the cards" checked={settings.jingle} onChange={(v) => set({ jingle: v })} />

      <ConfirmButton
        label="Reset broadcast settings"
        confirmLabel="Press again to reset"
        onConfirm={() => onChange({ ...BROADCAST_DEFAULTS })}
        className="ps-btn mt-2 flex min-h-11 items-center justify-center gap-2 text-sm"
      >
        {(armed) => (
          <>
            <RotateCcw size={14} /> {armed ? "Press again to reset" : "Reset broadcast settings"}
          </>
        )}
      </ConfirmButton>
    </div>
  );
}

export default memo(BroadcastTab);
