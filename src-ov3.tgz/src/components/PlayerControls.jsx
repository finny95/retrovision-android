import React, { useEffect, useState } from "react";
import { Play, Pause, Volume2, VolumeX, Maximize, Minimize } from "lucide-react";

function formatTime(s) {
  if (!s || !isFinite(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

// Volume and mute live in the app's saved preferences (so controller volume and
// this slider stay in step); the parent passes them in.
export default function PlayerControls({ videoRef, containerRef, disabled, live, volume, muted, onVolume, onToggleMute }) {
  const [playing, setPlaying] = useState(false);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isFs, setIsFs] = useState(false);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onTime = () => setCurrent(v.currentTime);
    const onDur = () => setDuration(v.duration || 0);
    v.addEventListener("play", onPlay);
    v.addEventListener("pause", onPause);
    v.addEventListener("timeupdate", onTime);
    v.addEventListener("loadedmetadata", onDur);
    v.addEventListener("durationchange", onDur);
    return () => {
      v.removeEventListener("play", onPlay);
      v.removeEventListener("pause", onPause);
      v.removeEventListener("timeupdate", onTime);
      v.removeEventListener("loadedmetadata", onDur);
      v.removeEventListener("durationchange", onDur);
    };
  }, [videoRef]);

  useEffect(() => {
    const onFs = () => setIsFs(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v || !v.src) return;
    if (v.paused) v.play();
    else v.pause();
  };

  const onSeek = (e) => {
    const v = videoRef.current;
    if (!v || !v.duration) return;
    v.currentTime = Number(e.target.value);
    setCurrent(v.currentTime);
  };


  const toggleFullscreen = () => {
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen();
  };

  const pct = duration ? (current / duration) * 100 : 0;

  return (
    <div className="flex flex-col gap-2 px-1">
      <div className="group relative flex items-center rounded-full has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-[#ffd21f]">
        <div className="ps-inset relative h-2 w-full !rounded-full">
          <div
            className="absolute left-0 top-0 h-full rounded-full bg-gradient-to-b from-[#fff27a] to-[#f5b800]"
            style={{ width: `${pct}%` }}
          />
        </div>
        <input
          type="range"
          min={0}
          max={duration || 0}
          step={0.01}
          value={current}
          onChange={onSeek}
          disabled={disabled || live}
          className="absolute inset-0 m-0 w-full cursor-pointer opacity-0 disabled:cursor-not-allowed"
          aria-label="Seek"
        />
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        <button
          onClick={togglePlay}
          disabled={disabled}
          className="ps-btn-primary flex h-10 w-10 items-center justify-center disabled:cursor-not-allowed disabled:opacity-40"
          aria-label={playing ? "Pause" : "Play"}
        >
          {playing ? <Pause size={18} /> : <Play size={18} className="ml-0.5" />}
        </button>

        <span className="whitespace-nowrap text-xs font-bold tabular-nums text-[#d4e3ff]">
          {formatTime(current)} <span className="text-[#6f8cc4]">/</span> {formatTime(duration)}
        </span>
        {live && (
          <span className="rounded bg-[#e2231a] px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white">
            ● Live
          </span>
        )}

        <div className="ml-auto flex min-w-0 items-center gap-1 sm:gap-2">
          <button
            onClick={onToggleMute}
            className="ps-btn flex h-9 w-9 shrink-0 items-center justify-center disabled:cursor-not-allowed disabled:opacity-40"
            aria-label={muted ? "Unmute" : "Mute"}
          >
            {muted || volume === 0 ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={muted ? 0 : volume}
            onChange={(e) => onVolume(Number(e.target.value))}
            className="tv-range w-16 min-w-0 cursor-pointer sm:w-24"
            style={{ "--pct": `${(muted ? 0 : volume) * 100}%` }}
            aria-label="Volume"
          />
          <button
            onClick={toggleFullscreen}
            disabled={disabled}
            className="ps-btn flex h-9 w-9 shrink-0 items-center justify-center disabled:cursor-not-allowed disabled:opacity-40"
            aria-label="Fullscreen"
          >
            {isFs ? <Minimize size={18} /> : <Maximize size={18} />}
          </button>
        </div>
      </div>
    </div>
  );
}