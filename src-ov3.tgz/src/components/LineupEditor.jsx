import React, { useEffect, useMemo, useRef, useState } from "react";
import { ArrowUp, ArrowDown, X, RefreshCw, Tv, Megaphone } from "lucide-react";
import { formatClock } from "@/lib/schedule";
import { useBackHandler } from "@/components/tv/backStack";
import { Modal } from "@/components/tv/Picker";
import { focusEl, refocus } from "@/lib/spatialNav";

// Long lineups (every episode of several shows) are drawn a page at a time.
const PAGE = 60;
const iconBtn = "ps-btn flex h-9 w-9 shrink-0 items-center justify-center !rounded-lg disabled:opacity-25";

// The full saved lineup of a playlist channel. B or Done closes.
export default function LineupEditor({ lineup, media, onChange, onRebuild, onClose }) {
  const [shown, setShown] = useState(PAGE);
  const boxRef = useRef(null);
  const byId = useMemo(() => new Map(media.map((m) => [m.id, m])), [media]);
  const total = useMemo(() => lineup.reduce((n, e) => n + (byId.get(e.mediaId)?.duration || 0), 0), [lineup, byId]);

  useBackHandler(() => {
    onClose();
    return true;
  });
  useEffect(() => {
    requestAnimationFrame(() => focusEl(document.querySelector("[data-lineup-done]")));
  }, []);

  const move = (i, dir) => {
    const j = i + dir;
    if (j < 0 || j >= lineup.length) return;
    const next = [...lineup];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
    refocus(`[data-lineup-row="${j}"] [data-act="${dir < 0 ? "up" : "down"}"]`);
  };
  const remove = (i) => {
    onChange(lineup.filter((_, k) => k !== i));
    const at = Math.min(i, lineup.length - 2);
    refocus(`[data-lineup-row="${at}"] [data-act="remove"]`, "[data-lineup-done]");
  };

  return (
    <Modal
      wide
      title={`Lineup · ${lineup.length} items`}
      subtitle={`Loops every ${formatClock(total)} (plus breaks and bumpers). Stays exactly as you set it.`}
      onClose={onClose}
      bodyRef={boxRef}
      footer="A: move / remove · B: done"
    >
      <div className="grid grid-cols-2 gap-2 pb-1">
        <button onClick={onRebuild} className="ps-btn flex min-h-10 items-center justify-center gap-1.5 text-xs uppercase">
          <RefreshCw size={13} /> Rebuild
        </button>
        <button data-lineup-done onClick={onClose} className="ps-btn-primary flex min-h-10 items-center justify-center text-xs uppercase">
          Done
        </button>
      </div>
      {lineup.slice(0, shown).map((e, i) => {
        const m = byId.get(e.mediaId);
        return (
          <div key={`${e.mediaId}-${i}`} data-lineup-row={i} className={`ps-inset flex items-center gap-1.5 px-2 py-1.5 ${m ? "" : "!border-red-500/60"}`}>
            <span className="w-8 shrink-0 text-right text-[10px] font-bold text-[#6f8cc4]">{i + 1}</span>
            {e.kind === "ad" ? <Megaphone size={13} className="shrink-0 text-sky-300" /> : <Tv size={13} className="shrink-0 text-[#ffd21f]" />}
            <span className="min-w-0 flex-1">
              <span className="block truncate text-xs font-bold text-white">{m ? m.name : "Missing file (skipped)"}</span>
              {m && <span className="block truncate text-[10px] text-[#a9c3ee]">{[m.show, m.season].filter(Boolean).join(" / ")} · {formatClock(m.duration)}</span>}
            </span>
            <button data-act="up" onClick={() => move(i, -1)} disabled={i === 0} className={iconBtn} aria-label="Move up">
              <ArrowUp size={14} />
            </button>
            <button data-act="down" onClick={() => move(i, 1)} disabled={i === lineup.length - 1} className={iconBtn} aria-label="Move down">
              <ArrowDown size={14} />
            </button>
            <button data-act="remove" onClick={() => remove(i)} className={iconBtn} aria-label="Remove from lineup">
              <X size={14} />
            </button>
          </div>
        );
      })}
      {lineup.length > shown && (
        <button onClick={() => setShown((n) => n + PAGE * 2)} className="ps-btn min-h-10 text-[11px] uppercase">
          Show more ({lineup.length - shown} left)
        </button>
      )}
    </Modal>
  );
}
