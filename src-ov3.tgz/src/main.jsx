import React, { useEffect } from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@fontsource/vt323/400.css'
import '@fontsource/arimo/400.css'
import '@fontsource/arimo/700.css'
import '@fontsource/arimo/700-italic.css'
import '@/index.css'
import '@/components/installation/installPrompt'
import { isNative } from '@/native/platform'

// The Android app bundles the site itself, so it skips the offline service worker.
if ('serviceWorker' in navigator && import.meta.env.PROD && !isNative()) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {})
  })
}

// Android app: starts updates, back button and keep-awake handling. It mounts next to
// the app so it only runs once the first render succeeded (a broken update then rolls back).
function NativeBoot() {
  useEffect(() => {
    import('@/native/boot').then(({ startNative }) => startNative())
  }, [])
  return null
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <>
    <App />
    {isNative() && <NativeBoot />}
  </>
)