import { useEffect, useRef } from "react";
import { drawBumper, drawDog, drawNextStrip, drawRatingBug, drawCaption } from "@/lib/broadcastGfx";
import { cueAt } from "@/lib/subtitles";
import { drawTeletext } from "@/lib/teletext";
import { programmeTitle } from "@/lib/schedule";

// Owns the canvas of channel graphics the CRT shader lays over the picture.
// Redraws only when what's on it changes (or every frame while animating), and
// tells CRTPlayer through gfxRef: { canvas, dirty, animating, visible, resize }.
export default function useBroadcastGfx({ videoRef, state }) {
  const stateRef = useRef(state);
  stateRef.current = state;
  const gfxRef = useRef(null);
  if (!gfxRef.current) {
    // Fixed-size canvas (the GPU texture never needs reallocating). Graphics are
    // drawn in a space matching the screen's shape and squeezed to fit, so they
    // look right once the shader stretches the canvas over the screen.
    const canvas = document.createElement("canvas");
    canvas.width = 1024;
    canvas.height = 576;
    gfxRef.current = {
      canvas,
      dirty: true,
      animating: false,
      visible: false,
      aspect: 16 / 9,
      resize(w, h) {
        const a = Math.max(0.5, Math.min(3, w / Math.max(1, h)));
        if (Math.abs(a - this.aspect) > 0.001) {
          this.aspect = a;
          this.sig = "";
        }
        return false;
      },
      sig: "",
    };
  }

  useEffect(() => {
    let raf;
    let fontsReady = false;
    Promise.all([document.fonts?.load?.("700 40px Arimo"), document.fonts?.load?.("italic 700 40px Arimo"), document.fonts?.load?.("40px VT323")]).then(() => {
      fontsReady = true;
      gfxRef.current.sig = "";
    }).catch(() => {});
    const ctx = gfxRef.current.canvas.getContext("2d");
    let stripAt = 0;
    let lastStripKey = "";

    const frame = () => {
      const g = gfxRef.current;
      const s = stateRef.current;
      const { canvas } = g;
      const h = 576;
      const w = Math.round(h * g.aspect);
      const begin = () => {
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.setTransform(canvas.width / w, 0, 0, 1, 0, 0);
      };
      const now = Date.now();
      const b = s.bumper;
      const bc = s.settings;

      // Teletext covers everything (or sits over the picture in mix mode).
      if (s.teletext) {
        const tt = s.teletext;
        const sig = `tt:${tt.page}:${tt.sub}:${tt.typed}:${tt.mix}:${Math.floor(now / 1000)}:${w}:${fontsReady}:${tt.built.rows.length}`;
        g.animating = false;
        if (sig === g.sig) return;
        g.sig = sig;
        begin();
        drawTeletext(ctx, w, h, tt, tt.built, now);
        g.visible = true;
        g.dirty = true;
        return;
      }

      if (b) {
        const t = (now - b.startedAt) / 1000;
        // The overnight test card is still: redraw it once a minute (its clock),
        // not every frame for hours.
        if (b.bumper === "closedown" && t > 11) {
          const sig = `cd:${b.key}:${Math.floor(now / 60000)}:${w}:${fontsReady}`;
          g.animating = false;
          if (sig === g.sig) return;
          g.sig = sig;
        } else if (b.bumper === "weather") {
          // The weather channel runs for hours: 20 frames a second is plenty.
          g.animating = true;
          if (now - (g.lastWx || 0) < 50) return;
          g.lastWx = now;
          g.sig = `bumper:${b.key}`;
        } else {
          g.animating = true;
          g.sig = `bumper:${b.key}`;
        }
        begin();
        drawBumper(ctx, w, h, b, t, s.channel);
        g.visible = true;
        g.dirty = true;
        return;
      }
      g.animating = false;

      // Overlays over a programme: logo, classification bug, "Next" strip.
      const it = s.item;
      const v = videoRef.current;
      const parts = [];
      let bugAlpha = 0;
      let strip = 0;
      if (s.channel && it && it.kind === "show" && v) {
        const into = v.currentTime - (it.from || 0);
        if (bc.dog) parts.push(`dog:${bc.dogCorner}:${bc.dogOpacity}:${s.channel.id}:${s.channel.logoText || s.channel.name}`);
        const rating = s.ratings?.[it.media?.show];
        if (bc.ratingBug && rating && it.part === 0 && into >= 0 && into < bc.ratingBugSecs) {
          bugAlpha = clampFade(into, bc.ratingBugSecs);
          parts.push(`bug:${rating}:${Math.round(bugAlpha * 10)}`);
        }
        const left = (it.to ?? v.duration) - v.currentTime;
        if (bc.nextStrip && s.next && it.part === (it.parts || 1) - 1 && left > 0 && left < bc.nextStripSecs) {
          const key = `${it.media?.id}:${s.next.startMs}`;
          if (key !== lastStripKey) {
            lastStripKey = key;
            stripAt = now;
          }
          strip = Math.min(1, (now - stripAt) / 600);
          parts.push(`strip:${key}:${Math.round(strip * 20)}`);
        }
      }
      // Closed captions for whatever file is playing.
      const cue = s.cues && v && v.getAttribute("src") ? cueAt(s.cues, v.currentTime) : null;
      if (cue) parts.push(`cc:${cue.start}:${cue.text.length}`);
      const sig = `${fontsReady}|${w}x${h}|${parts.join("|")}`;
      if (sig === g.sig) return;
      g.sig = sig;
      begin();
      if (!parts.length) {
        g.visible = false;
        g.dirty = true;
        return;
      }
      if (bc.dog && s.channel && it?.kind === "show") drawDog(ctx, w, h, s.channel, bc.dogCorner, bc.dogOpacity);
      if (bugAlpha > 0) drawRatingBug(ctx, w, h, s.ratings[it.media.show], bugAlpha);
      if (strip > 0) drawNextStrip(ctx, w, h, programmeTitle(s.next), s.channel, strip);
      if (cue) drawCaption(ctx, w, h, cue.text);
      g.visible = true;
      g.dirty = true;
    };
    // Every frame normally. Low power: about 15 a second while something moves,
    // otherwise a few checks a second (captions, the logo, the Next strip).
    let timer = 0;
    const loop = () => {
      frame();
      if (stateRef.current.lowPower) timer = setTimeout(loop, gfxRef.current.animating ? 66 : 150);
      else raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(timer);
    };
  }, [videoRef]);

  return gfxRef;
}

function clampFade(t, total) {
  return Math.max(0, Math.min(1, Math.min(t / 0.4, (total - t) / 0.6)));
}
