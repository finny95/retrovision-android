import { useEffect, useState } from "react";

// Battery level and charging, where the device shares them (Battery Status API).
// null = unknown (no battery, or the browser doesn't say).
export default function useBattery() {
  const [battery, setBattery] = useState(null);
  useEffect(() => {
    let mgr = null;
    let alive = true;
    const read = () => alive && mgr && setBattery({ level: mgr.level, charging: mgr.charging });
    navigator.getBattery?.()
      .then((m) => {
        mgr = m;
        read();
        m.addEventListener("levelchange", read);
        m.addEventListener("chargingchange", read);
      })
      .catch(() => {});
    return () => {
      alive = false;
      mgr?.removeEventListener("levelchange", read);
      mgr?.removeEventListener("chargingchange", read);
    };
  }, []);
  return battery;
}
