import React, { useEffect, useRef } from "react";

// Low power mode's picture: the plain <video> (the device's own video hardware
// does the work), the channel graphics canvas laid straight over it, a small
// snow canvas between channels, and optionally one still layer of scanlines.
// No WebGL; the only loop runs a few times a second unless snow is showing or
// the picture is sitting in the guide's box. Same props as CRTPlayer where they
// matter.
export default function LitePlayer({ videoRef, hasFrame, staticLevel = 0, gfxRef = null, power = "on", powerFx = true, pig = false, scanlines = true }) {
  const boxRef = useRef(null);
  const snowRef = useRef(null);
  const levelRef = useRef(staticLevel);
  levelRef.current = staticLevel;
  const pigRef = useRef(pig);
  pigRef.current = pig;
  const frameRef = useRef(hasFrame);
  frameRef.current = hasFrame;
  const kickRef = useRef(null);

  // The video element shows itself (it stays hidden while the CRT canvas draws it).
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return undefined;
    const keep = v.getAttribute("style") || "";
    // Android's WebView draws a grey "play" picture on a bare video: blank it.
    const keepPoster = v.getAttribute("poster");
    v.setAttribute("poster", "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7");
    Object.assign(v.style, {
      display: "block",
      position: "absolute",
      left: "0px",
      top: "0px",
      width: "100%",
      height: "100%",
      objectFit: "contain",
      background: "#000",
      zIndex: "0",
    });
    return () => {
      v.setAttribute("style", keep);
      if (keepPoster == null) v.removeAttribute("poster");
      else v.setAttribute("poster", keepPoster);
    };
  }, [videoRef]);

  // Channel graphics: the same canvas CRTPlayer uses as a texture, shown as is.
  useEffect(() => {
    const g = gfxRef?.current;
    const box = boxRef.current;
    if (!g || !box) return undefined;
    const c = g.canvas;
    Object.assign(c.style, { position: "absolute", left: "0px", top: "0px", width: "100%", height: "100%", pointerEvents: "none" });
    box.insertBefore(c, box.firstChild);
    return () => {
      c.remove();
      c.removeAttribute("style");
    };
  }, [gfxRef]);

  // Switching on / off: the picture folds to a line and a dot (plain CSS).
  const firstPower = useRef(true);
  useEffect(() => {
    if (firstPower.current) {
      firstPower.current = false;
      if (power === "on") return;
    }
    const v = videoRef.current;
    const anim = !powerFx ? "" : power === "off" ? "rv-tube-off 0.42s ease-in forwards" : "rv-tube-on 0.5s ease-out";
    for (const el of [v, boxRef.current]) {
      if (!el) continue;
      el.style.animation = "none";
      void el.offsetWidth; // restart
      el.style.transformOrigin = "50% 50%";
      el.style.animation = anim;
    }
  }, [power, powerFx, videoRef]);

  useEffect(() => {
    const box = boxRef.current;
    const snow = snowRef.current;
    const v = videoRef.current;
    const g = gfxRef?.current;
    if (!box || !snow || !v) return undefined;
    const sctx = snow.getContext("2d");
    const img = sctx.createImageData(snow.width, snow.height);
    let raf = 0;
    let timer = 0;
    let lastSnow = 0;
    let shown = 0;
    let lastPlace = "";
    const set = (el, prop, val) => {
      if (el.style[prop] !== val) el.style[prop] = val;
    };
    // The guide's box (it only moves when the screen changes size).
    const place = () => {
      let r = null;
      if (pigRef.current) {
        const slot = document.querySelector("[data-pig-slot]");
        const parent = box.parentElement;
        if (slot && parent) {
          const s = slot.getBoundingClientRect();
          const p = parent.getBoundingClientRect();
          r = { x: s.left + slot.clientLeft - p.left, y: s.top + slot.clientTop - p.top, w: slot.clientWidth, h: slot.clientHeight };
        } else r = { x: 0, y: 0, w: 0, h: 0 };
      }
      const key = r ? `${r.x},${r.y},${r.w},${r.h}` : "full";
      if (key === lastPlace) return;
      lastPlace = key;
      const css = r
        ? { left: `${r.x}px`, top: `${r.y}px`, width: `${r.w}px`, height: `${r.h}px`, borderRadius: "6px" }
        : { left: "0px", top: "0px", width: "100%", height: "100%", borderRadius: "" };
      Object.assign(box.style, css);
      Object.assign(v.style, css);
    };
    const tick = () => {
      const now = performance.now();
      place();
      set(v, "visibility", frameRef.current ? "" : "hidden");
      if (g) set(g.canvas, "display", g.visible ? "" : "none");
      // Snow: snaps on, fades over a quarter second, ~12 frames a second.
      const target = levelRef.current;
      shown = target >= shown ? target : Math.max(target, shown - 0.07);
      set(snow, "opacity", String(Math.min(1, Math.round(shown * 100) / 100)));
      set(snow, "display", shown > 0.01 ? "" : "none");
      if (shown > 0.01 && now - lastSnow > 80) {
        lastSnow = now;
        const d = img.data;
        for (let i = 0; i < d.length; i += 4) {
          const n = Math.random();
          const l = n * n * 255;
          d[i] = d[i + 1] = d[i + 2] = l;
          d[i + 3] = 255;
        }
        sctx.putImageData(img, 0, 0);
      }
      // Busy (snow, or the guide's box): every frame. Otherwise a few times a second.
      if (shown > 0.01 || pigRef.current) raf = requestAnimationFrame(tick);
      else timer = setTimeout(tick, 120);
    };
    kickRef.current = () => {
      cancelAnimationFrame(raf);
      clearTimeout(timer);
      tick();
    };
    tick();
    return () => {
      kickRef.current = null;
      cancelAnimationFrame(raf);
      clearTimeout(timer);
    };
  }, [videoRef, gfxRef]);

  // Snow or the guide's box starting: don't wait for the next slow check.
  useEffect(() => {
    kickRef.current?.();
  }, [staticLevel, pig, hasFrame]);

  return (
    <div ref={boxRef} className="pointer-events-none absolute inset-0 z-[1] overflow-hidden">
      <canvas ref={snowRef} width={240} height={135} className="absolute inset-0 h-full w-full" style={{ display: "none" }} />
      {scanlines && <div className="rv-lite-lines absolute inset-0" />}
    </div>
  );
}
