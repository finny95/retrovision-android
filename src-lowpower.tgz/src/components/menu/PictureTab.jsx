import React, { memo, useMemo } from "react";
import { RotateCcw } from "lucide-react";
import { FIELDS, PRESETS, RETRO, formatSetting } from "@/lib/crtSettings";
import { Cycler, SliderRow, SectionLabel, Toggle } from "@/components/tv/controls";

const RECEPTION = [
  { value: "perfect", label: "Perfect" },
  { value: "good", label: "Good (rare blips)" },
  { value: "fair", label: "Fair" },
  { value: "poor", label: "Poor (stormy night)" },
];

const LOW_POWER = [
  { value: "off", label: "Off" },
  { value: "on", label: "On" },
  { value: "auto", label: "Auto (battery low)" },
];

function lowPowerHint(lp) {
  if (lp.mode === "auto") {
    if (!lp.battery) return "This device doesn't share its battery level, so Auto stays off.";
    const pct = Math.round(lp.battery.level * 100);
    return `Battery ${pct}%${lp.battery.charging ? ", charging" : ""}. Turns on below 30% when not charging.`;
  }
  return "Plain picture and lighter graphics: uses much less battery.";
}

const same = (a, b) => FIELDS.every((f) => Math.abs((a[f.key] ?? 0) - (b[f.key] ?? 0)) < 1e-6);

// One setting per row: Up/Down picks the setting, Left/Right changes it.
// lowPower: { mode, active, battery, scanlines }; onLowPower(prefs patch).
function PictureTab({ settings, onChange, lowPower = null, onLowPower }) {
  const look = useMemo(() => Object.keys(PRESETS).find((k) => same(settings, PRESETS[k])) || "Custom", [settings]);
  const options = useMemo(() => {
    const list = Object.keys(PRESETS).map((k) => ({ value: k, label: k }));
    return look === "Custom" ? [...list, { value: "Custom", label: "Custom" }] : list;
  }, [look]);

  return (
    <div className="flex flex-col gap-2">
      <Cycler
        label="Look"
        hint="Pick a style, then fine-tune below"
        value={look}
        options={options}
        onChange={(v) => PRESETS[v] && onChange({ ...settings, ...PRESETS[v] })}
      />
      <SectionLabel hint="Up / Down picks a setting · Left / Right changes it">Fine-tune</SectionLabel>
      {FIELDS.map((f) => (
        <SliderRow
          key={f.key}
          label={f.label}
          value={settings[f.key]}
          min={f.min}
          max={f.max}
          step={f.step}
          display={formatSetting(f, settings[f.key])}
          onChange={(v) => onChange({ ...settings, [f.key]: v })}
        />
      ))}
      <SectionLabel hint="Now and then the picture breaks up into blocks for a moment, like a weak signal on a stormy night.">Reception</SectionLabel>
      <Cycler label="Signal" value={settings.reception || "perfect"} options={RECEPTION} onChange={(v) => onChange({ ...settings, reception: v })} />
      <Toggle
        label="Menus on the tube"
        hint="Menus and on-screen info bulge and get scanlines like the picture. Turn off if menus feel slow."
        checked={settings.tubeUi !== false}
        onChange={(v) => onChange({ ...settings, tubeUi: v })}
      />
      <Toggle label="Switch on / off effect" hint="The picture opens from a line when it starts, and shrinks to a dot when it turns off" checked={settings.powerFx !== false} onChange={(v) => onChange({ ...settings, powerFx: v })} />
      {lowPower && (
        <>
          <SectionLabel hint="No CRT effects, a lighter picture and graphics. For when the battery matters more than the look.">Battery</SectionLabel>
          <Cycler label="Low power" hint={lowPowerHint(lowPower)} value={lowPower.mode} options={LOW_POWER} onChange={(v) => onLowPower?.({ lowPower: v })} />
          {lowPower.mode !== "off" && (
            <Toggle
              label="Scanlines in low power"
              hint="One still layer of lines over the picture. Costs almost nothing."
              checked={lowPower.scanlines}
              onChange={(v) => onLowPower?.({ liteScanlines: v })}
            />
          )}
          {lowPower.active && (
            <p className="ps-inset px-3 py-2 text-xs font-bold text-[#ffe14d]" data-testid="low-power-note">
              Low power is on: the CRT effects above are paused.
            </p>
          )}
        </>
      )}
      <button
        onClick={() => onChange({ ...RETRO, reception: settings.reception, powerFx: settings.powerFx, tubeUi: settings.tubeUi })}
        className="ps-btn mt-1 flex min-h-11 items-center justify-center gap-2 text-sm"
      >
        <RotateCcw size={14} /> Reset picture
      </button>
    </div>
  );
}

export default memo(PictureTab);
