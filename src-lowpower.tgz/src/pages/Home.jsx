import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { WifiOff, Menu as MenuIcon, ChevronUp, ChevronDown, Volume1, Volume2, VolumeX, Play, Pause } from "lucide-react";
import CRTPlayer from "@/components/CRTPlayer";
import LitePlayer from "@/components/LitePlayer";
import useBattery from "@/hooks/useBattery";
import { useTube } from "@/components/TubeFilter";
import PlayerControls from "@/components/PlayerControls";
import MenuPanel, { TABS, Brand } from "@/components/menu/MenuPanel";
import ChannelsTab from "@/components/menu/ChannelsTab";
import LibraryTab, { LOOSE } from "@/components/menu/LibraryTab";
import PictureTab from "@/components/menu/PictureTab";
import SoundTab from "@/components/menu/SoundTab";
import GuideTab from "@/components/menu/GuideTab";
import BroadcastTab from "@/components/menu/BroadcastTab";
import SystemTab from "@/components/menu/SystemTab";
import PinPad from "@/components/PinPad";
import useSleepTimer from "@/hooks/useSleepTimer";
import ReminderPopup from "@/components/ReminderPopup";
import { buildPage, FASTEXT } from "@/lib/teletext";
import { useWeather, DEFAULT_PLACE } from "@/lib/weather";
import { setSeasonal } from "@/lib/broadcastGfx";
import { remotePageHtml, REMOTE_KEYS } from "@/lib/remotePage";
import useBroadcastGfx from "@/hooks/useBroadcastGfx";
import { useBreaks, withBreaks } from "@/lib/episodeMeta";
import { ChannelBug, VolumeBar, MuteTag, InfoBanner, ScreenMessage, NumberEntry, CornerTag, SleepIcon, LockScreen, AsleepScreen, TimeshiftTag } from "@/components/TvOsd";
import InstallButton from "@/components/InstallButton";
import { Key } from "@/components/tv/controls";
import useChannelPlayback from "@/hooks/useChannelPlayback";
import useControls from "@/hooks/useControls";
import useLandscape from "@/hooks/useLandscape";
import useMedia from "@/hooks/useMedia";
import useAutoFullscreen from "@/hooks/useAutoFullscreen";
import useStableCallback from "@/hooks/useStableCallback";
import { BackStackContext, createBackStack } from "@/components/tv/backStack";
import { usePrefs, boostFor, replacePrefs } from "@/lib/prefs";
import { replaceBreaks } from "@/lib/episodeMeta";
import { unlockAudio, routePlayer, setBoostDb, startStatic, stopStatic, playChime, startTone, stopTone, setToneVolume, setAutoLevel, setLevelKey, onLoudness, startAmbient, stopAmbient, setAmbientVolume } from "@/lib/audioEngine";
import { setEpisodeInfoEnabled, syncEpisodeInfo, episodeInfoStatus, useEpisodeInfo, episodeLine, clearEpisodeInfo } from "@/lib/episodeInfo";
import { loadSubtitles, hasSubtitles } from "@/lib/subtitles";
import { isNative } from "@/native/platform";
import { hasNative } from "@/native/capabilities";
import { activeScope, adjust, focusEl, focusFirst, getFocusables, isAdjustable, moveFocus } from "@/lib/spatialNav";
import { pickLinkedFolder, describeHandle, getPlayable, pathInfo, matchSubtitle } from "@/lib/linkedFolder";
import { listShows, generateLineup, formatClock, setBroadcast, broadcastVersion, nowNext, promoFor, promoWhen, programmeTitle, RATINGS, newSeed } from "@/lib/schedule";
import {
  addMedia, addLinkedMediaBatch, listMedia, removeMedia, parsePath, updateMedia,
  listChannels, saveChannel, removeChannel, clearMedia, clearChannels,
} from "@/lib/mediaDb";

// Shows something for `ms`, then hides it. Re-flashing restarts the timer.
function useFlash() {
  const [on, setOn] = useState(false);
  const timer = useRef(null);
  const flash = useCallback((ms) => {
    setOn(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setOn(false), ms);
  }, []);
  const hide = useCallback(() => {
    clearTimeout(timer.current);
    setOn(false);
  }, []);
  useEffect(() => () => clearTimeout(timer.current), []);
  return [on, flash, hide];
}

// Run after React has drawn the latest state.
const afterRender = (fn) => requestAnimationFrame(() => requestAnimationFrame(fn));
const clamp01 = (v) => Math.min(1, Math.max(0, Math.round(v * 100) / 100));
const pad2 = (n) => String(n).padStart(2, "0");
const isTab = (el) => el?.getAttribute?.("role") === "tab";

const WATCH_HINTS = [
  ["▲▼", "Channel"],
  ["◀▶", "Volume"],
  ["A", "Pause"],
  ["X", "Mute"],
  ["LT", "Last ch"],
  ["RT", "Sleep"],
  ["Start", "Menu"],
];
// TV remote / keyboard without a controller.
const REMOTE_HINTS = [
  ["▲▼", "Channel"],
  ["0-9", "Channel no."],
  ["◀▶", "Volume"],
  ["OK", "Menu"],
  ["Back", "Close"],
];
const SLEEP_FADE_MS = 5000;
const TEXT_PAGES = (n) => [100, 101, 102, 110, ...Array.from({ length: Math.min(19, n) }, (_, i) => 111 + i), 200, 201, 300, 400];
// Ratings at or above the lock setting need the PIN.
const lockedRating = (rating, lock) => lock !== "off" && rating && RATINGS.indexOf(rating) >= RATINGS.indexOf(lock);

export default function Home() {
  const videoRef = useRef(null);
  const stageRef = useRef(null);
  const screenRef = useRef(null); // the box the picture fills
  const objectUrlRef = useRef(null);
  const queueRef = useRef(null); // { list, index } while playing through a show
  const lastFocusRef = useRef(null);
  const lastBackRef = useRef(0);
  const switchRef = useRef({ at: 0, seq: 0 });
  const srcSeqRef = useRef(0);
  const backStack = useMemo(createBackStack, []);

  const [prefs, update] = usePrefs();
  const [src, setSrc] = useState("");
  const [srcSeq, setSrcSeq] = useState(0);
  const [label, setLabel] = useState("Nothing loaded");
  const [activeId, setActiveId] = useState(null);
  const [currentRec, setCurrentRec] = useState(null);
  const [isAudio, setIsAudio] = useState(false);
  const [rawLibrary, setLibrary] = useState([]);
  const [breaksMap, setBreaks] = useBreaks();
  const [hasFrame, setHasFrame] = useState(false);
  const [loadProblem, setLoadProblem] = useState(null);
  const [online, setOnline] = useState(navigator.onLine);
  const [importing, setImporting] = useState(null);
  const [channels, setChannels] = useState([]);
  const [channel, setChannel] = useState(null);
  const [editing, setEditing] = useState(null); // null | "new" | channel
  const [tab, setTab] = useState(TABS.some((t) => t.id === prefs.lastTab) ? prefs.lastTab : "guide");
  const [libShow, setLibShow] = useState(null);
  const [navMode, setNavMode] = useState("watch"); // where controller / keys go
  const [menuOpen, setMenuOpen] = useState(false); // TV layout overlay
  const [switching, setSwitching] = useState(false);
  const [bugOn, flashBug, hideBug] = useFlash();
  const [volOn, flashVol, hideVol] = useFlash();
  const [infoOn, flashInfo, hideInfo] = useFlash();
  const [touchOn, flashTouch, hideTouch] = useFlash();
  const [tagOn, flashTag, hideTag] = useFlash(); // sleep / captions corner tag
  const [tagText, setTagText] = useState("");

  const tv = useLandscape(); // phone/handheld sideways or a TV: full-screen picture, menu slides over
  const wide = useMedia("(min-width: 1024px)");
  const guideFull = tv && menuOpen && tab === "guide";
  const variant = tv ? (guideFull ? "full" : "overlay") : wide ? "column" : "inline";
  useAutoFullscreen(tv);

  // Library records with their break points (own or the show's automatic ones).
  const library = useMemo(() => withBreaks(rawLibrary, breaksMap, prefs.autoBreaks), [rawLibrary, breaksMap, prefs.autoBreaks]);
  // Broadcast settings feed the scheduler (bumpers, breaks, rating cards).
  const scheduleKey = useMemo(() => {
    const b = prefs.broadcast;
    setBroadcast({
      upNextSecs: b.upNext ? b.upNextSecs : 0,
      identSecs: b.ident ? b.identSecs : 0,
      breakSecs: b.breakBumpers ? b.breakBumperSecs : 0,
      ratingCard: b.ratingCard,
      ratingCardSecs: b.ratingCardSecs,
      promos: b.promos,
      promoSecs: b.promoSecs,
      closedown: b.closedown ? { from: b.closedownFrom, to: b.closedownTo } : null,
      ratings: prefs.ratings,
    });
    return broadcastVersion();
  }, [prefs.broadcast, prefs.ratings]);
  const shows = listShows(library);
  const currentShow = currentRec?.show || null;
  const boostDb = boostFor(prefs, currentShow);

  // --- Library + channels -----------------------------------------------------
  useEffect(() => {
    Promise.all([listMedia(), listChannels()]).then(async ([m, list]) => {
      setLibrary(m);
      // Freeze channels saved before lineups existed so they stop reshuffling.
      const frozen = await Promise.all(
        list.map((c) => (c.lineup || c.blocks?.length || c.timetable ? c : saveChannel({ ...c, lineup: generateLineup(c, m) })))
      );
      setChannels(frozen.sort((a, b) => a.number - b.number));
    });
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, []);

  // --- Playback ---------------------------------------------------------------
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return undefined;
    setHasFrame(false);
    setLoadProblem(null);
    if (!src) {
      v.removeAttribute("src");
      v.load();
      return undefined;
    }
    const onLoaded = () => {
      setHasFrame(true);
      setLoadProblem(null);
    };
    // Say what went wrong instead of sitting on "Loading signal" forever.
    const onError = () =>
      setLoadProblem(v.error?.code === 4 ? "Can't play this file: its format isn't supported" : "Couldn't read this file. Try relinking the folder");
    const slow = setTimeout(() => {
      if (v.readyState < 2 && !v.error) setLoadProblem("Still tuning in… this file is slow to open");
    }, 15000);
    v.addEventListener("loadeddata", onLoaded);
    v.addEventListener("error", onError);
    v.load();
    v.play().catch(() => {});
    return () => {
      clearTimeout(slow);
      v.removeEventListener("loadeddata", onLoaded);
      v.removeEventListener("error", onError);
    };
  }, [src]);

  const bumpSrc = () => {
    srcSeqRef.current += 1;
    setSrcSeq(srcSeqRef.current);
  };

  const playBlob = useCallback(async (source, name, id, type) => {
    // `source` is a File/Blob or a library record (copied blob, linked file handle,
    // or in the Android app a linked file that resolves to a streaming URL).
    const playable = source instanceof Blob ? source : await getPlayable(source);
    if (!playable) {
      setLabel(`${name} (can't open: allow access or relink the folder)`);
      bumpSrc();
      return;
    }
    if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    const isUrl = typeof playable === "string";
    const url = isUrl ? playable : URL.createObjectURL(playable);
    objectUrlRef.current = isUrl ? null : url;
    setIsAudio(Boolean(type?.startsWith("audio")));
    setCurrentRec(source instanceof Blob ? null : source);
    setSrc(url);
    setLabel(name);
    setActiveId(id);
    bumpSrc();
  }, []);

  const clearPicture = useCallback((text = "Nothing loaded") => {
    if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    objectUrlRef.current = null;
    setSrc("");
    setLabel(text);
    setActiveId(null);
    setCurrentRec(null);
    bumpSrc();
  }, []);

  const [previewing, setPreviewing] = useState(false);
  const [power, setPower] = useState("on");
  const onChannelEmpty = useStableCallback(() => clearPicture("No episodes on this channel"));
  const activeIdRef = useRef(null);
  activeIdRef.current = activeId;
  // Start over / pause live TV: how far behind live the channel is.
  const [shift, setShift] = useState(0);
  const [livePause, setLivePause] = useState(null); // ms when paused
  useEffect(() => {
    setShift(0);
    setLivePause(null);
  }, [channel?.id]);
  const { nowPlaying, bumper } = useChannelPlayback({
    videoRef,
    channel,
    media: library,
    playBlob,
    onEmpty: onChannelEmpty,
    scheduleKey,
    loadedIdRef: activeIdRef,
    shiftMs: shift,
    paused: Boolean(livePause),
  });
  // Now / next programme for banners and the "Next" strip (at the channel's own time).
  const nn = useMemo(() => (channel ? nowNext(channel, library, Date.now() - shift) : null), [channel, library, nowPlaying, scheduleKey, shift]); // eslint-disable-line react-hooks/exhaustive-deps
  // --- Parental lock -------------------------------------------------------------
  // A locked channel, or a show rated at/above the lock, needs the PIN once per
  // app session (per channel / per show).
  const [unlocked, setUnlocked] = useState(() => new Set());
  const [pinAsk, setPinAsk] = useState(null); // { title, subtitle, then }
  const pin = prefs.parental.pin;
  const channelLocked = useCallback((c) => Boolean(pin && c?.locked && !unlocked.has(`ch:${c.id}`)), [pin, unlocked]);
  const playingItem = nowPlaying?.current;
  const lock = useMemo(() => {
    if (!pin) return null;
    if (channel && channelLocked(channel)) return { key: `ch:${channel.id}`, reason: `${channel.name} is locked` };
    const show = channel ? (playingItem?.kind === "show" ? playingItem.media?.show : null) : currentRec?.show;
    const r = show && prefs.ratings[show];
    if (show && lockedRating(r, prefs.parental.lockRating) && !unlocked.has(`show:${show}`)) return { key: `show:${show}`, reason: `${show} is rated ${r}` };
    return null;
  }, [pin, channel, channelLocked, playingItem, currentRec, prefs.ratings, prefs.parental.lockRating, unlocked]);
  const askUnlock = () => {
    if (!lock) return;
    const key = lock.key;
    setPinAsk({ title: "Locked", subtitle: lock.reason, then: () => setUnlocked((u) => new Set(u).add(key)) });
  };

  // --- Closed captions --------------------------------------------------------
  const [cues, setCues] = useState(null);
  useEffect(() => {
    setCues(null);
    if (!prefs.captions || !currentRec) return undefined;
    let alive = true;
    loadSubtitles(currentRec).then((c) => alive && setCues(c));
    return () => {
      alive = false;
    };
  }, [currentRec, prefs.captions]);
  const showTag = (text, ms = 2500) => {
    setTagText(text);
    flashTag(ms);
  };
  const toggleCaptions = () => {
    const on = !prefs.captions;
    update({ captions: on });
    showTag(on ? (currentRec && !hasSubtitles(currentRec) ? "CC on · none here" : "CC on") : "CC off");
  };

  // A promo card advertises something later on (this channel or another).
  const promo = useMemo(() => {
    if (bumper?.bumper !== "promo" || !channel) return null;
    const pick = promoFor(channels, library, channel, bumper.startedAt, `${channel.id}|${bumper.key}`);
    if (!pick) return null;
    return {
      channel: pick.channel,
      when: promoWhen(pick.prog.startMs, bumper.startedAt),
      title: programmeTitle(pick.prog),
      episode: episodeLine(pick.prog.media),
    };
  }, [bumper?.key, channel?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const weatherPlace = prefs.weatherPlace || DEFAULT_PLACE;
  const wx = useWeather(weatherPlace);
  // The weather channel draws the forecast full screen, over its music.
  const musicWeather = Boolean(channel?.weather && nowPlaying?.current?.kind === "music");
  const wxStart = useRef(Date.now());
  const gfxBumper = useMemo(() => {
    if (bumper?.bumper === "weather") return { ...bumper, weather: wx };
    if (musicWeather) return { bumper: "weather", key: "wx-music", startedAt: wxStart.current, endsAt: wxStart.current + 864e5, weather: wx };
    return bumper && promo ? { ...bumper, promo } : bumper;
  }, [bumper, promo, wx, musicWeather]);
  // Built-in weather music (when the weather channel has no music folder).
  const ambientOn = bumper?.bumper === "weather" && !prefs.muted && !previewing;
  useEffect(() => {
    if (!ambientOn) return undefined;
    startAmbient(prefs.volume);
    return () => stopAmbient();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ambientOn]);
  useEffect(() => setAmbientVolume(prefs.volume), [prefs.volume]);
  useEffect(() => setSeasonal(prefs.broadcast.seasonal !== false), [prefs.broadcast.seasonal]);

  // --- Teletext ------------------------------------------------------------------------
  const [tt, setTt] = useState(null); // { page, sub, typed, mix }
  const [ttTick, setTtTick] = useState(0);
  useEffect(() => {
    if (!tt) return undefined;
    const t = setInterval(() => setTtTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, [Boolean(tt)]); // eslint-disable-line react-hooks/exhaustive-deps
  const ttMinute = Math.floor(Date.now() / 60000);
  const ttBuilt = useMemo(
    () =>
      tt
        ? buildPage(tt.page, tt.sub, {
            channels,
            media: library,
            nowMs: Date.now(),
            weather: wx,
            reminders: prefs.reminders || [],
            captions: prefs.captions,
            sleepRemaining: 0,
          })
        : null,
    [tt?.page, tt?.sub, ttMinute, channels, library, wx, prefs.reminders, prefs.captions] // eslint-disable-line react-hooks/exhaustive-deps
  );
  // Pages with several screens turn over by themselves, like the real thing.
  useEffect(() => {
    if (!tt || !ttBuilt || ttBuilt.subpages < 2 || ttTick === 0 || ttTick % 15) return;
    setTt((x) => (x ? { ...x, sub: x.sub + 1 } : x));
  }, [ttTick]); // eslint-disable-line react-hooks/exhaustive-deps
  // --- Low power: plain picture, no WebGL, lighter graphics (Picture tab). Auto
  // turns it on when the battery is under 30% and not charging.
  const battery = useBattery();
  const lowMode = prefs.lowPower || "off";
  const batteryLow = Boolean(battery && !battery.charging && battery.level <= 0.3);
  const lowPower = lowMode === "on" || (lowMode === "auto" && batteryLow);
  const lowPowerWas = useRef(lowPower);
  useEffect(() => {
    if (lowPowerWas.current === lowPower) return;
    lowPowerWas.current = lowPower;
    if (lowMode === "auto") showTag(lowPower ? `Low power on · battery ${Math.round((battery?.level || 0) * 100)}%` : "Low power off");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lowPower]);

  const gfxRef = useBroadcastGfx({
    videoRef,
    state: {
      lowPower,
      bumper: gfxBumper,
      channel,
      item: nowPlaying?.current,
      settings: prefs.broadcast,
      ratings: prefs.ratings,
      next: nn?.next,
      cues: lock ? null : cues,
      teletext: tt && ttBuilt ? { ...tt, built: ttBuilt } : null,
    },
  });
  // Test-card tone overnight.
  const toneOn = bumper?.bumper === "closedown" && prefs.broadcast.closedownTone && !prefs.muted && !previewing && !lock;
  useEffect(() => {
    if (!toneOn) return undefined;
    startTone(prefs.volume);
    return () => stopTone();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toneOn]);
  useEffect(() => setToneVolume(prefs.volume), [prefs.volume]);
  // Station chime as a bumper starts.
  useEffect(() => {
    if (!bumper || !prefs.broadcast.jingle || prefs.muted || ["rating", "closedown", "standby"].includes(bumper.bumper)) return;
    if (Date.now() - bumper.startedAt < 800) playChime(prefs.volume, bumper.bumper);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bumper?.key]);

  // Files from the library play on through the show; a quick-play file repeats.
  useEffect(() => {
    const v = videoRef.current;
    if (!v || channel) return undefined;
    const onEnded = () => {
      const q = queueRef.current;
      const next = q?.list[q.index + 1];
      if (q && next) {
        queueRef.current = { list: q.list, index: q.index + 1 };
        playBlob(next, next.name, next.id, next.type);
      } else if (!q) {
        v.currentTime = 0;
        v.play().catch(() => {});
      }
    };
    v.addEventListener("ended", onEnded);
    return () => v.removeEventListener("ended", onEnded);
  }, [channel, playBlob]);

  // --- Sound: app volume, per-show boost, static hiss ---------------------------
  useEffect(() => {
    const on = (e) => setPreviewing(Boolean(e.detail));
    window.addEventListener("rv-preview", on);
    return () => window.removeEventListener("rv-preview", on);
  }, []);
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.volume = prefs.volume;
    v.muted = prefs.muted || previewing || Boolean(lock);
    if (prefs.muted) stopStatic();
  }, [prefs.volume, prefs.muted, previewing, lock]);

  const boostRef = useRef(boostDb);
  boostRef.current = boostDb > 0 || prefs.autoLevel;
  useEffect(() => {
    setBoostDb(boostDb);
    setAutoLevel(prefs.autoLevel);
    // Only route through Web Audio once something needs it (boost or auto volume).
    if (boostDb > 0 || prefs.autoLevel) routePlayer(videoRef.current);
  }, [boostDb, prefs.autoLevel]);
  // Auto volume learns each show's loudness and remembers it.
  const levelKey = currentRec?.show || null;
  useEffect(() => {
    setLevelKey(levelKey, levelKey ? prefs.loudness[levelKey] : undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [levelKey]);
  useEffect(() => {
    onLoudness((key, db) => update((p) => ({ loudness: { ...p.loudness, [key]: db } })));
  }, [update]);

  useEffect(() => {
    const unlock = () =>
      unlockAudio().then((ok) => {
        if (ok && boostRef.current) routePlayer(videoRef.current);
      });
    unlock();
    const onVisible = () => document.visibilityState === "visible" && unlock();
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("keydown", unlock);
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);

  const changeVolume = (delta) => {
    update((p) => ({ volume: clamp01(p.volume + delta), muted: false }));
    flashVol(2200);
  };
  const toggleMute = () => {
    update((p) => ({ muted: !p.muted }));
    flashVol(2200);
  };
  const setShowBoost = useStableCallback((show, db) => update((p) => ({ boost: { ...p.boost, [show]: db } })));

  // --- Channel changes: static + channel number ---------------------------------
  const endSwitch = useStableCallback(() => {
    setSwitching(false);
    stopStatic();
    flashBug(3000);
    if (tv) flashInfo(5000);
  });

  useEffect(() => {
    if (!switching) return undefined;
    const s = switchRef.current;
    const elapsed = performance.now() - s.at;
    const ready = (srcSeq > s.seq && (hasFrame || Boolean(loadProblem) || !src)) || Boolean(bumper);
    // At least 0.7 s of snow so it reads as a channel change; never more than 8 s.
    const t = setTimeout(endSwitch, Math.max(0, (ready ? 700 : 8000) - elapsed));
    const hiss = setTimeout(stopStatic, Math.max(0, 2500 - elapsed));
    return () => {
      clearTimeout(t);
      clearTimeout(hiss);
    };
  }, [switching, srcSeq, hasFrame, loadProblem, src, endSwitch, bumper]);

  const prevChannelRef = useRef(null);
  const changeChannel = (next) => {
    if (!next) return;
    queueRef.current = null;
    if (channel && next.id !== channel.id) prevChannelRef.current = channel;
    if (next.id === channel?.id) {
      flashBug(3500);
      if (tv) flashInfo(5000);
      return;
    }
    if (prefs.staticOnSwitch) {
      switchRef.current = { at: performance.now(), seq: srcSeqRef.current };
      setSwitching(true);
      videoRef.current?.pause();
      if (prefs.staticSound && !prefs.muted) startStatic(prefs.volume);
    } else if (tv) {
      flashInfo(5000);
    }
    hideTouch();
    flashBug(prefs.staticOnSwitch ? 8000 : 4000);
    setChannel(next);
  };

  const lastChannel = () => {
    const prev = prevChannelRef.current && channels.find((c) => c.id === prevChannelRef.current.id);
    if (prev) changeChannel(prev);
    else flashBug(2500);
  };

  // --- Typing a channel number -------------------------------------------------
  const [entry, setEntry] = useState(null); // { digits, missing }
  const entryRef = useRef({ digits: "", timer: null });
  const commitEntry = useStableCallback((digits) => {
    clearTimeout(entryRef.current.timer);
    entryRef.current.digits = "";
    const c = channels.find((x) => x.number === Number(digits));
    if (c) {
      setEntry(null);
      changeChannel(c);
    } else {
      setEntry({ digits: pad2(Number(digits)), missing: true });
      entryRef.current.timer = setTimeout(() => setEntry(null), 1800);
    }
  });
  const typeDigit = (d) => {
    const e = entryRef.current;
    clearTimeout(e.timer);
    e.digits = (e.digits + d).slice(-3);
    const digits = e.digits;
    setEntry({ digits, missing: false });
    hideBug();
    const key = String(Number(digits));
    // Wait for more digits only while a longer channel number could still match.
    const wait = /^0+$/.test(digits) || (!digits.startsWith("0") && channels.some((c) => String(c.number).length > key.length && String(c.number).startsWith(key)));
    if (!wait || digits.length >= 3) commitEntry(digits);
    else e.timer = setTimeout(() => commitEntry(digits), 1600);
  };
  useEffect(() => () => clearTimeout(entryRef.current.timer), []);

  const stepChannel = (dir) => {
    if (!channels.length) {
      flashInfo(4000);
      return;
    }
    // Favourites only (when set and there are some), always keeping the current channel in the list.
    const favs = prefs.surfFavs ? channels.filter((c) => c.fav || c.id === channel?.id) : [];
    const list = favs.filter((c) => c.fav).length ? favs : channels;
    const i = list.findIndex((c) => c.id === channel?.id);
    const n = list.length;
    const j = i === -1 ? (dir > 0 ? 0 : n - 1) : (i + dir + n) % n;
    changeChannel(list[j]);
  };

  // --- Menu: open / close / tabs / focus -----------------------------------------
  const contentEl = () => document.querySelector("[data-menu-panel] [data-menu-content]");
  const focusContent = () => {
    const content = contentEl();
    if (content && focusFirst(content)) return;
    focusEl(document.querySelector('[data-menu-panel] [role="tab"][aria-selected="true"]'));
  };
  const restoreFocus = () => {
    const panel = document.querySelector("[data-menu-panel]");
    const last = lastFocusRef.current;
    if (panel && last?.isConnected && panel.contains(last) && getFocusables(panel).includes(last)) focusEl(last);
    else focusContent();
  };

  const openMenu = (toTab) => {
    setNavMode("menu");
    if (tv) setMenuOpen(true);
    hideInfo();
    hideTouch();
    if (toTab && toTab !== tab) {
      setTab(toTab);
      update({ lastTab: toTab });
      afterRender(focusContent);
    } else afterRender(restoreFocus);
  };
  const closeMenu = () => {
    setNavMode("watch");
    setMenuOpen(false);
    if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur();
  };

  const switchTab = (id, focusTo = "content") => {
    setTab(id);
    update({ lastTab: id });
    afterRender(() =>
      focusTo === "tab" ? focusEl(document.querySelector(`[data-menu-panel] [data-tab="${id}"]`)) : focusContent()
    );
  };
  const cycleTab = (dir, focusTo) => {
    const i = TABS.findIndex((t) => t.id === tab);
    switchTab(TABS[(i + dir + TABS.length) % TABS.length].id, focusTo);
  };

  // Remember where focus was in the menu, and treat focusing it as "using the menu".
  useEffect(() => {
    const onFocusIn = (e) => {
      if (e.target?.closest?.("[data-menu-panel]")) {
        lastFocusRef.current = e.target;
        setNavMode("menu");
      }
    };
    const onPointer = () => document.documentElement.removeAttribute("data-nav-active");
    document.addEventListener("focusin", onFocusIn);
    window.addEventListener("pointerdown", onPointer, true);
    return () => {
      document.removeEventListener("focusin", onFocusIn);
      window.removeEventListener("pointerdown", onPointer, true);
    };
  }, []);

  // Leaving the channel editor puts focus back on that channel's row.
  const prevEditingRef = useRef(editing);
  useEffect(() => {
    const prev = prevEditingRef.current;
    prevEditingRef.current = editing;
    if (prev && !editing && navMode === "menu") {
      afterRender(() => {
        const key = prev === "new" ? "new-channel" : `ch:${prev.id}`;
        const el = document.querySelector(`[data-nav-key="${channel && prev === "new" ? `ch:${channel.id}` : key}"]`);
        if (el) focusEl(el);
        else focusContent();
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing]);

  // Same for leaving a show's page in Library.
  const openShow = useStableCallback((key) => {
    const prev = libShow;
    setLibShow(key);
    if (!key && prev) afterRender(() => focusEl(document.querySelector(`[data-nav-key="show:${CSS.escape(prev)}"]`)) || focusContent());
  });

  // --- Sleep timer ------------------------------------------------------------------
  // When it runs out: sound and picture fade, playback stops, and in the app it
  // closes itself (the screen-on hold goes with it) so the device sleeps.
  const [sleepPhase, setSleepPhase] = useState(null); // null | "fading" | "asleep"
  const sleepRef = useRef({ channel: null, timer: null });
  const fallAsleep = useStableCallback(async () => {
    // The picture shrinks to a dot first, like switching an old set off.
    if (prefs.crt.powerFx !== false) {
      setPower("off");
      await new Promise((r) => setTimeout(r, 1100));
    }
    sleepRef.current.channel = channel;
    stopStatic();
    stopTone();
    setChannel(null);
    clearPicture("Asleep");
    setSleepPhase("asleep");
    if (isNative()) {
      try {
        const { MediaFolder } = await import("@/native/mediaFolder");
        await MediaFolder.setKeepAwake({ enabled: false });
      } catch {
        // older app build
      }
      try {
        const { App } = await import("@capacitor/app");
        await App.exitApp();
      } catch {
        // stays on the Goodnight screen
      }
    }
  });
  const goToSleep = useStableCallback(() => {
    closeMenu();
    setSleepPhase("fading");
    const v = videoRef.current;
    const from = v ? v.volume : 0;
    const t0 = Date.now();
    clearInterval(sleepRef.current.timer);
    sleepRef.current.timer = setInterval(() => {
      const k = Math.min(1, (Date.now() - t0) / SLEEP_FADE_MS);
      if (v) v.volume = from * (1 - k);
      setToneVolume(prefs.volume * (1 - k));
      if (k >= 1) {
        clearInterval(sleepRef.current.timer);
        fallAsleep();
      }
    }, 100);
  });
  const wake = () => {
    clearInterval(sleepRef.current.timer);
    const v = videoRef.current;
    if (v) v.volume = prefs.volume;
    setToneVolume(prefs.volume);
    const was = sleepPhase;
    setSleepPhase(null);
    setPower("on");
    if (was === "asleep" && sleepRef.current.channel) changeChannel(sleepRef.current.channel);
    else if (was === "fading") showTag("Sleep cancelled");
  };
  useEffect(() => () => clearInterval(sleepRef.current.timer), []);
  const sleep = useSleepTimer(goToSleep);
  const setSleepMinutes = sleep.setMinutes;
  // Troubleshooting on a device (DevTools console): __rvSleepIn(seconds).
  useEffect(() => {
    window.__rvSleepIn = (secs) => setSleepMinutes(secs / 60);
  }, [setSleepMinutes]);
  const cycleSleep = () => {
    const m = sleep.cycle();
    showTag(m ? `Sleep ${m}` : "Sleep off", 3000);
  };
  const sleepSoon = sleep.remaining > 0 && sleep.remaining <= 60000;

  // --- Picture-in-picture (Android app, Home button while watching) ----------------
  const [pip, setPip] = useState(false);
  const enterPip = useStableCallback((active) => {
    setPip(active);
    if (active) {
      closeMenu();
      hideBug();
      hideVol();
      hideInfo();
      hideTouch();
    }
  });
  useEffect(() => {
    const on = (e) => enterPip(Boolean(e?.active ?? e?.detail?.active));
    window.addEventListener("rv-pip", on);
    return () => window.removeEventListener("rv-pip", on);
  }, [enterPip]);

  // --- Episode titles (TVmaze) ------------------------------------------------------
  useEpisodeInfo();
  useEffect(() => setEpisodeInfoEnabled(prefs.episodeInfo), [prefs.episodeInfo]);
  // Ad, ident and promo folders aren't shows to look up.
  const infoShows = useMemo(() => {
    const skip = new Set(channels.flatMap((c) => [...(c.adShows || []), c.identShow, c.promoShow]).filter(Boolean));
    return shows.filter((x) => !skip.has(x));
  }, [shows, channels]);
  const infoKey = infoShows.join("\u0000");
  useEffect(() => {
    if (!prefs.episodeInfo || !infoShows.length) return undefined;
    const t = setTimeout(() => syncEpisodeInfo(infoShows, prefs.showMatch), 2500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefs.episodeInfo, infoKey, online]);
  const onRefreshInfo = useStableCallback(() => syncEpisodeInfo(infoShows, prefs.showMatch, { force: true }));
  const onMatchShow = useStableCallback((show, id) => {
    const match = { ...prefs.showMatch, [show]: id };
    update({ showMatch: match });
    syncEpisodeInfo(infoShows.includes(show) ? infoShows : [...infoShows, show], match, { force: true, only: show });
  });

  // --- Rescan linked folders (Android app) -----------------------------------------
  const [rescanStatus, setRescanStatus] = useState("");
  const handleRescan = async () => {
    if (!(await hasNative("rescanFolder"))) {
      setRescanStatus("This version of the app can't rescan. Update the app, or link the folder again.");
      return;
    }
    const { MediaFolder, linkedTrees } = await import("@/native/mediaFolder");
    const trees = linkedTrees(rawLibrary);
    const known = new Map(rawLibrary.filter((m) => m.uri).map((m) => [m.uri, m]));
    let added = 0;
    let subs = 0;
    let lost = 0;
    setRescanStatus("");
    setImporting({ done: 0, total: trees.length });
    for (let i = 0; i < trees.length; i++) {
      try {
        const { rootName, files, subtitles = [] } = await MediaFolder.rescanFolder({ treeUri: trees[i] });
        const fresh = [];
        for (const file of files) {
          const subtitleUri = matchSubtitle(file, subtitles)?.uri;
          const old = known.get(file.uri);
          if (!old) fresh.push({ native: { ...file, subtitleUri }, ...pathInfo(rootName, file.parts || []) });
          else if (subtitleUri && old.subtitleUri !== subtitleUri) {
            await updateMedia({ ...old, subtitleUri });
            subs++;
          }
        }
        const records = [];
        for (const f of fresh) {
          try {
            records.push(await describeHandle(f));
          } catch {
            // unreadable file: skip it
          }
        }
        if (records.length) await addLinkedMediaBatch(records);
        added += records.length;
      } catch {
        lost++;
      }
      setImporting({ done: i + 1, total: trees.length });
    }
    setImporting(null);
    setLibrary(await listMedia());
    setRescanStatus(
      [
        added ? `${added} new ${added === 1 ? "file" : "files"}` : "No new files",
        subs ? `${subs} with new captions` : "",
        lost ? `${lost} ${lost === 1 ? "folder" : "folders"} need linking again` : "",
      ]
        .filter(Boolean)
        .join(" · ")
    );
  };
  const onRescan = useStableCallback(handleRescan);
  const canRescan = isNative() && rawLibrary.some((m) => m.uri);

  // --- Back (controller B, Escape, Android back) ----------------------------------
  const goBack = () => {
    // Some controllers send B both as a button and as Android "back": handle it once.
    if (Date.now() - lastBackRef.current < 400) return true;
    let handled = false;
    if (sleepPhase) {
      wake();
      handled = true;
    } else if (tt && navMode !== "menu") {
      setTt(null);
      handled = true;
    } else if (navMode === "menu") {
      if (!backStack.run()) closeMenu();
      handled = true;
    } else if (document.querySelector("[data-nav-modal]") && backStack.run()) {
      handled = true;
    } else if (entry) {
      clearTimeout(entryRef.current.timer);
      entryRef.current.digits = "";
      setEntry(null);
      handled = true;
    } else if (bugOn || volOn || infoOn || touchOn || tagOn) {
      hideTag();
      hideBug();
      hideVol();
      hideInfo();
      hideTouch();
      handled = true;
    }
    if (handled) lastBackRef.current = Date.now();
    return handled;
  };
  const goBackStable = useStableCallback(goBack);
  const powerFxRef = useRef(true);
  powerFxRef.current = prefs.crt.powerFx !== false;
  // Coming back to the app switches the picture on again.
  useEffect(() => {
    const on = () => document.visibilityState === "visible" && setPower("on");
    document.addEventListener("visibilitychange", on);
    return () => document.removeEventListener("visibilitychange", on);
  }, []);
  useEffect(() => {
    const onBack = (e) => {
      if (goBackStable()) {
        e.preventDefault();
        return;
      }
      // Leaving the app: switch the picture off first.
      if (isNative() && powerFxRef.current) {
        e.preventDefault();
        setPower("off");
        setTimeout(() => import("@capacitor/app").then(({ App }) => App.minimizeApp()).catch(() => {}), 900);
      }
    };
    window.addEventListener("native-back", onBack);
    return () => window.removeEventListener("native-back", onBack);
  }, [goBackStable]);

  // --- Controller / keyboard -------------------------------------------------------
  const togglePlay = () => {
    const v = videoRef.current;
    if (channel) {
      // Pause live TV: the channel waits, then carries on from where you stopped.
      if (livePause) {
        setShift((x) => Math.min(6 * 3600e3, x + (Date.now() - livePause)));
        setLivePause(null);
      } else {
        v?.pause();
        setLivePause(Date.now());
      }
      flashInfo(3000);
      return;
    }
    if (!v?.src) return;
    if (v.paused) v.play().catch(() => {});
    else v.pause();
    flashInfo(3000);
  };
  const startOver = () => {
    if (!channel || !nn?.now) return;
    const paused = livePause ? Date.now() - livePause : 0;
    setLivePause(null);
    // Back to the start of what's on (with its "coming up next" card).
    setShift((x) => Math.max(0, x + paused + (Date.now() - x - paused - nn.now.startMs)));
    showTag("Start over");
    flashInfo(4000);
  };
  const goLive = () => {
    if (!channel) return;
    setShift(0);
    setLivePause(null);
    showTag("Live");
  };
  const nudgeShift = (secs) => {
    if (!channel) return;
    const paused = livePause ? Date.now() - livePause : 0;
    setLivePause(null);
    setShift((x) => {
      const next = Math.min(6 * 3600e3, Math.max(0, x + paused + secs * 1000));
      return next < 2000 ? 0 : next;
    });
    flashInfo(2500);
  };
  const seek = (s) => {
    const v = videoRef.current;
    if (!v || channel || !isFinite(v.duration)) return;
    v.currentTime = Math.min(v.duration, Math.max(0, v.currentTime + s));
    flashInfo(2500);
  };

  const watchAction = (action, info) => {
    switch (action) {
      case "up":
      case "r1":
        stepChannel(1);
        return true;
      case "down":
      case "l1":
        stepChannel(-1);
        return true;
      case "left":
        changeVolume(-0.05);
        return true;
      case "right":
        changeVolume(0.05);
        return true;
      case "a":
        if (lock) {
          askUnlock();
          return true;
        }
        // A TV remote has no Start button, so its OK opens the menu. With a
        // controller connected, OK/Enter is the controller's A: play/pause.
        if (info?.source === "key" && !pad.connected) openMenu();
        else togglePlay();
        return true;
      case "play":
        togglePlay();
        return true;
      case "x":
        toggleMute();
        return true;
      case "y":
        // Toggle what's actually on screen (the volume bar hides the banner).
        if (infoOn && !volOn && !touchOn) hideInfo();
        else {
          hideVol();
          hideTouch();
          flashInfo(6000);
        }
        return true;
      case "l2":
        if (channel || !src) lastChannel();
        else seek(-10);
        return true;
      case "r2":
        if (channel || !src) cycleSleep();
        else seek(10);
        return true;
      case "last":
        lastChannel();
        return true;
      case "sleep":
        cycleSleep();
        return true;
      case "captions":
        toggleCaptions();
        return true;
      case "startover":
        startOver();
        return true;
      case "live":
        goLive();
        return true;
      case "rew":
        if (channel) nudgeShift(30);
        else seek(-10);
        return true;
      case "ff":
        if (channel) nudgeShift(-30);
        else seek(10);
        return true;
      case "text":
        openText();
        return true;
      case "start":
        openMenu();
        return true;
      case "select":
        openMenu("guide");
        return true;
      default:
        if (/^d\d$/.test(action)) {
          typeDigit(action.slice(1));
          return true;
        }
        return false;
    }
  };

  const menuAction = (action, info) => {
    const scope = activeScope();
    const el = document.activeElement;
    const inScope = el && el !== document.body && scope.contains(el);
    const modal = scope.hasAttribute("data-nav-modal");
    switch (action) {
      case "up":
      case "down":
      case "left":
      case "right": {
        const horizontal = action === "left" || action === "right";
        const dir = action === "left" ? -1 : 1;
        if (horizontal && inScope && isTab(el)) {
          cycleTab(dir, "tab");
          return true;
        }
        if (horizontal && inScope && isAdjustable(el)) {
          adjust(el, dir);
          return true;
        }
        const moved = moveFocus(action, scope);
        // Coming up into the tab bar lands on the open tab, not whichever is nearest.
        if (moved && !modal && isTab(document.activeElement) && !isTab(el)) {
          focusEl(scope.querySelector('[role="tab"][aria-selected="true"]'));
        }
        // Nothing further that way: let the screen react (the guide pages its time window).
        if (!moved && inScope) el.dispatchEvent(new CustomEvent("nav-edge", { detail: action, bubbles: true }));
        return true;
      }
      case "a":
        // Keyboards click the focused button themselves; controllers and the phone remote don't.
        if (info.source === "pad" || info.remote || !inScope) {
          if (inScope) el.click();
          else focusFirst(scope);
        }
        return true;
      case "l1":
      case "r1":
        if (!modal) cycleTab(action === "r1" ? 1 : -1);
        return true;
      case "l2":
      case "r2":
        for (let i = 0; i < 6; i++) if (!moveFocus(action === "r2" ? "down" : "up", scope)) break;
        return true;
      case "start":
      case "select":
        if (!modal) closeMenu();
        return true;
      case "x":
        toggleMute();
        return true;
      case "play":
        togglePlay();
        return true;
      default:
        return false;
    }
  };

  // Teletext keys: numbers pick a page, Up/Down flip pages, Left/Right the
  // sub-pages, the coloured keys jump, A mixes it over the picture.
  const openText = () => {
    closeMenu();
    hideInfo();
    hideBug();
    setTt({ page: 100, sub: 0, typed: "", mix: false });
  };
  const textGo = (page) => {
    if (page === 801) {
      setTt(null);
      toggleCaptions();
      return;
    }
    setTt((x) => ({ ...x, page, sub: 0, typed: "" }));
  };
  const textAction = (action) => {
    const pages = TEXT_PAGES(channels.length);
    const i = pages.indexOf(tt.page);
    if (/^d\d$/.test(action)) {
      const typed = `${tt.typed}${action.slice(1)}`;
      if (typed.length >= 3) textGo(Number(typed));
      else setTt({ ...tt, typed });
      return true;
    }
    switch (action) {
      case "up":
      case "r1":
        textGo(pages[(i + 1 + pages.length) % pages.length] || 100);
        return true;
      case "down":
      case "l1":
        textGo(pages[(i - 1 + pages.length) % pages.length] || 100);
        return true;
      case "right":
        setTt({ ...tt, sub: tt.sub + 1 });
        return true;
      case "left":
        setTt({ ...tt, sub: Math.max(0, tt.sub - 1) });
        return true;
      case "a":
      case "y":
        setTt({ ...tt, mix: !tt.mix });
        return true;
      case "red":
      case "green":
      case "yellow":
      case "blue":
        textGo(FASTEXT[["red", "green", "yellow", "blue"].indexOf(action)].page);
        return true;
      case "text":
        setTt(null);
        return true;
      case "start":
        setTt(null);
        openMenu();
        return true;
      case "select":
        setTt(null);
        openMenu("guide");
        return true;
      case "x":
        toggleMute();
        return true;
      default:
        return true;
    }
  };

  const handleAction = (action, info) => {
    if (info.source === "pad" || action !== "a") document.documentElement.setAttribute("data-nav-active", "");
    // Phone remote extras that always mean the same thing.
    if (action === "volup" || action === "voldown") {
      if (sleepPhase) wake();
      changeVolume(action === "volup" ? 0.05 : -0.05);
      return true;
    }
    if (action === "chup" || action === "chdown") {
      if (sleepPhase) wake();
      setTt(null);
      stepChannel(action === "chup" ? 1 : -1);
      return true;
    }
    if (action === "b") return goBack();
    // Any button wakes it from the sleep timer (and cancels the fade).
    if (sleepPhase) {
      wake();
      return true;
    }
    // A pop-up (PIN pad...) opened while watching takes the controls.
    const modal = Boolean(document.querySelector("[data-nav-modal]"));
    const inMenu = modal || (navMode === "menu" && (!tv || menuOpen));
    if (tt && !inMenu) return textAction(action);
    return inMenu ? menuAction(action, info) : watchAction(action, info);
  };
  const pad = useControls(handleAction);
  const handleActionStable = useStableCallback(handleAction);

  // --- Phone remote (Android app) ------------------------------------------------
  const [remoteInfo, setRemoteInfo] = useState(null);
  useEffect(() => {
    if (!isNative()) return undefined;
    let alive = true;
    (async () => {
      if (!(await hasNative("remote"))) return;
      const { MediaFolder } = await import("@/native/mediaFolder");
      try {
        const info = prefs.remoteOn ? await MediaFolder.startRemote({ html: remotePageHtml() }) : await MediaFolder.stopRemote();
        if (alive) setRemoteInfo(info);
      } catch (e) {
        if (alive) setRemoteInfo({ running: false, error: String(e?.message || e) });
      }
    })();
    return () => {
      alive = false;
    };
  }, [prefs.remoteOn]);
  useEffect(() => {
    const on = (e) => {
      const action = REMOTE_KEYS[e?.k];
      if (action) handleActionStable(action, { source: "key", repeat: false, remote: true });
    };
    window.addEventListener("rv-remote", on);
    return () => window.removeEventListener("rv-remote", on);
  }, [handleActionStable]);
  // What the phone shows: channel, what's on, volume.
  const remoteState = JSON.stringify({
    ok: true,
    channel: channel ? { number: channel.number, name: channel.name } : null,
    now: channel && nn ? programmeTitle(nn.now) : label,
    next: channel && nn?.next ? programmeTitle(nn.next) : "",
    volume: Math.round(prefs.volume * 100),
    muted: prefs.muted,
    sleep: sleep.remaining ? formatClock(sleep.remaining / 1000) : "",
  });
  useEffect(() => {
    if (!remoteInfo?.running) return;
    import("@/native/mediaFolder").then(({ MediaFolder }) => MediaFolder.setRemoteState({ json: remoteState })).catch(() => {});
  }, [remoteState, remoteInfo?.running]);
  const onNewRemoteCode = useStableCallback(async () => {
    const { MediaFolder } = await import("@/native/mediaFolder");
    setRemoteInfo(await MediaFolder.newRemoteCode());
  });

  // --- Wake timer: the app was opened by it, so tune the chosen channel -----------
  const wakeTo = useStableCallback((number) => {
    const c = channels.find((x) => x.number === Number(number));
    if (!c) return;
    setSleepPhase(null);
    setPower("on");
    setTt(null);
    closeMenu();
    changeChannel(c);
  });
  useEffect(() => {
    if (!isNative() || !channels.length) return undefined;
    const take = () =>
      import("@/native/mediaFolder")
        .then(({ MediaFolder }) => MediaFolder.takeWake())
        .then((r) => r?.channel != null && wakeTo(r.channel))
        .catch(() => {});
    take();
    const on = () => take();
    window.addEventListener("rv-wake", on);
    return () => window.removeEventListener("rv-wake", on);
  }, [channels.length > 0]); // eslint-disable-line react-hooks/exhaustive-deps

  // --- Library actions ----------------------------------------------------------
  const handleAdd = async (files) => {
    const playable = files.filter((f) => /^(video|audio)\//.test(f.type));
    if (!playable.length) return;
    const saved = new Array(playable.length);
    let next = 0;
    let done = 0;
    setImporting({ done: 0, total: playable.length });
    const worker = async () => {
      while (next < playable.length) {
        const i = next++;
        saved[i] = await addMedia(playable[i], parsePath(playable[i]));
        setImporting({ done: ++done, total: playable.length });
      }
    };
    await Promise.all(Array.from({ length: Math.min(4, playable.length) }, worker));
    setImporting(null);
    setLibrary(await listMedia());
    if (playable.length === 1) {
      setChannel(null);
      queueRef.current = null;
      playBlob(saved[0].blob, saved[0].name, saved[0].id, saved[0].type);
    }
  };

  // Link a folder in place: no copying, only file handles + durations are saved.
  const handleLink = async () => {
    let found;
    try {
      found = await pickLinkedFolder();
    } catch {
      return; // picker cancelled
    }
    if (!found.length) return;
    const records = new Array(found.length);
    let next = 0;
    let done = 0;
    setImporting({ done: 0, total: found.length });
    const worker = async () => {
      while (next < found.length) {
        const i = next++;
        try {
          records[i] = await describeHandle(found[i]);
        } catch {
          records[i] = null;
        }
        setImporting({ done: ++done, total: found.length });
      }
    };
    await Promise.all(Array.from({ length: Math.min(8, found.length) }, worker));
    await addLinkedMediaBatch(records.filter(Boolean));
    setImporting(null);
    setLibrary(await listMedia());
  };

  const handleRemoveMany = async (list) => {
    for (const m of list) await removeMedia(m.id);
    setLibrary(await listMedia());
    if (!channel && list.some((m) => m.id === activeId)) {
      queueRef.current = null;
      clearPicture();
    }
  };

  const playFile = (m, list) => {
    setChannel(null);
    const index = list ? list.indexOf(m) : -1;
    queueRef.current = index >= 0 ? { list, index } : null;
    playBlob(m, m.name, m.id, m.type);
    if (tv) closeMenu();
    else revealScreen();
  };

  const onAddFiles = useStableCallback(handleAdd);
  const onLinkFolder = useStableCallback(handleLink);
  const onRemoveMedia = useStableCallback((m) => handleRemoveMany([m]));
  const onRemoveMany = useStableCallback(handleRemoveMany);
  const onPlayMedia = useStableCallback((m, list) => playFile(m, list));
  const onPlayList = useStableCallback((list) => list.length && playFile(list[0], list));
  const onQuickPlay = useStableCallback((file) => {
    setChannel(null);
    queueRef.current = null;
    playBlob(file, file.name, null, file.type);
    if (tv) closeMenu();
  });
  const onPicture = useCallback((crt) => update({ crt }), [update]);
  const onBroadcast = useCallback((broadcast) => update({ broadcast }), [update]);
  const setShowRating = useStableCallback((show, r) => update((p) => ({ ratings: { ...p.ratings, [show]: r } })));
  const setShowAutoBreaks = useStableCallback((show, n) => update((p) => ({ autoBreaks: { ...p.autoBreaks, [show]: n } })));

  // On a phone the list can be scrolled far below the screen: bring the picture back into view.
  const revealScreen = () => {
    const el = stageRef.current;
    if (!tv && el && el.getBoundingClientRect().bottom < 80) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  // --- Channel actions ----------------------------------------------------------
  const tuneTo = async (c) => {
    // Tapping a channel is a user gesture, so re-grant access to linked folders here.
    const linked = library.find((m) => m.handle);
    if (linked) await getPlayable(linked);
    changeChannel(c);
    if (tv) closeMenu();
    else revealScreen();
  };

  const handleSaveChannel = async (data) => {
    const saved = await saveChannel(data);
    const list = await listChannels();
    setChannels(list);
    const fresh = list.find((c) => c.id === saved.id) || saved;
    if (channel?.id === fresh.id) setChannel(fresh);
    else changeChannel(fresh);
    setEditing(null);
  };

  // --- Favourites, reshuffle, start fresh, resets ------------------------------------
  const onToggleFav = useStableCallback(async (c) => {
    const saved = await saveChannel({ ...c, fav: !c.fav });
    setChannels(await listChannels());
    if (channel?.id === saved.id) setChannel(saved);
    afterRender(() => focusEl(document.querySelector(`[data-nav-key="ch:${c.id}"]`)?.parentElement?.querySelector("[aria-pressed]")));
  });
  // A new mix on every channel: playlists get fresh lineups (shows spread evenly),
  // blocks and timetables new random picks.
  const rebuildChannels = async (lib, { reshuffle = true } = {}) => {
    const list = await listChannels();
    for (const c of list) {
      const seed = reshuffle ? newSeed() : c.seed;
      const playlist = !c.blocks?.length && !c.timetable && !c.weather;
      await saveChannel({ ...c, seed, lineup: playlist ? generateLineup({ ...c, seed }, lib) : c.lineup });
    }
    const fresh = await listChannels();
    setChannels(fresh);
    if (channel) setChannel(fresh.find((c) => c.id === channel.id) || null);
    return fresh.length;
  };
  const onReshuffleAll = useStableCallback(async () => {
    const n = await rebuildChannels(library);
    showTag(`Reshuffled ${n} channels`);
  });
  // Start fresh: forget every show, link one folder, rebuild the channels from it.
  const onStartFresh = useStableCallback(async (keepChannels) => {
    let found;
    try {
      found = await pickLinkedFolder();
    } catch {
      return "cancelled";
    }
    if (!found.length) return "That folder has no videos in it";
    setChannel(null);
    clearPicture();
    queueRef.current = null;
    await clearMedia();
    if (!keepChannels) await clearChannels();
    const records = new Array(found.length);
    let next = 0;
    let done = 0;
    setImporting({ done: 0, total: found.length });
    const worker = async () => {
      while (next < found.length) {
        const i = next++;
        try {
          records[i] = await describeHandle(found[i]);
        } catch {
          records[i] = null;
        }
        setImporting({ done: ++done, total: found.length });
      }
    };
    await Promise.all(Array.from({ length: Math.min(8, found.length) }, worker));
    await addLinkedMediaBatch(records.filter(Boolean));
    const lib = await listMedia();
    setLibrary(lib);
    const n = await rebuildChannels(lib);
    setImporting(null);
    return `Added ${lib.length} files${keepChannels ? `, rebuilt ${n} channels` : ""}`;
  });
  const onResetSettings = useStableCallback(() => {
    replacePrefs({ parental: prefs.parental });
    window.location.reload();
  });
  const onEraseAll = useStableCallback(async () => {
    await clearMedia();
    await clearChannels();
    replacePrefs({});
    replaceBreaks({});
    await clearEpisodeInfo();
    try {
      window.localStorage.removeItem("retrovision.weather.v1");
    } catch {
      // ignore
    }
    window.location.reload();
  });

  // --- Reminders -----------------------------------------------------------------
  const reminders = prefs.reminders || [];
  const onRemind = useStableCallback((c, p) => {
    const key = `${c.id}|${p.startMs}`;
    update((pr) => {
      const list = pr.reminders || [];
      const has = list.some((r) => `${r.channelId}|${r.startMs}` === key);
      return {
        reminders: has
          ? list.filter((r) => `${r.channelId}|${r.startMs}` !== key)
          : [...list, { id: key, channelId: c.id, channelName: c.name, number: c.number, title: programmeTitle(p), startMs: p.startMs }],
      };
    });
    showTag(reminders.some((r) => `${r.channelId}|${r.startMs}` === key) ? "Reminder off" : "Reminder set");
  });
  const [dueReminder, setDueReminder] = useState(null);
  useEffect(() => {
    const check = () => {
      const now = Date.now();
      const list = prefs.reminders || [];
      const stale = list.filter((r) => r.startMs < now - 10 * 60000);
      if (stale.length) update((pr) => ({ reminders: (pr.reminders || []).filter((r) => r.startMs >= now - 10 * 60000) }));
      if (dueReminder) return;
      const due = list.find((r) => r.startMs - now <= 30000 && r.startMs - now > -5 * 60000 && !r.shown);
      if (due) {
        setDueReminder(due);
        update((pr) => ({ reminders: (pr.reminders || []).map((r) => (r.id === due.id ? { ...r, shown: true } : r)) }));
        if (!prefs.muted) playChime(prefs.volume, "next");
      }
    };
    check();
    const t = setInterval(check, 5000);
    return () => clearInterval(t);
  }, [prefs.reminders, dueReminder, prefs.muted, prefs.volume, update]);
  const watchReminder = () => {
    const r = dueReminder;
    setDueReminder(null);
    const c = channels.find((x) => x.id === r.channelId);
    if (c) {
      setTt(null);
      closeMenu();
      changeChannel(c);
    }
  };

  // Editing a locked channel needs the PIN (otherwise it could just be unlocked).
  const editChannel = useStableCallback((c) => {
    if (c && c !== "new" && channelLocked(c)) {
      setPinAsk({
        title: "Locked channel",
        subtitle: `Enter the PIN to edit ${c.name}`,
        then: () => {
          setUnlocked((u) => new Set(u).add(`ch:${c.id}`));
          setEditing(c);
        },
      });
    } else setEditing(c);
  });

  const handleDeleteChannel = async (c) => {
    await removeChannel(c.id);
    setChannels(await listChannels());
    setEditing(null);
    if (channel?.id === c.id) {
      setChannel(null);
      clearPicture();
    }
  };

  // --- Pointer on the picture ---------------------------------------------------
  const onStagePointer = () => {
    if (sleepPhase) {
      wake();
      return;
    }
    if (tt) {
      setTt(null);
      return;
    }
    if (lock && !menuOpen) {
      askUnlock();
      return;
    }
    if (tv) {
      if (menuOpen) closeMenu();
      else flashTouch(4500);
    } else if (navMode === "menu") {
      closeMenu();
    }
  };

  // --- The CRT tube for the menus and on-screen displays (TubeFilter). In TV
  // layout the guide fills the screen and CRTPlayer draws the picture into its
  // corner box itself, so the two always line up.
  const tube = useTube(screenRef, prefs.crt, !lowPower);
  const tubeStyle = tube.filter ? { "--rv-tube": tube.filter } : undefined;

  // --- Render -------------------------------------------------------------------
  const showHints = tv || pad.connected;
  const playingShow = currentRec ? currentRec.show || LOOSE : null;
  const staticLevel = switching ? 1 : !src && !bumper ? 0.45 : 0;
  const nowMs = Date.now();
  // Tuned in part way through: offer to start it over (or say how far behind live).
  const into = channel && nn?.now?.media ? nowMs - shift - nn.now.startMs : 0;
  const startOverNote = !channel
    ? null
    : livePause
      ? `Paused · ${pad.connected ? "A" : "Play"} to carry on`
      : shift > 1500
        ? `${formatClock(shift / 1000)} behind live · ${pad.connected ? "R3" : "⏭"} back to live`
        : into > 180000
          ? `Started ${Math.round(into / 60000)} min ago · ${pad.connected ? "L3" : "R / ⏮"} to start over`
          : null;

  let message = null;
  if (bumper) message = null;
  else if (switching) message = loadProblem ? <ScreenMessage>{loadProblem}</ScreenMessage> : null;
  else if (!src)
    message = (
      <ScreenMessage>
        {channel ? "No episodes on this channel" : "No signal"}
        {!channel && (
          <span className="mt-1 block text-[0.6em] opacity-80">
            {!tv ? "Pick a channel or a show below" : pad.connected ? "Press Start for the menu" : "Press OK or tap for the menu"}
          </span>
        )}
      </ScreenMessage>
    );
  else if (!hasFrame) message = <ScreenMessage>{loadProblem || "Loading signal…"}</ScreenMessage>;
  else if (isAudio && !musicWeather) message = <ScreenMessage>♪ {label}</ScreenMessage>;
  if (tt) message = null;

  const tabContent = {
    guide: (
      <GuideTab
        channels={channels}
        media={library}
        activeId={channel?.id}
        onTune={tuneTo}
        pig={guideFull}
        onPig={closeMenu}
        wide={tv || wide}
        isLocked={channelLocked}
        reminders={reminders}
        onRemind={onRemind}
        onOpenText={openText}
        favsOnly={Boolean(prefs.guideFavs)}
        onFavsOnly={(v) => update({ guideFavs: v })}
      />
    ),
    channels: (
      <ChannelsTab
        channels={channels}
        media={library}
        shows={shows}
        activeId={channel?.id}
        editing={editing}
        onEdit={editChannel}
        isLocked={channelLocked}
        hasPin={Boolean(pin)}
        onToggleFav={onToggleFav}
        onReshuffleAll={onReshuffleAll}
        onTune={tuneTo}
        onSave={handleSaveChannel}
        onDelete={handleDeleteChannel}
        onGoLibrary={() => switchTab("library")}
      />
    ),
    library: (
      <LibraryTab
        media={library}
        activeId={channel ? null : activeId}
        playingShow={channel ? null : playingShow}
        importing={importing}
        boost={prefs.boost}
        ratings={prefs.ratings}
        autoBreaks={prefs.autoBreaks}
        openShow={libShow}
        onOpenShow={openShow}
        onBoost={setShowBoost}
        onRating={setShowRating}
        onAutoBreaks={setShowAutoBreaks}
        onSetBreaks={setBreaks}
        onPlay={onPlayMedia}
        onPlayList={onPlayList}
        onRemove={onRemoveMedia}
        onRemoveMany={onRemoveMany}
        onAddFiles={onAddFiles}
        onLink={onLinkFolder}
        onQuickPlay={onQuickPlay}
        infoOn={prefs.episodeInfo}
        onMatch={onMatchShow}
        onRescan={canRescan ? onRescan : null}
        rescanStatus={rescanStatus}
      />
    ),
    picture: (
      <PictureTab
        settings={prefs.crt}
        onChange={onPicture}
        lowPower={{ mode: lowMode, active: lowPower, battery, scanlines: prefs.liteScanlines !== false }}
        onLowPower={update}
      />
    ),
    sound: <SoundTab prefs={prefs} update={update} currentShow={currentShow} onBoost={setShowBoost} />,
    broadcast: <BroadcastTab settings={prefs.broadcast} onChange={onBroadcast} />,
    system: (
      <SystemTab
        prefs={prefs}
        update={update}
        library={rawLibrary}
        sleep={sleep}
        infoStatus={prefs.episodeInfo ? episodeInfoStatus() : ""}
        onRefreshInfo={onRefreshInfo}
        onResetSettings={onResetSettings}
        onStartFresh={onStartFresh}
        onEraseAll={onEraseAll}
        weather={wx}
        channels={channels}
        remoteInfo={remoteInfo}
        onNewRemoteCode={onNewRemoteCode}
      />
    ),
  }[tab];

  const touchBtn = "ps-btn flex h-11 min-w-11 items-center justify-center gap-1.5 px-3";
  const v = videoRef.current;

  return (
    <BackStackContext.Provider value={backStack}>
      <div className={tv ? "ps-font fixed inset-0 overflow-hidden bg-black text-white" : "ps-app min-h-screen text-white"} style={tubeStyle}>
        {tube.svg}
        <div className={tv ? "contents" : "relative mx-auto flex min-h-screen max-w-6xl flex-col gap-4 px-3 py-4 sm:px-6"}>
          {!tv && (
            <header className="ps-panel flex items-center gap-3 px-4 py-2.5">
              <div className="min-w-0">
                <Brand />
                <p className="pl-6 text-[10px] font-bold uppercase tracking-[0.25em] text-[#8fc4ff]">Digital</p>
              </div>
              {!online && (
                <span className="flex items-center gap-1 rounded-full bg-[#071741] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#ffe14d]">
                  <WifiOff size={11} /> Offline
                </span>
              )}
              <div className="ml-auto">
                <InstallButton />
              </div>
            </header>
          )}

          <div className={tv ? "contents" : "flex flex-1 flex-col gap-4 lg:grid lg:grid-cols-[minmax(0,1fr)_25rem] lg:items-start"}>
            <div className={tv ? "contents" : "flex flex-col gap-3 lg:sticky lg:top-4"}>
              <div
                ref={stageRef}
                onPointerDown={onStagePointer}
                data-bumper={bumper?.bumper || undefined}
                data-item={channel ? nowPlaying?.current?.kind : undefined}
                data-captions={cues ? cues.length : undefined}
                data-teletext={tt ? tt.page : undefined}
                data-power={power}
                className={
                  tv
                    ? guideFull
                      ? "pointer-events-none absolute inset-0 z-50 overflow-hidden"
                      : "absolute inset-0 z-0 overflow-hidden bg-black"
                    : "relative overflow-hidden rounded-[22px] border border-[#4a7bd4] bg-black p-2 shadow-[inset_0_1px_0_rgba(255,255,255,0.25),0_30px_80px_-20px_rgba(0,0,0,0.9)] sm:p-3"
                }
              >
                <div ref={screenRef} className={`relative w-full overflow-hidden ${guideFull ? "" : "bg-black"} ${tv ? "h-full" : "aspect-video rounded-[14px] ring-1 ring-white/5"}`}>
                  {lowPower ? (
                    <LitePlayer
                      videoRef={videoRef}
                      hasFrame={hasFrame && !(guideFull && lock)}
                      staticLevel={tt ? 0 : staticLevel}
                      gfxRef={gfxRef}
                      power={power}
                      powerFx={prefs.crt.powerFx !== false}
                      pig={guideFull}
                      scanlines={prefs.liteScanlines !== false}
                    />
                  ) : (
                    <CRTPlayer
                      videoRef={videoRef}
                      settings={prefs.crt}
                      hasFrame={hasFrame && !(guideFull && lock)}
                      staticLevel={tt ? 0 : staticLevel}
                      gfxRef={gfxRef}
                      power={power}
                      warmUp={prefs.crt.powerFx !== false}
                      pig={guideFull}
                      pigCurve={tube.curved}
                    />
                  )}
                  {!guideFull && <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/[0.06] via-transparent to-transparent" />}
                  {sleepPhase === "fading" && <div className="rv-sleep-fade pointer-events-none absolute inset-0 z-[16] bg-black" />}
                  {/* Everything the set draws over the picture, on the tube with it. */}
                  <div className="rv-tube absolute inset-0 z-[2]" data-tube data-power={power} data-low-power={lowPower || undefined}>
                  {!guideFull && message}
                  {lock && !guideFull && (!bumper || lock.key.startsWith("ch:")) && <LockScreen reason={lock.reason} hint={pad.connected ? "Press A to enter the PIN" : "Press OK or tap to enter the PIN"} />}
                  {sleepPhase === "asleep" && <AsleepScreen hint={isNative() ? "Closing…" : "Press any button to wake"} />}
                  {channel && (livePause || shift > 1500) && !guideFull && !pip && !tt && <TimeshiftTag paused={Boolean(livePause)} behindMs={livePause ? Date.now() - livePause + shift : shift} />}
                  {entry && !guideFull && !pip && <NumberEntry digits={entry.digits} missing={entry.missing} compact={!tv} />}
                  {bugOn && !entry && !guideFull && !pip && <ChannelBug channel={channel} compact={!tv} />}
                  {prefs.muted && !volOn && !guideFull && !pip && <MuteTag />}
                  {(tagOn || sleepSoon) && !guideFull && !pip && (
                    <CornerTag lower={prefs.muted && !volOn} icon={sleepSoon || tagText.startsWith("Sleep") ? <SleepIcon /> : null}>
                      {sleepSoon && !tagOn ? `Sleep ${formatClock(sleep.remaining / 1000)}` : tagText}
                    </CornerTag>
                  )}
                  {volOn && !guideFull && !pip && <VolumeBar volume={prefs.volume} muted={prefs.muted} />}
                  {infoOn && !touchOn && !volOn && !guideFull && !pip && (src || bumper || !channels.length) && (
                    <InfoBanner
                      channel={channel}
                      nn={nn}
                      nowMs={nowMs}
                      file={!channel && v ? { time: v.currentTime || 0, duration: v.duration || 0, sub: currentShow || "" } : null}
                      label={channels.length || src ? label : "No channels yet. Press Start to open the menu and make one."}
                      boostDb={boostDb}
                      compact={!tv}
                      hints={pad.connected ? WATCH_HINTS : tv ? REMOTE_HINTS : null}
                      note={startOverNote}
                    />
                  )}
                  {tv && touchOn && !menuOpen && !pip && (
                    <div className="ps-panel absolute inset-x-3 bottom-3 z-30 flex items-center gap-2 px-3 py-2" onPointerDown={(e) => e.stopPropagation()}>
                      <button className={touchBtn} onClick={() => openMenu()} aria-label="Open menu">
                        <MenuIcon size={18} /> <span className="text-sm">Menu</span>
                      </button>
                      <button className={touchBtn} onClick={() => stepChannel(-1)} aria-label="Channel down">
                        <ChevronDown size={18} />
                      </button>
                      <button className={touchBtn} onClick={() => stepChannel(1)} aria-label="Channel up">
                        <ChevronUp size={18} />
                      </button>
                      <span className="min-w-0 flex-1 truncate px-2 text-sm font-bold">
                        {channel && <span className="ps-btn-primary mr-2 px-1.5 text-sm">{pad2(channel.number)}</span>}
                        {nn ? `${nn.now.media?.show || label}` : label}
                      </span>
                      <button className={touchBtn} onClick={() => { changeVolume(-0.05); flashTouch(4500); }} aria-label="Volume down">
                        <Volume1 size={18} />
                      </button>
                      <button className={touchBtn} onClick={() => { changeVolume(0.05); flashTouch(4500); }} aria-label="Volume up">
                        <Volume2 size={18} />
                      </button>
                      <button className={touchBtn} onClick={() => { toggleMute(); flashTouch(4500); }} aria-label={prefs.muted ? "Unmute" : "Mute"}>
                        {prefs.muted ? <VolumeX size={18} /> : <Volume2 size={18} className="opacity-60" />}
                      </button>
                      <button className={touchBtn} onClick={() => { togglePlay(); flashTouch(4500); }} aria-label="Play or pause">
                        {v && !v.paused ? <Pause size={18} /> : <Play size={18} />}
                      </button>
                    </div>
                  )}
                  </div>
                  <video ref={videoRef} src={src || undefined} playsInline className="hidden" />
                </div>
              </div>

              {!tv && (
                <div className="ps-panel flex flex-col gap-3 p-3">
                  <div className="flex min-w-0 items-center gap-3">
                    {channel && <span className="ps-btn-primary shrink-0 px-2 py-0.5 text-lg tabular-nums">{pad2(channel.number)}</span>}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold text-white">{channel && nn ? nn.now.media?.show || label : label}</p>
                      <p className="truncate text-[11px] font-bold uppercase tracking-wider text-[#8fc4ff]">
                        {channel ? channel.name : currentShow || "Now playing"}
                        {bumper && " · Station break"}
                        {channel && nowPlaying?.current.kind === "ad" && " · Ad break"}
                        {channel && nn && ` · ${formatClock((nn.now.endMs - nowMs) / 1000)} left`}
                        {boostDb > 0 && ` · Boost +${boostDb} dB`}
                      </p>
                    </div>
                  </div>
                  <PlayerControls
                    videoRef={videoRef}
                    containerRef={stageRef}
                    disabled={!hasFrame}
                    live={Boolean(channel)}
                    volume={prefs.volume}
                    muted={prefs.muted}
                    onVolume={(val) => update({ volume: clamp01(val), muted: false })}
                    onToggleMute={() => update((p) => ({ muted: !p.muted }))}
                  />
                  {pad.connected && (
                    <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] font-bold uppercase tracking-wider text-[#a9c3ee]">
                      {navMode === "menu" ? (
                        <>
                          <span className="text-[#ffe14d]">Controller: menu</span>
                          <span className="flex items-center gap-1"><Key>B</Key> / <Key>Start</Key> back to watching</span>
                        </>
                      ) : (
                        <>
                          <span className="text-[#ffe14d]">Controller: watching</span>
                          {WATCH_HINTS.map(([k, val]) => (
                            <span key={k} className="flex items-center gap-1"><Key>{k}</Key> {val}</span>
                          ))}
                        </>
                      )}
                    </p>
                  )}
                </div>
              )}
            </div>

            {(!tv || menuOpen) &&
              (() => {
                const panel = (
                  <MenuPanel
                    variant={variant}
                    tab={tab}
                    onTab={(id) => switchTab(id, "tab")}
                    onClose={closeMenu}
                    showHints={showHints}
                    controller={pad.connected}
                  >
                    {tabContent}
                  </MenuPanel>
                );
                // Over the picture: on the tube too.
                return tv ? (
                  <div className="rv-tube pointer-events-none fixed inset-0 z-40" data-tube data-power={power}>
                    {panel}
                  </div>
                ) : (
                  panel
                );
              })()}
          </div>
        </div>
        {/* Pop-ups (Modal, reminders) render in here. */}
        <div id="rv-modal-root" className={`${tv ? "rv-tube" : ""} pointer-events-none fixed inset-0 z-[80]`} data-tube={tv ? "" : undefined} data-power={tv ? power : undefined} />
      </div>
      {dueReminder && <ReminderPopup reminder={dueReminder} onWatch={watchReminder} onDismiss={() => setDueReminder(null)} />}
      {pinAsk && (
        <PinPad
          title={pinAsk.title}
          subtitle={pinAsk.subtitle}
          check={(p) => p === pin}
          onDone={() => {
            const then = pinAsk.then;
            setPinAsk(null);
            then();
            if (navMode === "menu") afterRender(restoreFocus);
          }}
          onClose={() => {
            setPinAsk(null);
            if (navMode === "menu") afterRender(restoreFocus);
          }}
        />
      )}
    </BackStackContext.Provider>
  );
}
