import { useCallback, useEffect, useRef, useState } from "react";

export const SLEEP_STEPS = [0, 15, 30, 45, 60, 90, 120];

// Sleep timer: { remaining (ms), minutes (the step it was set to), setMinutes, cycle }.
// cycle() steps up like a TV remote's sleep button: off, 15, 30 ... 120, off.
// onSleep runs once when it runs out.
export default function useSleepTimer(onSleep) {
  const [sleepAt, setSleepAt] = useState(null);
  const [minutes, setMins] = useState(0);
  const [now, setNow] = useState(() => Date.now());
  const onSleepRef = useRef(onSleep);
  onSleepRef.current = onSleep;

  useEffect(() => {
    if (!sleepAt) return undefined;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [sleepAt]);

  useEffect(() => {
    if (sleepAt && now >= sleepAt) {
      setSleepAt(null);
      setMins(0);
      onSleepRef.current?.();
    }
  }, [now, sleepAt]);

  const setMinutes = useCallback((m) => {
    setMins(m);
    setNow(Date.now());
    setSleepAt(m ? Date.now() + m * 60000 : null);
  }, []);

  const remaining = sleepAt ? Math.max(0, sleepAt - now) : 0;
  const cycle = useCallback(() => {
    const left = remaining / 60000;
    const next = SLEEP_STEPS.find((s) => s > left + 0.5) ?? 0;
    setMinutes(next);
    return next;
  }, [remaining, setMinutes]);

  return { remaining, minutes, setMinutes, cycle };
}
