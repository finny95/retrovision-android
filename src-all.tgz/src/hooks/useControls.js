import { useEffect, useRef, useState } from "react";
import { isSlider, isTextField } from "@/lib/spatialNav";

// One input layer for controllers, TV remotes and keyboards. Everything is
// turned into the same small set of actions:
//   up down left right  a b x y  l1 r1 l2 r2  start select  play (media key)
//   d0..d9 (number keys)  last  sleep  captions
// and handed to onAction(action, { source, repeat }). Return true from the
// handler when the action was used (keyboard events are then swallowed).

const PAD = { A: 0, B: 1, X: 2, Y: 3, L1: 4, R1: 5, L2: 6, R2: 7, SELECT: 8, START: 9, UP: 12, DOWN: 13, LEFT: 14, RIGHT: 15 };
const DEADZONE = 0.5;
const REPEAT_DELAY = 380;
const REPEAT_RATE = 110;
const REPEATS = new Set(["up", "down", "left", "right", "l2", "r2"]);

const KEYS = {
  ArrowUp: "up",
  ArrowDown: "down",
  ArrowLeft: "left",
  ArrowRight: "right",
  Enter: "a",
  " ": "a",
  MediaPlayPause: "play",
  Escape: "b",
  Backspace: "b",
  GoBack: "b",
  BrowserBack: "b",
  PageUp: "r1",
  PageDown: "l1",
  ChannelUp: "r1",
  ChannelDown: "l1",
  "]": "r1",
  "[": "l1",
  m: "x",
  M: "x",
  i: "y",
  I: "y",
  Info: "y",
  g: "select",
  G: "select",
  Guide: "select",
  ContextMenu: "start",
  Menu: "start",
  // Remote extras: number keys tune, last channel, sleep, captions.
  ...Object.fromEntries(Array.from({ length: 10 }, (_, d) => [String(d), `d${d}`])),
  l: "last",
  L: "last",
  MediaLast: "last",
  s: "sleep",
  S: "sleep",
  c: "captions",
  C: "captions",
  ClosedCaptionToggle: "captions",
  Subtitle: "captions",
};

const isClickable = (el) =>
  el && el !== document.body && (el.tagName === "BUTTON" || el.tagName === "A" || el.tagName === "INPUT" || el.tagName === "SELECT" || el.hasAttribute("data-adjust"));

export default function useControls(onAction) {
  const handlerRef = useRef(onAction);
  handlerRef.current = onAction;
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    // Android sends many controller presses twice: once to the Gamepad API and once
    // as a key (d-pad -> arrow keys). Whichever arrives first wins; the echo within
    // 250 ms is dropped (and a key echo's default action, e.g. a click, is blocked).
    const ECHO_MS = 250;
    const lastPad = {};
    const lastKey = {};
    const emit = (action, info) => handlerRef.current?.(action, info) === true;

    // --- Controller ---------------------------------------------------------
    const held = {};
    let raf;
    const fire = (key, down, now) => {
      if (!down) {
        delete held[key];
        return;
      }
      const h = held[key];
      if (!h) {
        held[key] = { since: now, last: now };
        if (Date.now() - (lastKey[key] || 0) < ECHO_MS) return;
        lastPad[key] = Date.now();
        emit(key, { source: "pad", repeat: false });
        return;
      }
      if (REPEATS.has(key) && now - h.since > REPEAT_DELAY && now - h.last > REPEAT_RATE) {
        h.last = now;
        lastPad[key] = Date.now();
        emit(key, { source: "pad", repeat: true });
      }
    };
    const poll = (now) => {
      const pad = (navigator.getGamepads?.() || []).find(Boolean);
      if (pad) {
        const btn = (i) => Boolean(pad.buttons[i]?.pressed) || (pad.buttons[i]?.value || 0) > 0.5;
        const ax = pad.axes[0] || 0;
        const ay = pad.axes[1] || 0;
        fire("up", btn(PAD.UP) || ay < -DEADZONE, now);
        fire("down", btn(PAD.DOWN) || ay > DEADZONE, now);
        fire("left", btn(PAD.LEFT) || ax < -DEADZONE, now);
        fire("right", btn(PAD.RIGHT) || ax > DEADZONE, now);
        fire("a", btn(PAD.A), now);
        fire("b", btn(PAD.B), now);
        fire("x", btn(PAD.X), now);
        fire("y", btn(PAD.Y), now);
        fire("l1", btn(PAD.L1), now);
        fire("r1", btn(PAD.R1), now);
        fire("l2", btn(PAD.L2), now);
        fire("r2", btn(PAD.R2), now);
        fire("start", btn(PAD.START), now);
        fire("select", btn(PAD.SELECT), now);
      }
      raf = requestAnimationFrame(poll);
    };
    raf = requestAnimationFrame(poll);

    const sync = () => setConnected((navigator.getGamepads?.() || []).some(Boolean));
    window.addEventListener("gamepadconnected", sync);
    window.addEventListener("gamepaddisconnected", sync);
    sync();

    // --- Keyboard / TV remote ----------------------------------------------
    const onKey = (e) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const action = KEYS[e.key];
      if (!action) return;
      if (Date.now() - (lastPad[action] || 0) < ECHO_MS) {
        e.preventDefault();
        return;
      }
      lastKey[action] = Date.now();
      const target = e.target;
      if (isTextField(target)) {
        // Typing: only leave the field with Up/Down or Escape.
        if (!["up", "down", "b"].includes(action) || e.key === "Backspace") return;
      }
      // Let sliders and focused buttons do their native thing for these keys.
      if ((action === "left" || action === "right") && isSlider(target)) return;
      if (action === "a" && isClickable(target)) return;
      if (emit(action, { source: "key", repeat: e.repeat })) e.preventDefault();
    };
    window.addEventListener("keydown", onKey);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("gamepadconnected", sync);
      window.removeEventListener("gamepaddisconnected", sync);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  return { connected };
}
