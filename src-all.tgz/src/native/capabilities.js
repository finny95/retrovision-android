// Which native features this APK has (newer builds add more). Older builds
// don't have capabilities() at all, so they report none.
import { isNative } from "@/native/platform";

let cached = null;

export async function nativeCaps() {
  if (!isNative()) return { features: [], pipEnabled: false };
  if (cached) return cached;
  try {
    const { MediaFolder } = await import("@/native/mediaFolder");
    cached = await MediaFolder.capabilities();
  } catch {
    cached = { features: [], pipEnabled: false };
  }
  return cached;
}

export async function hasNative(feature) {
  return (await nativeCaps()).features?.includes(feature) || false;
}

// Picture-in-picture when leaving the app (Home button) while something plays.
export async function setPipEnabled(enabled) {
  const { MediaFolder } = await import("@/native/mediaFolder");
  await MediaFolder.setPip({ enabled });
  if (cached) cached = { ...cached, pipEnabled: enabled };
}
