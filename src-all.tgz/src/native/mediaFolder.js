// Android app only: link a media folder through the system folder picker.
// Files are never copied; the app keeps read access to the folder and streams
// each file from where it is (with seeking) via the /_rv_media/ route.
import { registerPlugin } from "@capacitor/core";

export const MediaFolder = registerPlugin("MediaFolder");

let counter = 0;

// A fresh URL each time, so replaying the same file reloads the <video>.
export function mediaUrl(record) {
  const name = encodeURIComponent(record.name || "media");
  return `${window.location.origin}/_rv_media/${name}?u=${encodeURIComponent(record.uri)}&n=${++counter}`;
}

// Fallback when the native probe can't read a duration: let the WebView try.
function durationFromUrl(url, type) {
  return new Promise((resolve) => {
    const el = document.createElement(type?.startsWith("audio") ? "audio" : "video");
    let settled = false;
    const done = (d) => {
      if (settled) return;
      settled = true;
      el.removeAttribute("src");
      el.load();
      resolve(isFinite(d) && d > 0 ? d : 0);
    };
    const timer = setTimeout(() => done(0), 15000);
    el.preload = "metadata";
    el.onloadedmetadata = () => {
      clearTimeout(timer);
      done(el.duration);
    };
    el.onerror = () => {
      clearTimeout(timer);
      done(0);
    };
    el.src = url;
  });
}

// Library record for a file found by MediaFolder.pickFolder().
export async function describeNative({ native: file, show, season }) {
  let duration = 0;
  try {
    ({ duration } = await MediaFolder.probe({ uri: file.uri }));
  } catch {
    duration = 0;
  }
  if (!duration) duration = await durationFromUrl(mediaUrl(file), file.type);
  return {
    name: file.name,
    type: file.type,
    size: file.size,
    added: Date.now(),
    duration,
    show,
    season,
    uri: file.uri,
    ...(file.subtitleUri ? { subtitleUri: file.subtitleUri } : {}),
  };
}

// Playable URL for a linked record, or null if the file is gone or access was lost.
export async function playableUrl(record) {
  try {
    const { readable } = await MediaFolder.check({ uri: record.uri });
    if (!readable) return null;
  } catch {
    // Older app build without check(): just try to play it.
  }
  return mediaUrl(record);
}

// Linked folders (as tree URIs) behind the library's records.
export function linkedTrees(records) {
  const trees = new Set();
  for (const r of records) if (r.uri && r.uri.includes("/document/")) trees.add(r.uri.split("/document/")[0]);
  return [...trees];
}
