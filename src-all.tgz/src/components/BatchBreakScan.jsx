import React, { useEffect, useRef, useState } from "react";
import { Modal } from "@/components/tv/Picker";
import { useBackHandler } from "@/components/tv/backStack";
import { scanForBreaks } from "@/lib/breakScan";
import { focusEl } from "@/lib/spatialNav";

// Find breaks in every episode of a show (or season) that has none set by hand.
export default function BatchBreakScan({ files, onSave, onClose }) {
  const todo = useRef(files.filter((m) => !m.manualBreaks && m.duration > 120));
  const [at, setAt] = useState(0);
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);
  const [stats, setStats] = useState({ found: 0, episodes: 0 });
  const ctl = useRef(null);
  const bodyRef = useRef(null);

  const stop = () => {
    ctl.current?.abort();
    onClose();
  };
  useBackHandler(() => {
    stop();
    return true;
  });

  useEffect(() => {
    window.dispatchEvent(new CustomEvent("rv-preview", { detail: true }));
    requestAnimationFrame(() => focusEl(bodyRef.current?.querySelector("button")));
    const c = new AbortController();
    ctl.current = c;
    (async () => {
      for (let i = 0; i < todo.current.length; i++) {
        if (c.signal.aborted) return;
        setAt(i);
        setProgress(0);
        try {
          const list = await scanForBreaks(todo.current[i], { signal: c.signal, onProgress: setProgress });
          if (list.length) {
            onSave(todo.current[i], list.map((x) => x.t));
            setStats((s) => ({ found: s.found + list.length, episodes: s.episodes + 1 }));
          }
        } catch (e) {
          if (e?.name === "AbortError") return;
        }
      }
      setDone(true);
    })();
    return () => {
      c.abort();
      window.dispatchEvent(new CustomEvent("rv-preview", { detail: false }));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const total = todo.current.length;
  const current = todo.current[at];
  const overall = total ? ((at + (done ? 1 : progress)) / total) * 100 : 100;

  return (
    <Modal title="Finding breaks" subtitle={total ? `${total} episodes without their own breaks` : "Every episode already has breaks"} onClose={stop} bodyRef={bodyRef} footer="B: stop (breaks found so far are kept)">
      <div className="ps-inset flex flex-col gap-2 px-3 py-3">
        <p className="truncate text-sm font-bold text-white">{done || !total ? "Done" : `Episode ${at + 1} of ${total}`}</p>
        {!done && current && <p className="truncate text-[11px] text-[#a9c3ee]">{current.name}</p>}
        <span className="relative h-2 overflow-hidden rounded-full bg-black/50">
          <span className="absolute inset-y-0 left-0 bg-gradient-to-b from-[#fff27a] to-[#f5b800]" style={{ width: `${overall}%` }} />
        </span>
        <p className="text-[11px] font-bold text-[#ffe14d]">
          {stats.found} breaks found in {stats.episodes} {stats.episodes === 1 ? "episode" : "episodes"}
        </p>
      </div>
      <button onClick={stop} className="ps-btn flex min-h-11 items-center justify-center text-sm">
        {done || !total ? "Close" : "Stop"}
      </button>
    </Modal>
  );
}
