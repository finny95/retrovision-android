import React, { useEffect, useRef, useState } from "react";
import { Delete, Lock } from "lucide-react";
import { Modal } from "@/components/tv/Picker";
import { useBackHandler } from "@/components/tv/backStack";
import { focusEl } from "@/lib/spatialNav";

const KEYS = [["1", "2", "3"], ["4", "5", "6"], ["7", "8", "9"], ["clear", "0", "del"]];

// Four-digit PIN entry: on-screen keypad (controller / remote / touch) plus the
// number keys on a remote or keyboard.
//   mode "check": onDone(pin) only when check(pin) is true.
//   mode "new":   asks twice, then onDone(pin).
export default function PinPad({ title = "Enter PIN", subtitle, mode = "check", check, onDone, onClose }) {
  const [digits, setDigits] = useState("");
  const [first, setFirstState] = useState(null);
  const firstRef = useRef(null);
  const setFirst = (v) => {
    firstRef.current = v;
    setFirstState(v);
  };
  const [error, setError] = useState("");
  const bodyRef = useRef(null);
  const digitsRef = useRef(digits);
  digitsRef.current = digits;

  useBackHandler(() => {
    onClose();
    return true;
  });
  useEffect(() => {
    requestAnimationFrame(() => focusEl(bodyRef.current?.querySelector('[data-pin-key="5"]')));
  }, []);

  const submit = (pin) => {
    if (mode === "new") {
      if (firstRef.current == null) {
        setFirst(pin);
        put("");
        setError("");
        return;
      }
      if (pin !== firstRef.current) {
        setFirst(null);
        put("");
        setError("The PINs didn't match. Start again.");
        return;
      }
      onDone(pin);
      return;
    }
    if (check?.(pin)) onDone(pin);
    else {
      put("");
      setError("Wrong PIN");
    }
  };

  const put = (v) => {
    digitsRef.current = v;
    setDigits(v);
  };
  const press = (k) => {
    const d = digitsRef.current;
    if (k === "clear") return put("");
    if (k === "del") return put(d.slice(0, -1));
    if (d.length >= 4) return undefined;
    const next = d + k;
    put(next);
    setError("");
    if (next.length === 4) {
      digitsRef.current = "";
      submit(next);
    }
    return undefined;
  };
  const pressRef = useRef(press);
  pressRef.current = press;

  // Number keys and Backspace go to the PIN, not to channel changes or Back.
  useEffect(() => {
    const onKey = (e) => {
      if (/^[0-9]$/.test(e.key)) {
        e.preventDefault();
        e.stopPropagation();
        pressRef.current(e.key);
      } else if (e.key === "Backspace" && digitsRef.current) {
        e.preventDefault();
        e.stopPropagation();
        pressRef.current("del");
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, []);

  const prompt = mode === "new" ? (first == null ? "Choose a 4-digit PIN" : "Enter it again to confirm") : subtitle || "Enter your 4-digit PIN";

  return (
    <Modal title={title} subtitle={prompt} onClose={onClose} bodyRef={bodyRef} footer="Number keys or the pad · B: cancel">
      <div className="flex flex-col items-center gap-2 py-1" data-pin-pad>
        <Lock size={22} className="text-[#ffd21f]" />
        <div className="flex gap-3" aria-label={`${digits.length} of 4 digits entered`}>
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className={`h-4 w-4 rounded-full border-2 border-white ${i < digits.length ? "bg-[#ffd21f]" : "bg-transparent"}`} />
          ))}
        </div>
        <p role="status" className="min-h-[1.25rem] text-xs font-bold text-[#ff8a80]">{error}</p>
      </div>
      {KEYS.map((row, r) => (
        <div key={r} data-nav-row className="grid grid-cols-3 gap-1.5">
          {row.map((k) => (
            <button
              key={k}
              data-pin-key={k}
              onClick={() => press(k)}
              aria-label={k === "del" ? "Delete" : k === "clear" ? "Clear" : k}
              className="ps-row flex min-h-12 items-center justify-center text-lg font-bold"
            >
              {k === "del" ? <Delete size={18} /> : k === "clear" ? <span className="text-xs uppercase">Clear</span> : k}
            </button>
          ))}
        </div>
      ))}
    </Modal>
  );
}
