import React, { useEffect, useRef, useState } from "react";
import { Check, Ban } from "lucide-react";
import { Modal } from "@/components/tv/Picker";
import { TextRow } from "@/components/tv/controls";
import { useBackHandler } from "@/components/tv/backStack";
import { searchShows, cleanShowName, matchedId } from "@/lib/episodeInfo";
import { focusEl } from "@/lib/spatialNav";

// Pick which TVmaze show a folder is (when the automatic match is wrong).
export default function ShowMatch({ show, onPick, onClose }) {
  const bodyRef = useRef(null);
  const [q, setQ] = useState(() => cleanShowName(show).q);
  const [results, setResults] = useState(null);
  const [error, setError] = useState("");
  const current = matchedId(show);

  useBackHandler(() => {
    onClose();
    return true;
  });

  useEffect(() => {
    let alive = true;
    const t = setTimeout(() => {
      setError("");
      searchShows(q)
        .then((r) => alive && setResults(r))
        .catch(() => alive && setError("Couldn't reach TVmaze. Check the internet connection."));
    }, 400);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [q]);

  const focusedOnce = useRef(false);
  useEffect(() => {
    if (!results || focusedOnce.current) return;
    focusedOnce.current = true;
    requestAnimationFrame(() => focusEl(bodyRef.current?.querySelector('[aria-selected="true"]') || bodyRef.current?.querySelector("[data-result]") || bodyRef.current?.querySelector("button")));
  }, [results]);

  return (
    <Modal title="Which show is this?" subtitle={show} onClose={onClose} bodyRef={bodyRef} footer="A: choose · B: close">
      <TextRow label="Search" value={q} placeholder="Show name" onChange={setQ} maxLength={60} />
      {error && <p className="ps-inset px-3 py-2 text-xs text-[#ffe14d]">{error}</p>}
      {!results && !error && <p className="px-3 py-2 text-xs text-[#a9c3ee]">Searching…</p>}
      {results?.length === 0 && <p className="px-3 py-2 text-xs text-[#a9c3ee]">No matches. Try a different spelling.</p>}
      {results?.map((r) => (
        <button
          key={r.id}
          data-result
          role="option"
          aria-selected={r.id === current}
          data-on={r.id === current || undefined}
          onClick={() => onPick(r.id)}
          className="ps-row flex min-h-11 items-center justify-between gap-3 px-3 py-2 text-left text-sm"
        >
          <span className="min-w-0">
            <span className="ps-label block truncate">{r.title}</span>
            <span className="ps-hint block truncate text-[11px]">{[r.year, r.network].filter(Boolean).join(" · ") || "TVmaze"}</span>
          </span>
          {r.id === current && <Check size={15} className="shrink-0" />}
        </button>
      ))}
      <button onClick={() => onPick(0)} className="ps-btn mt-1 flex min-h-11 items-center justify-center gap-2 text-sm">
        <Ban size={14} /> Don't look this one up
      </button>
    </Modal>
  );
}
