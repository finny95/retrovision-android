import React, { useEffect, useMemo, useRef, useState } from "react";
import { Plus, CalendarClock } from "lucide-react";
import { Modal } from "@/components/tv/Picker";
import { useBackHandler } from "@/components/tv/backStack";
import { Cycler, NavRow, Stepper, SectionLabel, ConfirmButton } from "@/components/tv/controls";
import { showSeasons, SLOT_DAYS } from "@/lib/schedule";
import { focusEl } from "@/lib/spatialNav";

export const DAY_OPTIONS = [
  { value: "all", label: "Every day" },
  { value: "weekdays", label: "Weekdays" },
  { value: "weekends", label: "Weekends" },
  { value: "mon", label: "Mondays" },
  { value: "tue", label: "Tuesdays" },
  { value: "wed", label: "Wednesdays" },
  { value: "thu", label: "Thursdays" },
  { value: "fri", label: "Fridays" },
  { value: "sat", label: "Saturdays" },
  { value: "sun", label: "Sundays" },
];
const ORDER = [
  { value: "inorder", label: "In order" },
  { value: "random", label: "Random" },
];

export const timeLabel = (min) => {
  const m = ((min % 1440) + 1440) % 1440;
  const h = Math.floor(m / 60);
  return `${h % 12 || 12}:${String(m % 60).padStart(2, "0")}${h >= 12 ? "pm" : "am"}`;
};
const lengthLabel = (min) => (min < 60 ? `${min} min` : `${Math.floor(min / 60)}h${min % 60 ? ` ${min % 60}m` : ""}`);
const daysLabel = (d) => DAY_OPTIONS.find((o) => o.value === d)?.label || "Every day";
const overlaps = (a, b) => {
  const da = SLOT_DAYS[a.days] || SLOT_DAYS.all;
  const db = SLOT_DAYS[b.days] || SLOT_DAYS.all;
  return da.some((d) => db.includes(d)) && a.start < b.start + b.length && b.start < a.start + a.length;
};

function SlotEditor({ slot, others, shows, media, onChange, onDelete, onClose }) {
  const bodyRef = useRef(null);
  useBackHandler(() => {
    onClose();
    return true;
  });
  const set = (patch) => onChange({ ...slot, ...patch });
  const seasons = slot.show ? showSeasons(media, slot.show) : [];
  const clash = others.find((o) => overlaps(slot, o));
  return (
    <Modal
      title={`${timeLabel(slot.start)} slot`}
      subtitle={daysLabel(slot.days)}
      onClose={onClose}
      bodyRef={bodyRef}
      footer="◀▶ change · B: done"
      actions={
        <button tabIndex={-1} onClick={onClose} className="ps-btn-primary shrink-0 px-3 py-1 text-[11px] uppercase">
          Done
        </button>
      }
    >
      <SlotFocus bodyRef={bodyRef} />
      <Cycler label="Show" value={slot.show} options={shows.length ? shows.map((s) => ({ value: s, label: s })) : [{ value: "", label: "No shows yet" }]} onChange={(v) => set({ show: v, season: "" })} />
      {seasons.length > 0 && (
        <Cycler label="Season" value={slot.season || ""} options={[{ value: "", label: "All seasons" }, ...seasons.map((s) => ({ value: s, label: s }))]} onChange={(v) => set({ season: v })} />
      )}
      <Cycler label="Days" value={slot.days} options={DAY_OPTIONS} onChange={(v) => set({ days: v })} />
      <Stepper label="Starts" value={slot.start} min={0} max={1425} step={15} format={timeLabel} onChange={(v) => set({ start: v })} />
      <Stepper label="Length" value={slot.length} min={15} max={480} step={15} format={lengthLabel} onChange={(v) => set({ length: v })} hint={`Ends ${timeLabel(slot.start + slot.length)}`} />
      <Cycler label="Episodes" hint={slot.order === "random" ? "Random picks each time" : "Carries on where the last airing stopped"} value={slot.order || "inorder"} options={ORDER} onChange={(v) => set({ order: v })} />
      {clash && (
        <p className="ps-inset px-3 py-2 text-[11px] font-bold text-[#ffe14d]">
          Overlaps the {timeLabel(clash.start)} {clash.show} slot. The earlier one is cut short.
        </p>
      )}
      <ConfirmButton label="Delete this slot" confirmLabel="Press again to delete" onConfirm={onDelete} className="ps-btn mt-1 flex min-h-11 items-center justify-center text-sm" />
    </Modal>
  );
}

function SlotFocus({ bodyRef }) {
  // First control gets focus when the slot opens.
  useEffect(() => {
    requestAnimationFrame(() => focusEl(bodyRef.current?.querySelector("[data-adjust], button")));
  }, [bodyRef]);
  return null;
}

// Booked slots for a timetable channel: what airs when, on which days.
export default function TimetableEditor({ slots, shows, media, onChange }) {
  const [open, setOpen] = useState(null); // index
  const rootRef = useRef(null);
  const sorted = useMemo(() => slots.map((s, i) => ({ s, i })).sort((a, b) => a.s.start - b.s.start || a.s.days.localeCompare(b.s.days)), [slots]);

  const add = () => {
    const last = sorted[sorted.length - 1]?.s;
    const start = last ? Math.min(1410, last.start + last.length) : 18 * 60;
    const next = [...slots, { days: "all", start, length: 30, show: shows[0] || "", season: "", order: "inorder" }];
    onChange(next);
    setOpen(next.length - 1);
  };
  const close = () => {
    const i = open;
    setOpen(null);
    requestAnimationFrame(() => focusEl(rootRef.current?.querySelector(`[data-nav-key="slot:${i}"]`) || rootRef.current?.querySelector("[data-add-slot]")));
  };

  return (
    <div ref={rootRef} className="flex flex-col gap-2">
      <SectionLabel hint="Book shows at set times. Each slot fills with whole episodes (with their bumpers and breaks); anything left over plays the filler below.">
        Timetable · {slots.length} {slots.length === 1 ? "slot" : "slots"}
      </SectionLabel>
      {sorted.map(({ s, i }) => (
        <NavRow
          key={i}
          navKey={`slot:${i}`}
          icon={<CalendarClock size={16} className="text-[#a9c3ee]" />}
          label={`${timeLabel(s.start)} - ${timeLabel(s.start + s.length)}`}
          hint={`${daysLabel(s.days)}${s.order === "random" ? " · random" : ""}`}
          value={s.show ? `${s.show}${s.season ? ` · ${s.season}` : ""}` : "Pick a show"}
          onClick={() => setOpen(i)}
        />
      ))}
      <button data-add-slot onClick={add} disabled={!shows.length} className="ps-btn flex min-h-11 items-center justify-center gap-2 text-sm disabled:opacity-40">
        <Plus size={15} /> Add a time slot
      </button>
      {open != null && slots[open] && (
        <SlotEditor
          slot={slots[open]}
          others={slots.filter((_, k) => k !== open)}
          shows={shows}
          media={media}
          onChange={(s) => onChange(slots.map((x, k) => (k === open ? s : x)))}
          onDelete={() => {
            onChange(slots.filter((_, k) => k !== open));
            setOpen(null);
            requestAnimationFrame(() => focusEl(rootRef.current?.querySelector("[data-add-slot]")));
          }}
          onClose={close}
        />
      )}
      {!shows.length && <p className="px-1 text-[11px] text-[#a9c3ee]">Add shows in Library first.</p>}
    </div>
  );
}
