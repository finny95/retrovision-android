import React from "react";
import { CalendarDays, Tv, HardDrive, SlidersHorizontal, Volume2, Radio, X, Star, Settings } from "lucide-react";
import { Key } from "@/components/tv/controls";
import { useNow } from "@/components/menu/ChannelsTab";
import { formatTimeOfDay } from "@/lib/schedule";

export const TABS = [
  { id: "guide", label: "Guide", icon: CalendarDays },
  { id: "channels", label: "Channels", icon: Tv },
  { id: "library", label: "Library", icon: HardDrive },
  { id: "picture", label: "Picture", icon: SlidersHorizontal },
  { id: "sound", label: "Sound", icon: Volume2 },
  { id: "broadcast", label: "Broadcast", icon: Radio },
  { id: "system", label: "System", icon: Settings },
];

export function Clock({ className = "" }) {
  const now = useNow(15000);
  const d = new Date(now);
  return (
    <span className={`flex items-baseline gap-2 whitespace-nowrap ${className}`}>
      <span className="text-[11px] font-bold uppercase text-[#d4e3ff]">
        {d.toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" })}
      </span>
      <span className="text-base font-bold text-white">{formatTimeOfDay(now)}</span>
    </span>
  );
}

export function Brand({ small = false }) {
  return (
    <span className="flex min-w-0 items-center gap-1.5">
      <Star size={small ? 15 : 18} className="shrink-0 fill-[#ffd21f] text-[#ffd21f] drop-shadow" />
      <span className={`truncate font-bold italic uppercase tracking-wide text-white ${small ? "text-sm" : "text-base"}`}>
        Cathode<span className="text-[#ffd21f]">Tube</span>
      </span>
    </span>
  );
}

// The menu: seven tabs, one focus scope. variant:
//   "overlay" - slides over the picture (TV / handheld landscape)
//   "full"    - whole screen (the TV guide in TV layout, picture in the corner)
//   "column"  - fixed side column (desktop)
//   "inline"  - under the screen (phone portrait)
export default function MenuPanel({ variant, tab, onTab, onClose, showHints, controller = true, children }) {
  const overlay = variant === "overlay" || variant === "full";
  const shell = {
    overlay: "ps-panel fixed inset-y-0 right-0 z-40 flex w-[min(27rem,96vw)] flex-col !rounded-none !border-y-0 !border-r-0",
    full: "ps-panel fixed inset-0 z-40 flex flex-col !rounded-none !border-0",
    column: "ps-panel flex h-full min-h-0 flex-col overflow-hidden",
    inline: "ps-panel flex flex-col",
  }[variant];

  return (
    <section data-nav-scope data-menu-panel className={shell} aria-label="Menu">
      <div className={`ps-titlebar flex items-center gap-3 px-3 py-2 ${overlay ? "" : "rounded-t-[13px]"}`}>
        {overlay ? <Brand small /> : <span className="text-sm font-bold uppercase tracking-wider text-white">Main menu</span>}
        <Clock className="ml-auto" />
        {overlay && (
          <button tabIndex={-1} onClick={onClose} className="shrink-0 rounded-full p-1 text-white/80 hover:text-white" aria-label="Close menu">
            <X size={16} />
          </button>
        )}
      </div>
      <div role="tablist" className={`flex items-end gap-0.5 border-b-2 border-[#0a1f55] bg-[#0b2257] px-1.5 pt-1.5 ${variant === "inline" ? "sticky top-0 z-10" : ""}`}>
        {TABS.map((t) => {
          const Icon = t.icon;
          const on = t.id === tab;
          return (
            <button
              key={t.id}
              role="tab"
              aria-selected={on}
              data-tab={t.id}
              onClick={() => onTab(t.id)}
              className="ps-tab flex min-h-11 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 px-0.5 py-1"
            >
              <Icon size={15} className="shrink-0" />
              <span className="truncate text-[10px] sm:text-[11px]">{t.label}</span>
            </button>
          );
        })}
      </div>

      <div data-menu-content className={`${variant === "inline" ? "" : "min-h-0 flex-1 overflow-y-auto overscroll-contain"} p-3`}>
        {children}
      </div>

      {showHints && (
        <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 border-t border-[#2d5bb8] bg-[#071741] px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-[#a9c3ee]">
          <span className="flex items-center gap-1"><Key>✥</Key> Move</span>
          <span className="flex items-center gap-1"><Key>◀▶</Key> Change</span>
          <span className="flex items-center gap-1"><Key>{controller ? "A" : "OK"}</Key> Select</span>
          <span className="flex items-center gap-1"><Key>{controller ? "B" : "Back"}</Key> Back</span>
          {controller && <span className="flex items-center gap-1"><Key>LB</Key><Key>RB</Key> Tabs</span>}
        </div>
      )}
    </section>
  );
}
