import React, { memo, useEffect, useRef, useState } from "react";
import { Download, Upload, Lock, KeyRound, Moon, RefreshCw } from "lucide-react";
import { Cycler, Toggle, SectionLabel, ConfirmButton, NavRow } from "@/components/tv/controls";
import PinPad from "@/components/PinPad";
import { saveBackup, parseBackup, restoreBackup } from "@/lib/backup";
import { nativeCaps, setPipEnabled } from "@/native/capabilities";
import { isNative } from "@/native/platform";
import { formatClock } from "@/lib/schedule";
import { SLEEP_STEPS } from "@/hooks/useSleepTimer";
import { focusFirst } from "@/lib/spatialNav";

const SLEEP = SLEEP_STEPS.map((m) => ({ value: m, label: m ? `${m} min` : "Off" }));
const LOCKS = [
  { value: "off", label: "Off" },
  { value: "MA15+", label: "MA15+" },
  { value: "M", label: "M and above" },
];
const btn = "ps-btn flex min-h-11 items-center justify-center gap-2 px-3 text-sm";

// Everything about the box itself: sleep timer, captions, parental lock,
// picture-in-picture, backup / restore.
function SystemTab({ prefs, update, library, sleep, infoStatus, onRefreshInfo }) {
  const [pin, setPin] = useState(null); // null | { mode, title, then }
  const [adminOk, setAdminOk] = useState(false);
  const [caps, setCaps] = useState({ features: [], pipEnabled: false });
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef(null);
  const pendingRestore = useRef(null);
  const parental = prefs.parental;
  const hasPin = Boolean(parental.pin);
  const canChange = !hasPin || adminOk;

  useEffect(() => {
    nativeCaps().then(setCaps);
  }, []);

  const setParental = (patch) => update((p) => ({ parental: { ...p.parental, ...patch } }));
  const askPin = (title, then) => setPin({ mode: "check", title, then });
  const parentalRef = useRef(null);
  const refocus = () => requestAnimationFrame(() => parentalRef.current && focusFirst(parentalRef.current));

  const doBackup = async () => {
    setBusy(true);
    setStatus("");
    try {
      setStatus(await saveBackup(library));
    } catch (e) {
      setStatus(e?.code === "CANCELLED" || /cancel/i.test(e?.message || "") ? "Backup cancelled" : `Couldn't save the backup: ${e?.message || e}`);
    }
    setBusy(false);
  };

  const finishRestore = async (data) => {
    setBusy(true);
    try {
      const { channels, unmatched } = await restoreBackup(data, library);
      setStatus(`Restored ${channels} channel${channels === 1 ? "" : "s"}${unmatched ? ` (${unmatched} lineup items aren't in this library)` : ""}. Restarting…`);
      setTimeout(() => window.location.reload(), 1200);
    } catch (e) {
      setStatus(`Couldn't restore: ${e?.message || e}`);
      setBusy(false);
    }
  };

  const onFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const data = parseBackup(await file.text());
      if (hasPin && !adminOk) {
        pendingRestore.current = data;
        askPin("Restore backup", () => finishRestore(pendingRestore.current));
      } else finishRestore(data);
    } catch (err) {
      setStatus(err.message);
    }
  };

  const sleepMins = sleep.minutes;
  const sleepHint = sleep.remaining
    ? `Turns off in ${formatClock(sleep.remaining / 1000)}${isNative() ? ", then the app closes so the device can sleep" : ""}`
    : isNative()
      ? "Fades out, then closes the app so the device can sleep. RT or S while watching."
      : "Fades out and stops. S while watching.";

  return (
    <div className="flex flex-col gap-2">
      <SectionLabel>Sleep timer</SectionLabel>
      <Cycler label="Sleep timer" hint={sleepHint} value={sleepMins} options={SLEEP} onChange={(m) => sleep.setMinutes(m)} />

      <SectionLabel hint="Subtitle files (.srt or .vtt) with the same name as the video, in the same folder. Relink or rescan the folder to pick up new ones.">
        Captions
      </SectionLabel>
      <Toggle label="Closed captions" hint="C on a keyboard toggles them" checked={prefs.captions} onChange={(v) => update({ captions: v })} />

      <SectionLabel hint="Episode names and posters looked up online (TVmaze) from the show folder names. Kept on this device, so they work offline afterwards.">
        Episode info
      </SectionLabel>
      <Toggle label="Look up episode titles" hint={infoStatus || undefined} checked={prefs.episodeInfo} onChange={(v) => update({ episodeInfo: v })} />
      {prefs.episodeInfo && (
        <button onClick={onRefreshInfo} className={btn}>
          <RefreshCw size={14} /> Look up again
        </button>
      )}

      <SectionLabel hint="Lock channels (in each channel's settings) and shows above a classification behind a 4-digit PIN.">Parental lock</SectionLabel>
      <div ref={parentalRef} className="flex flex-col gap-2">
      {!hasPin ? (
        <NavRow
          label="Set a PIN"
          icon={<KeyRound size={16} className="text-[#a9c3ee]" />}
          navKey="pin-set"
          onClick={() => setPin({ mode: "new", title: "New PIN", then: (p) => { setParental({ pin: p }); setAdminOk(true); } })}
        />
      ) : !canChange ? (
        <NavRow label="Unlock settings" hint="Enter the PIN to change the lock" icon={<Lock size={16} className="text-[#ffd21f]" />} navKey="pin-unlock" onClick={() => askPin("Parental lock", () => setAdminOk(true))} />
      ) : (
        <>
          <Cycler label="Lock shows rated" hint="Set ratings per show in Library" value={parental.lockRating} options={LOCKS} onChange={(v) => setParental({ lockRating: v })} />
          <NavRow label="Change PIN" icon={<KeyRound size={16} className="text-[#a9c3ee]" />} navKey="pin-change" onClick={() => setPin({ mode: "new", title: "New PIN", then: (p) => setParental({ pin: p }) })} />
          <ConfirmButton label="Remove PIN and locks" confirmLabel="Press again to remove" onConfirm={() => { setParental({ pin: "", lockRating: "off" }); setAdminOk(false); refocus(); }} className={btn} />
        </>
      )}
      </div>

      {caps.features?.includes("pip") && (
        <>
          <SectionLabel>Picture-in-picture</SectionLabel>
          <Toggle
            label="Keep playing in a small window"
            hint="When you press Home while something is on"
            checked={Boolean(caps.pipEnabled)}
            onChange={(v) => {
              setCaps((c) => ({ ...c, pipEnabled: v }));
              setPipEnabled(v).catch(() => setCaps((c) => ({ ...c, pipEnabled: !v })));
            }}
          />
        </>
      )}

      <SectionLabel hint="Channels, timetables, breaks, ratings and every setting, as one small file. The video files aren't included: link the same folders on the other device first.">
        Backup
      </SectionLabel>
      <button onClick={doBackup} disabled={busy} className={btn}>
        <Download size={14} /> Save a backup
      </button>
      <button onClick={() => fileRef.current?.click()} disabled={busy} className={btn}>
        <Upload size={14} /> Restore from a backup
      </button>
      <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" tabIndex={-1} onChange={onFile} />
      {status && (
        <p role="status" className="ps-inset px-3 py-2 text-xs font-bold text-[#ffe14d]">
          {status}
        </p>
      )}

      <SectionLabel>About</SectionLabel>
      <p className="ps-inset flex items-center gap-2 px-3 py-2.5 text-xs text-[#a9c3ee]">
        <Moon size={14} className="shrink-0 text-[#ffd21f]" />
        <span>
          Cathode Tube{import.meta.env.VITE_OTA_VERSION ? ` · build ${import.meta.env.VITE_OTA_VERSION}` : ""}
          {isNative() && caps.features?.length ? ` · app features: ${caps.features.join(", ")}` : ""}
        </span>
      </p>

      {pin && (
        <PinPad
          mode={pin.mode}
          title={pin.title}
          check={(p) => p === parental.pin}
          onDone={(p) => {
            const then = pin.then;
            setPin(null);
            then(p);
            refocus();
          }}
          onClose={() => {
            setPin(null);
            pendingRestore.current = null;
            refocus();
          }}
        />
      )}
    </div>
  );
}

export default memo(SystemTab);
