import React, { memo, useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Link2, FilePlus, FolderPlus, Play, Trash2, Film, Music, Folder, Volume2, Zap, Scissors, RefreshCw, Wand2, Info, Captions } from "lucide-react";
import BreakEditor from "@/components/BreakEditor";
import BatchBreakScan from "@/components/BatchBreakScan";
import ShowMatch from "@/components/ShowMatch";
import { episodeMeta, showMeta, useEpisodeInfo, matchedId } from "@/lib/episodeInfo";
import { hasSubtitles } from "@/lib/subtitles";
import { canLinkFolders } from "@/lib/linkedFolder";
import { isNative } from "@/native/platform";
import { formatClock, RATINGS } from "@/lib/schedule";
import { useBackHandler } from "@/components/tv/backStack";
import { Cycler, SliderRow, ConfirmButton, SectionLabel, NavRow } from "@/components/tv/controls";
import { focusFirst, refocus } from "@/lib/spatialNav";

export const LOOSE = "__loose__";
const PAGE = 50;
const order = new Intl.Collator(undefined, { numeric: true, sensitivity: "base" });
const keyOf = (m) => m.show || LOOSE;
export const showTitle = (key) => (key === LOOSE ? "Loose files" : key);
export const boostLabel = (db) => (db > 0 ? `+${db} dB` : "Off");

function formatSize(bytes) {
  if (bytes > 1e9) return `${(bytes / 1e9).toFixed(1)} GB`;
  if (bytes > 1e6) return `${(bytes / 1e6).toFixed(0)} MB`;
  return `${Math.max(1, Math.round((bytes || 0) / 1e3))} KB`;
}

const actionCls = "ps-btn flex min-h-11 items-center justify-center gap-2 px-3 text-sm";
const RATING_OPTIONS = [{ value: "", label: "Not set" }, ...RATINGS.map((r) => ({ value: r, label: r }))];
const AUTO_OPTIONS = [0, 1, 2, 3, 4].map((n) => ({ value: n, label: n ? `${n} per episode` : "Off" }));

function ShowList({ groups, total, playingShow, boost, importing, onOpenShow, onAddFiles, onLink, onQuickPlay, onRescan, rescanStatus }) {
  const fileRef = useRef(null);
  const folderRef = useRef(null);
  const quickRef = useRef(null);
  const pick = (e) => {
    onAddFiles(Array.from(e.target.files || []));
    e.target.value = "";
  };
  const linkable = canLinkFolders();

  return (
    <div className="flex flex-col gap-2">
      <div className="grid grid-cols-2 gap-2">
        {linkable && (
          <button onClick={onLink} disabled={Boolean(importing)} data-nav-default={groups.length === 0 || undefined} className={`${actionCls.replace("ps-btn", "ps-btn-primary")} col-span-2`}>
            <Link2 size={15} /> Link a shows folder
          </button>
        )}
        <button onClick={() => fileRef.current?.click()} disabled={Boolean(importing)} className={actionCls}>
          <FilePlus size={15} /> Add files
        </button>
        {!isNative() ? (
          <button onClick={() => folderRef.current?.click()} disabled={Boolean(importing)} className={actionCls}>
            <FolderPlus size={15} /> Copy a folder
          </button>
        ) : null}
        <button onClick={() => quickRef.current?.click()} className={`${actionCls} ${isNative() ? "" : "col-span-2"}`}>
          <Zap size={15} /> Quick play
        </button>
        <input ref={fileRef} type="file" accept="video/*,audio/*" multiple className="hidden" onChange={pick} tabIndex={-1} />
        <input ref={folderRef} type="file" webkitdirectory="" multiple className="hidden" onChange={pick} tabIndex={-1} />
        <input
          ref={quickRef}
          type="file"
          accept="video/*,audio/*"
          className="hidden"
          tabIndex={-1}
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onQuickPlay(f);
            e.target.value = "";
          }}
        />
      </div>
      {onRescan && groups.length > 0 && (
        <button onClick={onRescan} disabled={Boolean(importing)} className={actionCls}>
          <RefreshCw size={15} /> Rescan linked folders
        </button>
      )}
      {rescanStatus && (
        <p role="status" className="ps-inset px-3 py-2 text-[11px] font-bold text-[#ffe14d]">
          {rescanStatus}
        </p>
      )}
      {linkable && groups.length === 0 && (
        <p className="px-1 text-[11px] leading-snug text-[#a9c3ee]">
          Pick the folder that holds your shows (Show / Season / episodes). Nothing is copied: files stay where they are.
        </p>
      )}
      {importing && (
        <p role="status" className="ps-inset px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-[#ffe14d]">
          Adding {importing.done} of {importing.total}…
        </p>
      )}

      {groups.length > 0 && (
        <SectionLabel>
          {groups.filter((g) => g.key !== LOOSE).length} shows · {total} files
        </SectionLabel>
      )}
      {groups.map((g) => {
        const db = g.key === LOOSE ? 0 : boost[g.key] || 0;
        const playing = playingShow === g.key;
        return (
          <button
            key={g.key}
            onClick={() => onOpenShow(g.key)}
            data-nav-key={`show:${g.key}`}
            data-on={playing || undefined}
            className="ps-row flex min-h-12 items-center gap-3 px-3 py-2 text-left"
          >
            {g.poster ? (
              <img src={g.poster} alt="" className="h-9 w-6 shrink-0 rounded-sm object-cover" />
            ) : (
              <Folder size={16} className="shrink-0 text-[#ffd21f]" />
            )}
            <span className="min-w-0 flex-1">
              <span className="ps-label block truncate text-sm">{showTitle(g.key)}</span>
              <span className="ps-hint block truncate text-[11px]">
                {g.seasons > 1 ? `${g.seasons} seasons · ` : ""}
                {g.count} {g.count === 1 ? "file" : "files"}
              </span>
            </span>
            {db > 0 && (
              <span className="ps-value flex shrink-0 items-center gap-1 text-[11px]">
                <Volume2 size={11} /> +{db}
              </span>
            )}
            {g.rating && <span className="ps-value shrink-0 text-[11px]">{g.rating}</span>}
            {playing && <Play size={13} className="shrink-0" />}
          </button>
        );
      })}
    </div>
  );
}

function ShowPage({ showKey, files, activeId, boostDb, rating, autoBreaks, infoOn, onMatch, onBack, onBoost, onRating, onAutoBreaks, onSetBreaks, onPlay, onPlayShow, onRemove, onRemoveShow }) {
  const [editingBreaks, setEditingBreaks] = useState(null);
  const [batch, setBatch] = useState(false);
  const [matching, setMatching] = useState(false);
  const meta = showKey !== LOOSE ? showMeta(showKey) : null;
  const rootRef = useRef(null);
  const [season, setSeason] = useState("");
  const [shown, setShown] = useState(PAGE);
  const seasons = useMemo(() => [...new Set(files.map((m) => m.season).filter(Boolean))].sort(order.compare), [files]);
  const list = useMemo(() => (season ? files.filter((m) => m.season === season) : files), [files, season]);
  const totalTime = useMemo(() => files.reduce((t, m) => t + (m.duration || 0), 0), [files]);

  useBackHandler(() => {
    onBack();
    return true;
  });
  useEffect(() => {
    requestAnimationFrame(() => focusFirst(rootRef.current));
  }, [showKey]);
  useEffect(() => setShown(PAGE), [season]);

  return (
    <div ref={rootRef} className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <button onClick={onBack} className="ps-btn flex min-h-10 shrink-0 items-center gap-1.5 px-3 text-sm" aria-label="Back to shows">
          <ArrowLeft size={15} /> Shows
        </button>
        {meta?.poster && <img src={meta.poster} alt="" className="h-12 w-8 shrink-0 rounded-sm border border-[#4a7bd4] object-cover" />}
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-sm font-bold text-white">{showTitle(showKey)}</h3>
          <p className="truncate text-[11px] text-[#a9c3ee]">
            {files.length} files{totalTime ? ` · ${formatClock(totalTime)}` : ""}
            {meta ? ` · ${[meta.premiered?.slice(0, 4), meta.network].filter(Boolean).join(" · ")}` : ""}
          </p>
        </div>
      </div>

      <button
        data-nav-default
        onClick={() => onPlayShow(list)}
        disabled={!list.length}
        className="ps-btn-primary flex min-h-11 items-center justify-center gap-2 px-3 text-sm disabled:opacity-40"
      >
        <Play size={15} /> Play {season || "from the start"}
      </button>

      {showKey !== LOOSE && (
        <SliderRow
          label="Audio boost"
          hint="For quiet shows. Remembered for every episode."
          value={boostDb}
          min={0}
          max={12}
          step={1}
          onChange={(v) => onBoost(showKey, v)}
          display={boostLabel(boostDb)}
        />
      )}
      {showKey !== LOOSE && (
        <>
          <Cycler label="Classification" hint="Shown in the corner as episodes start" value={rating || ""} options={RATING_OPTIONS} onChange={(v) => onRating(showKey, v)} />
          <Cycler label="Automatic breaks" hint="Evenly spaced, for episodes without their own" value={autoBreaks || 0} options={AUTO_OPTIONS} onChange={(v) => onAutoBreaks(showKey, v)} />
          <NavRow
            label="Find breaks in every episode"
            hint="Scans for the black gaps where ads were. Skips episodes with breaks set by hand."
            icon={<Wand2 size={16} className="text-[#a9c3ee]" />}
            navKey="batch-breaks"
            onClick={() => setBatch(true)}
          />
          {infoOn && (
            <NavRow
              label="Episode info"
              hint="Episode names and poster from TVmaze"
              icon={<Info size={16} className="text-[#a9c3ee]" />}
              value={meta ? meta.title : matchedId(showKey) === 0 ? "Off for this show" : "Not found"}
              navKey="show-match"
              onClick={() => setMatching(true)}
            />
          )}
        </>
      )}

      {seasons.length > 1 && (
        <Cycler label="Season" value={season} options={[{ value: "", label: `All (${seasons.length})` }, ...seasons.map((s) => ({ value: s, label: s }))]} onChange={setSeason} />
      )}

      <SectionLabel>
        {season || "Episodes"} · {list.length}
      </SectionLabel>
      {list.slice(0, shown).map((m) => {
        const active = m.id === activeId;
        const ep = episodeMeta(m);
        return (
          <div key={m.id} className="flex items-stretch gap-2" data-episode={m.id}>
            <button
              onClick={() => onPlay(m, list)}
              data-on={active || undefined}
              className="ps-row flex min-w-0 flex-1 items-center gap-3 px-3 py-2 text-left"
            >
              {m.type?.startsWith("audio") ? <Music size={14} className="shrink-0 text-[#ffd21f]" /> : <Film size={14} className="shrink-0 text-[#ffd21f]" />}
              <span className="min-w-0 flex-1">
                <span className="ps-label block truncate text-sm">{ep?.title ? `${ep.code} · ${ep.title}` : m.name}</span>
                <span className="ps-hint flex items-center gap-1 truncate text-[11px]">
                  {hasSubtitles(m) && <Captions size={12} className="shrink-0" aria-label="Has captions" />}
                  <span className="truncate">
                    {[ep?.title && m.name, !season && m.season, m.duration ? formatClock(m.duration) : "Unreadable", formatSize(m.size)].filter(Boolean).join(" · ")}
                  </span>
                </span>
              </span>
              {active && <Play size={13} className="shrink-0" />}
            </button>
            <button
              onClick={() => setEditingBreaks(m)}
              data-act="breaks"
              className="ps-btn flex w-14 shrink-0 flex-col items-center justify-center gap-0.5 !rounded-[10px] text-[10px]"
              aria-label={`Breaks for ${m.name}: ${m.breaks?.length || 0}`}
            >
              <Scissors size={14} />
              {m.manualBreaks ? m.breaks.length : m.breaks?.length ? `${m.breaks.length} auto` : "Breaks"}
            </button>
            <ConfirmButton
              label={`Remove ${m.name}`}
              confirmLabel={`Press again to remove ${m.name}`}
              onConfirm={() => {
                const i = list.indexOf(m);
                const next = list[i + 1] || list[i - 1];
                onRemove(m);
                if (next) refocus(`[data-episode="${next.id}"] button`, "[data-nav-default]");
              }}
              className="ps-btn flex w-12 shrink-0 items-center justify-center !rounded-[10px]"
            >
              {(armed) => (armed ? <span className="text-[10px] leading-tight">Again</span> : <Trash2 size={15} />)}
            </ConfirmButton>
          </div>
        );
      })}
      {list.length > shown && (
        <button onClick={() => setShown((n) => n + PAGE * 2)} className="ps-btn min-h-10 text-[11px] uppercase">
          Show more ({list.length - shown} left)
        </button>
      )}

      <ConfirmButton
        label={showKey === LOOSE ? "Remove these files from the library" : "Remove show from library"}
        confirmLabel="Press again to remove"
        onConfirm={() => onRemoveShow(files)}
        className="ps-btn mt-3 flex min-h-11 items-center justify-center gap-2 text-sm"
      >
        {(armed) => (
          <>
            <Trash2 size={14} /> {armed ? "Press again to remove" : showKey === LOOSE ? "Remove these files from the library" : "Remove show from library"}
          </>
        )}
      </ConfirmButton>
      <p className="px-1 text-center text-[10px] text-[#8fa9d8]">Linked files stay on your device. This only takes them out of the app.</p>
      {batch && (
        <BatchBreakScan
          files={list}
          onSave={onSetBreaks}
          onClose={() => {
            setBatch(false);
            requestAnimationFrame(() => document.querySelector('[data-nav-key="batch-breaks"]')?.focus());
          }}
        />
      )}
      {matching && (
        <ShowMatch
          show={showKey}
          onPick={(id) => {
            onMatch(showKey, id);
            setMatching(false);
            requestAnimationFrame(() => document.querySelector('[data-nav-key="show-match"]')?.focus());
          }}
          onClose={() => {
            setMatching(false);
            requestAnimationFrame(() => document.querySelector('[data-nav-key="show-match"]')?.focus());
          }}
        />
      )}
      {editingBreaks && (
        <BreakEditor
          record={files.find((f) => f.id === editingBreaks.id) || editingBreaks}
          seasonFiles={files.filter((f) => f.season === editingBreaks.season)}
          onSave={onSetBreaks}
          onClose={() => {
            const id = editingBreaks.id;
            setEditingBreaks(null);
            requestAnimationFrame(() => document.querySelector(`[data-episode="${id}"] [data-act="breaks"]`)?.focus());
          }}
        />
      )}
    </div>
  );
}

function LibraryTab({ media, activeId, playingShow, importing, boost, ratings = {}, autoBreaks = {}, openShow, onOpenShow, onBoost, onRating, onAutoBreaks, onSetBreaks, onPlay, onPlayList, onRemove, onRemoveMany, onAddFiles, onLink, onQuickPlay, infoOn = false, onMatch, onRescan, rescanStatus }) {
  const infoVersion = useEpisodeInfo();
  const byShow = useMemo(() => {
    const map = new Map();
    for (const m of media) {
      const k = keyOf(m);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(m);
    }
    for (const list of map.values()) list.sort((a, b) => order.compare(a.season || "", b.season || "") || order.compare(a.name, b.name));
    return map;
  }, [media]);

  const groups = useMemo(
    () =>
      [...byShow.entries()]
        .map(([key, list]) => ({
          key,
          count: list.length,
          seasons: new Set(list.map((m) => m.season).filter(Boolean)).size,
          rating: ratings[key],
          poster: key !== LOOSE ? showMeta(key)?.poster : null,
        }))
        .sort((a, b) => (a.key === LOOSE) - (b.key === LOOSE) || order.compare(a.key, b.key)),
    [byShow, ratings, infoVersion] // eslint-disable-line react-hooks/exhaustive-deps
  );

  const files = openShow ? byShow.get(openShow) : null;
  // The show was removed (or emptied): fall back to the list.
  useEffect(() => {
    if (openShow && !files) onOpenShow(null);
  }, [openShow, files, onOpenShow]);

  if (openShow && files) {
    return (
      <ShowPage
        showKey={openShow}
        files={files}
        activeId={activeId}
        boostDb={openShow === LOOSE ? 0 : boost[openShow] || 0}
        rating={ratings[openShow]}
        autoBreaks={autoBreaks[openShow]}
        infoOn={infoOn}
        onMatch={onMatch}
        onBack={() => onOpenShow(null)}
        onBoost={onBoost}
        onRating={onRating}
        onAutoBreaks={onAutoBreaks}
        onSetBreaks={onSetBreaks}
        onPlay={onPlay}
        onPlayShow={onPlayList}
        onRemove={onRemove}
        onRemoveShow={onRemoveMany}
      />
    );
  }
  return (
    <ShowList
      groups={groups}
      total={media.length}
      playingShow={playingShow}
      boost={boost}
      importing={importing}
      onOpenShow={onOpenShow}
      onAddFiles={onAddFiles}
      onLink={onLink}
      onQuickPlay={onQuickPlay}
      onRescan={onRescan}
      rescanStatus={rescanStatus}
    />
  );
}

export default memo(LibraryTab);
