import React, { memo } from "react";
import { SliderRow, Toggle, SectionLabel, ConfirmButton } from "@/components/tv/controls";
import { boostLabel } from "@/components/menu/LibraryTab";

function SoundTab({ prefs, update, currentShow, onBoost }) {
  // Shows stay listed at "Off" until cleared, so a slider never vanishes mid-change.
  const boosted = Object.entries(prefs.boost)
    .filter(([show]) => show !== currentShow)
    .sort(([a], [b]) => a.localeCompare(b));
  const pct = Math.round(prefs.volume * 100);

  return (
    <div className="flex flex-col gap-2">
      <SliderRow
        label="Volume"
        value={prefs.volume}
        min={0}
        max={1}
        step={0.05}
        display={prefs.muted ? "Muted" : `${pct}%`}
        hint="While watching: Left / Right on the d-pad"
        onChange={(v) => update({ volume: v, muted: false })}
      />
      <Toggle label="Mute" hint="X on a controller, M on a keyboard" checked={prefs.muted} onChange={(m) => update({ muted: m })} />

      <SectionLabel hint="Like a TV's auto volume: each show's loudness is learned while it plays, then quiet and loud shows (and ads) are brought to a similar level.">
        Auto volume
      </SectionLabel>
      <Toggle label="Even out loudness" hint={`${Object.keys(prefs.loudness || {}).length} shows measured so far`} checked={prefs.autoLevel} onChange={(v) => update({ autoLevel: v })} />
      {prefs.autoLevel && Object.keys(prefs.loudness || {}).length > 0 && (
        <ConfirmButton
          label="Forget measured levels"
          confirmLabel="Press again to forget"
          onConfirm={() => update({ loudness: {} })}
          className="ps-btn flex min-h-11 items-center justify-center text-sm"
        />
      )}

      <SectionLabel hint="Lifts quiet shows on top of auto volume. Each show remembers its own boost.">Audio boost</SectionLabel>
      {currentShow ? (
        <SliderRow
          label={`Now playing: ${currentShow}`}
          value={prefs.boost[currentShow] || 0}
          min={0}
          max={12}
          step={1}
          display={boostLabel(prefs.boost[currentShow] || 0)}
          onChange={(v) => onBoost(currentShow, v)}
        />
      ) : (
        <p className="ps-inset px-3 py-2.5 text-xs text-[#a9c3ee]">
          Play a show to boost it here, or open any show in Library.
        </p>
      )}
      {boosted.map(([show, db]) => (
        <SliderRow key={show} label={show} value={db} min={0} max={12} step={1} display={boostLabel(db)} onChange={(v) => onBoost(show, v)} />
      ))}
      {Object.keys(prefs.boost).length > 0 && (
        <ConfirmButton
          label="Clear all boosts"
          confirmLabel="Press again to clear"
          onConfirm={() => update({ boost: {} })}
          className="ps-btn flex min-h-11 items-center justify-center text-sm"
        />
      )}

      <SectionLabel>Channel changes</SectionLabel>
      <Toggle label="Static between channels" hint="Snow and a channel number while the next one tunes in" checked={prefs.staticOnSwitch} onChange={(v) => update({ staticOnSwitch: v })} />
      <Toggle label="Static sound" hint="A short hiss with the static" checked={prefs.staticSound} onChange={(v) => update({ staticSound: v })} />
    </div>
  );
}

export default memo(SoundTab);
