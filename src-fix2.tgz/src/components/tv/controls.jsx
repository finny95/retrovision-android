import React, { useCallback, useEffect, useRef, useState } from "react";
import { flushSync } from "react-dom";
import { ChevronLeft, ChevronRight, Minus, Plus } from "lucide-react";
import Picker from "@/components/tv/Picker";

// TV-style settings rows. Every row is one focus stop: Up/Down moves between
// rows, Left/Right changes the value, A opens/toggles.

export const rowCls =
  "flex min-h-12 w-full items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 text-left transition hover:border-white/25 focus:border-amber-400/70 focus:bg-amber-400/[0.06]";

export function SectionLabel({ children, hint }) {
  return (
    <div className="px-1 pt-2">
      <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-neutral-400">{children}</p>
      {hint && <p className="mt-0.5 text-[11px] leading-snug text-neutral-500">{hint}</p>}
    </div>
  );
}

// Pick one of several options. Long lists open a Picker on A / tap.
export function Cycler({ label, value, options, onChange, hint }) {
  const ref = useRef(null);
  const [picking, setPicking] = useState(false);
  const idx = Math.max(0, options.findIndex((o) => o.value === value));
  const current = options[idx];

  const step = useCallback(
    (dir) => {
      if (!options.length) return;
      onChange(options[(idx + dir + options.length) % options.length].value);
    },
    [idx, options, onChange]
  );

  useEffect(() => {
    const el = ref.current;
    const on = (e) => step(e.detail);
    el?.addEventListener("nav-adjust", on);
    return () => el?.removeEventListener("nav-adjust", on);
  }, [step]);

  const open = () => (options.length > 4 ? setPicking(true) : step(1));
  const refocus = () => requestAnimationFrame(() => ref.current?.focus());

  return (
    <>
      <div
        ref={ref}
        tabIndex={0}
        data-adjust
        role="button"
        aria-label={`${label}: ${current?.label ?? ""}`}
        onClick={open}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            open();
          }
        }}
        className={`${rowCls} cursor-pointer select-none`}
      >
        <span className="min-w-0">
          <span className="block text-sm text-neutral-200">{label}</span>
          {hint && <span className="block text-[11px] text-neutral-500">{hint}</span>}
        </span>
        <span className="flex max-w-[55%] shrink-0 items-center gap-1 text-amber-300">
          <button
            tabIndex={-1}
            onClick={(e) => {
              e.stopPropagation();
              step(-1);
            }}
            className="rounded p-1 text-neutral-400 hover:text-amber-200"
            aria-label={`Previous ${label}`}
          >
            <ChevronLeft size={16} />
          </button>
          <span className="min-w-0 truncate text-sm">{current?.label ?? "—"}</span>
          <button
            tabIndex={-1}
            onClick={(e) => {
              e.stopPropagation();
              step(1);
            }}
            className="rounded p-1 text-neutral-400 hover:text-amber-200"
            aria-label={`Next ${label}`}
          >
            <ChevronRight size={16} />
          </button>
        </span>
      </div>
      {picking && (
        <Picker
          title={label}
          options={options}
          value={value}
          onPick={(v) => {
            onChange(v);
            setPicking(false);
            refocus();
          }}
          onClose={() => {
            setPicking(false);
            refocus();
          }}
        />
      )}
    </>
  );
}

export function Toggle({ label, hint, checked, onChange }) {
  return (
    <button role="switch" aria-checked={checked} onClick={() => onChange(!checked)} className={rowCls}>
      <span className="min-w-0">
        <span className="block text-sm text-neutral-200">{label}</span>
        {hint && <span className="block text-[11px] text-neutral-500">{hint}</span>}
      </span>
      <span
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${checked ? "bg-amber-400" : "bg-white/15"}`}
        aria-hidden
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-neutral-950 transition-all ${checked ? "left-[1.375rem]" : "left-0.5"}`}
        />
      </span>
    </button>
  );
}

// A labelled slider row. The <input> itself is the focus stop, so a controller's
// Left/Right adjusts it and Up/Down moves on.
export function SliderRow({ label, value, min, max, step, onChange, display, hint }) {
  const pct = max > min ? ((value - min) / (max - min)) * 100 : 0;
  return (
    <label className="flex flex-col gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 has-[:focus]:border-amber-400/70 has-[:focus]:bg-amber-400/[0.06]">
      <span className="flex items-center justify-between gap-3">
        <span className="text-sm text-neutral-200">{label}</span>
        <span className="font-mono text-xs tabular-nums text-amber-300">{display ?? value}</span>
      </span>
      {hint && <span className="-mt-1 text-[11px] leading-snug text-neutral-500">{hint}</span>}
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        aria-label={label}
        className="tv-range w-full cursor-pointer"
        style={{ "--pct": `${pct}%` }}
      />
    </label>
  );
}

// A number you nudge with Left/Right (or the - / + buttons on touch).
export function Stepper({ label, value, min, max, onChange, format = (v) => v, hint }) {
  const ref = useRef(null);
  const clamp = useCallback((v) => Math.min(max, Math.max(min, v)), [min, max]);
  useEffect(() => {
    const el = ref.current;
    const on = (e) => onChange(clamp(value + e.detail));
    el?.addEventListener("nav-adjust", on);
    return () => el?.removeEventListener("nav-adjust", on);
  }, [value, onChange, clamp]);
  return (
    <div ref={ref} tabIndex={0} data-adjust role="spinbutton" aria-valuenow={value} aria-valuemin={min} aria-valuemax={max} aria-label={label} className={`${rowCls} select-none`}>
      <span className="min-w-0">
        <span className="block text-sm text-neutral-200">{label}</span>
        {hint && <span className="block text-[11px] text-neutral-500">{hint}</span>}
      </span>
      <span className="flex items-center gap-1">
        <button tabIndex={-1} onClick={() => onChange(clamp(value - 1))} disabled={value <= min} className="rounded-full border border-white/10 p-1.5 text-neutral-300 hover:text-amber-200 disabled:opacity-30" aria-label={`Decrease ${label}`}>
          <Minus size={14} />
        </button>
        <span className="min-w-[2.5rem] text-center font-mono text-sm tabular-nums text-amber-300">{format(value)}</span>
        <button tabIndex={-1} onClick={() => onChange(clamp(value + 1))} disabled={value >= max} className="rounded-full border border-white/10 p-1.5 text-neutral-300 hover:text-amber-200 disabled:opacity-30" aria-label={`Increase ${label}`}>
          <Plus size={14} />
        </button>
      </span>
    </div>
  );
}

// A row that opens something (sub-page, picker). Shows its current value on the right.
export function NavRow({ label, value, hint, onClick, icon, navKey, className = "", children }) {
  return (
    <button onClick={onClick} data-nav-key={navKey} className={`${rowCls} ${className}`}>
      <span className="flex min-w-0 items-center gap-3">
        {icon}
        <span className="min-w-0">
          <span className="block truncate text-sm text-neutral-100">{label}</span>
          {hint && <span className="block truncate text-[11px] text-neutral-500">{hint}</span>}
        </span>
      </span>
      <span className="flex min-w-0 shrink items-center gap-1 text-amber-300">
        {children}
        {value != null && <span className="max-w-[10rem] truncate text-sm">{value}</span>}
        <ChevronRight size={16} className="shrink-0 text-neutral-500" />
      </span>
    </button>
  );
}

// Destructive action: first press arms it, second press within 3 s does it.
export function ConfirmButton({ label, confirmLabel = "Press again to confirm", onConfirm, className = "", children }) {
  const [armed, setArmed] = useState(false);
  useEffect(() => {
    if (!armed) return undefined;
    const t = setTimeout(() => setArmed(false), 3000);
    return () => clearTimeout(t);
  }, [armed]);
  return (
    <button
      onClick={() => {
        if (armed) {
          setArmed(false);
          onConfirm();
        } else setArmed(true);
      }}
      onBlur={() => setArmed(false)}
      aria-label={armed ? confirmLabel : label}
      className={`${className} ${armed ? "!border-red-500/70 !bg-red-500/15 !text-red-200" : ""}`}
    >
      {children ? children(armed) : armed ? confirmLabel : label}
    </button>
  );
}

// Small key-cap used in hint legends.
export function Key({ children }) {
  return (
    <kbd className="inline-flex min-w-[1.4rem] items-center justify-center rounded border border-white/25 bg-white/5 px-1 py-px font-mono text-[10px] font-normal not-italic text-neutral-200">
      {children}
    </kbd>
  );
}

// Text you rarely type (a channel name). Shown as a row; A / tap turns it into a
// text box so the on-screen keyboard only appears when you ask for it.
export function TextRow({ label, value, placeholder, onChange, navDefault = false, maxLength = 40 }) {
  const [editing, setEditing] = useState(false);
  const inputRef = useRef(null);
  const buttonRef = useRef(null);
  const start = () => {
    flushSync(() => setEditing(true));
    inputRef.current?.focus();
    inputRef.current?.select();
  };
  const finish = (refocusRow) => {
    setEditing(false);
    if (refocusRow) requestAnimationFrame(() => buttonRef.current?.focus());
  };
  if (editing) {
    return (
      <label className={`${rowCls} cursor-text border-amber-400/70`}>
        <span className="shrink-0 text-sm text-neutral-200">{label}</span>
        <input
          ref={inputRef}
          value={value}
          maxLength={maxLength}
          onChange={(e) => onChange(e.target.value)}
          onBlur={() => finish(false)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === "Escape") {
              e.preventDefault();
              e.stopPropagation();
              finish(true);
            }
          }}
          placeholder={placeholder}
          enterKeyHint="done"
          className="min-w-0 flex-1 bg-transparent text-right text-sm text-amber-200 outline-none placeholder:text-neutral-600"
        />
      </label>
    );
  }
  return (
    <button ref={buttonRef} data-nav-default={navDefault || undefined} onClick={start} className={rowCls}>
      <span className="shrink-0 text-sm text-neutral-200">{label}</span>
      <span className={`min-w-0 truncate text-sm ${value ? "text-amber-200" : "text-neutral-500"}`}>{value || placeholder}</span>
    </button>
  );
}
