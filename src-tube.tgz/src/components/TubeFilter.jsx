import React, { useEffect, useRef, useState } from "react";
import { tubeActive, tubeMaps, tubeSource } from "@/lib/tubeUi";

const KEYS = ["curvature", "scanlineIntensity", "scanlineDensity", "vignette", "glow"];

function preload(url) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = img.onerror = () => resolve();
    img.src = url;
  });
}

function FilterDef({ id, maps }) {
  return (
    <filter id={id} x="0" y="0" width="1" height="1" filterUnits="objectBoundingBox" colorInterpolationFilters="sRGB">
      {maps.shade && <feImage href={maps.shade} preserveAspectRatio="none" result="shade" />}
      {maps.shade && <feComposite in="SourceGraphic" in2="shade" operator="arithmetic" k1={maps.boost} k2="0" k3="0" k4="0" result="lit" />}
      {maps.disp && <feImage href={maps.disp} preserveAspectRatio="none" result="map" />}
      {maps.disp && (
        <feDisplacementMap in={maps.shade ? "lit" : "SourceGraphic"} in2="map" scale={maps.scale} xChannelSelector="R" yChannelSelector="G" />
      )}
    </filter>
  );
}

// The tube for the DOM over the picture (see lib/tubeUi). boxRef: the screen
// (the box the CRT canvas fills). Returns the CSS filter to give elements with
// class "rv-tube" (via --rv-tube) and the <svg> holding it, to render once.
// Two filters take turns, so a new one is only switched to once its maps load.
export function useTube(boxRef, settings, enabled = true) {
  const on = Boolean(enabled && tubeActive(settings));
  const [size, setSize] = useState(null);
  useEffect(() => {
    const el = boxRef.current;
    if (!on || !el) return undefined;
    const measure = () => {
      const w = Math.round(el.clientWidth);
      const h = Math.round(el.clientHeight);
      if (w > 0 && h > 0) setSize((s) => (s && s.w === w && s.h === h ? s : { w, h }));
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [boxRef, on]);

  const dpr = typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1;
  const sig = on && size ? [size.w, size.h, dpr, ...KEYS.map((k) => settings[k])].join("|") : "";
  const [slots, setSlots] = useState([null, null]);
  const [active, setActive] = useState(-1);
  const activeRef = useRef(-1);
  activeRef.current = active;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  useEffect(() => {
    if (!sig) {
      setActive(-1);
      return undefined;
    }
    let dead = false;
    // A short wait so dragging a Picture slider doesn't rebuild on every step.
    const t = setTimeout(() => {
      const maps = tubeMaps({ width: size.w, height: size.h, dpr, settings: settingsRef.current });
      const next = activeRef.current === 0 ? 1 : 0;
      setSlots((s) => {
        const c = [...s];
        c[next] = maps;
        return c;
      });
      Promise.all([maps.shade, maps.disp].filter(Boolean).map(preload)).then(() =>
        setTimeout(() => {
          if (!dead) setActive(next);
        }, 80)
      );
    }, activeRef.current < 0 ? 0 : 150);
    return () => {
      dead = true;
      clearTimeout(t);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig]);

  const filter = on && active >= 0 && slots[active] ? `url(#rv-tube-${active})` : null;
  const curvature = filter && slots[active]?.disp ? settings.curvature : 0;

  // Taps: what you see at a point on the glass is the page from a little
  // further out, so send the click to that.
  useEffect(() => {
    if (!curvature) return undefined;
    const onClick = (e) => {
      if (!e.isTrusted) return;
      const host = e.target?.closest?.("[data-tube]");
      if (!host) return;
      const r = host.getBoundingClientRect();
      if (!r.width || !r.height) return;
      const [sx, sy] = tubeSource((e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height, curvature);
      const x = r.left + sx * r.width;
      const y = r.top + sy * r.height;
      if (Math.abs(x - e.clientX) < 2 && Math.abs(y - e.clientY) < 2) return;
      const t = document.elementFromPoint(x, y);
      if (!t || t === e.target) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      const focusable = t.closest?.("button, a[href], input, select, textarea, [tabindex]");
      if (focusable && document.activeElement !== focusable) focusable.focus?.({ preventScroll: true });
      t.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, detail: e.detail }));
    };
    window.addEventListener("click", onClick, true);
    return () => window.removeEventListener("click", onClick, true);
  }, [curvature]);

  const svg = (
    <svg aria-hidden="true" width="0" height="0" style={{ position: "absolute", width: 0, height: 0, overflow: "hidden", pointerEvents: "none" }}>
      <defs>{slots.map((m, i) => (m ? <FilterDef key={i} id={`rv-tube-${i}`} maps={m} /> : null))}</defs>
    </svg>
  );
  return { filter, svg, curved: Boolean(curvature) };
}
