import React, { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Lock, Bell, BellOff, Tv, Star, Newspaper } from "lucide-react";
import { Modal } from "@/components/tv/Picker";
import { useBackHandler } from "@/components/tv/backStack";
import { guideTimeline, programmeTitle, formatTimeOfDay } from "@/lib/schedule";
import { useNow } from "@/components/menu/ChannelsTab";
import { focusEl } from "@/lib/spatialNav";
import { episodeLine, useEpisodeInfo, showMeta, episodeMeta } from "@/lib/episodeInfo";

const SLOT = 30 * 60 * 1000;
const pad2 = (n) => String(n).padStart(2, "0");


export const reminderKey = (c, p) => `${c.id}|${p.startMs}`;

// A on a programme that's on later: watch the channel now, or get a reminder.
function ProgrammeActions({ channel, prog, reminded, onTune, onRemind, onClose }) {
  const bodyRef = useRef(null);
  useBackHandler(() => {
    onClose();
    return true;
  });
  useEffect(() => {
    requestAnimationFrame(() => focusEl(bodyRef.current?.querySelector("button")));
  }, []);
  const when = `${new Date(prog.startMs).toLocaleDateString(undefined, { weekday: "short" })} ${formatTimeOfDay(prog.startMs)}`;
  return (
    <Modal title={programmeTitle(prog)} subtitle={`${pad2(channel.number)} ${channel.name} · ${when}`} onClose={onClose} bodyRef={bodyRef} footer="A: choose · B: close">
      <button data-remind onClick={onRemind} className="ps-row flex min-h-12 items-center gap-3 px-3 text-left text-sm">
        {reminded ? <BellOff size={16} /> : <Bell size={16} />}
        <span className="ps-label">{reminded ? "Cancel the reminder" : `Remind me at ${formatTimeOfDay(prog.startMs)}`}</span>
      </button>
      <button onClick={onTune} className="ps-row flex min-h-12 items-center gap-3 px-3 text-left text-sm">
        <Tv size={16} />
        <span className="ps-label">Watch {pad2(channel.number)} {channel.name} now</span>
      </button>
    </Modal>
  );
}

// The TV guide: channels down the side, half-hour slots across, what's on in
// each. Up/Down changes channel row, Left/Right moves through programmes and
// pages the time window at the edges. A tunes to that channel (or, for something
// later, offers a reminder).
// pig: TV layout, the picture shows in the corner box (drawn there by CRTPlayer);
// the channel rows scroll under the top part so the box stays put. onPig: the
// box was tapped (back to watching).
export default function GuideTab({ channels: allChannels, media, activeId, onTune, pig = false, onPig, wide = false, isLocked, reminders = [], onRemind, onOpenText, favsOnly = false, onFavsOnly }) {
  const now = useNow(30000);
  useEpisodeInfo();
  const [acting, setActing] = useState(null); // { channel, prog }
  const hasFavs = allChannels.some((c) => c.fav);
  const channels = favsOnly && hasFavs ? allChannels.filter((c) => c.fav) : allChannels;
  const reminded = useMemo(() => new Set(reminders.map((r) => `${r.channelId}|${r.startMs}`)), [reminders]);
  const [page, setPage] = useState(0);
  const [focused, setFocused] = useState(null); // { channel, prog }
  const gridRef = useRef(null);
  const pendingFocus = useRef(null);
  const slots = wide ? 4 : 3;
  const start = Math.floor(now / SLOT) * SLOT + page * SLOT;
  const end = start + slots * SLOT;
  const span = end - start;

  const rows = useMemo(
    // Slivers (a programme ending a few seconds into the window) aren't worth a cell.
    () =>
      channels.map((c) => {
        const all = guideTimeline(c, media, start, end).filter((p) => p.endMs > start);
        // Only drop slivers cut off by the edge of the window (a show ending a few seconds in).
        const progs = all.filter((p) => Math.min(p.endMs, end) - Math.max(p.startMs, start) >= 90000 || (p.startMs >= start && p.endMs <= end));
        return { c, progs: progs.length ? progs : all };
      }),
    [channels, media, start, end]
  );

  // Page the window when Left/Right runs off the edge of the grid.
  useEffect(() => {
    const el = gridRef.current;
    const onEdge = (e) => {
      const row = document.activeElement?.closest?.("[data-guide-row]")?.dataset.guideRow;
      if (e.detail === "right" && page < 24) {
        pendingFocus.current = { row, at: "first" };
        setPage((p) => p + 1);
      } else if (e.detail === "left" && page > 0) {
        pendingFocus.current = { row, at: "last" };
        setPage((p) => p - 1);
      }
    };
    el?.addEventListener("nav-edge", onEdge);
    return () => el?.removeEventListener("nav-edge", onEdge);
  }, [page]);

  useEffect(() => {
    const want = pendingFocus.current;
    if (!want) return;
    pendingFocus.current = null;
    requestAnimationFrame(() => {
      const cells = gridRef.current?.querySelectorAll(`[data-guide-row="${want.row}"] [data-prog]`);
      if (cells?.length) focusEl(want.at === "first" ? cells[0] : cells[cells.length - 1]);
    });
  }, [start]);

  const info = focused || (() => {
    const r = rows.find((x) => x.c.id === activeId) || rows[0];
    const p = r?.progs.find((x) => x.startMs <= now && now < x.endMs) || r?.progs[0];
    return r && p ? { channel: r.c, prog: p } : null;
  })();
  const live = info && info.prog.startMs <= now && now < info.prog.endMs;
  const poster = info?.prog.media?.show ? showMeta(info.prog.media.show)?.poster : null;

  return (
    <div className={`flex flex-col gap-2 ${pig ? "h-full min-h-0" : ""}`}>
      {/* Buttons and what's focused on the left, the picture in its box on the right.
          With the box, the box sets the height (the left side fits in beside it), so
          the rows below get the rest of the screen and nothing pushes the box away. */}
      <div className="flex gap-3">
        <div className={`min-w-0 flex-1 ${pig ? "relative" : ""}`}>
        <div className={`flex flex-col gap-2 ${pig ? "absolute inset-0" : ""}`}>
          <div className="flex items-center gap-2" data-nav-row>
            <button data-guide-text onClick={onOpenText} className="ps-btn flex min-h-9 items-center gap-1.5 px-3 text-xs">
              <Newspaper size={14} /> Teletext
            </button>
            {hasFavs && (
              <button onClick={() => onFavsOnly?.(!favsOnly)} aria-pressed={favsOnly} className="ps-btn flex min-h-9 items-center gap-1.5 px-3 text-xs">
                <Star size={14} className={favsOnly ? "fill-[#ffd21f] text-[#ffd21f]" : ""} /> {favsOnly ? "Favourites" : "All channels"}
              </button>
            )}
            <span className="ml-auto truncate text-[10px] font-bold uppercase tracking-wider text-[#8fc4ff]">A: watch or remind</span>
          </div>
          <div className={`ps-inset flex min-w-0 flex-1 gap-3 overflow-hidden px-3 py-2 ${pig ? "min-h-0 items-start [@media(max-height:430px)]:py-1" : "min-h-[5.5rem] items-center"}`}>
            {poster && <img src={poster} alt="" className={`shrink-0 rounded border border-[#4a7bd4] object-cover ${pig ? "h-[min(12vw,20vh)] max-h-full w-auto" : "h-16 w-11"}`} />}
            <div className={`flex min-w-0 flex-1 flex-col justify-center gap-1 ${pig ? "[@media(max-height:430px)]:gap-0" : ""}`}>
              {info ? (
                <>
                  <p className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-[#8fc4ff]">
                    <span className="ps-btn-primary px-1.5 text-xs">{pad2(info.channel.number)}</span>
                    <span className="truncate">{info.channel.name}</span>
                    {live && <span className="rounded bg-[#e2231a] px-1.5 py-px text-[9px] text-white">On now</span>}
                    {isLocked?.(info.channel) && <Lock size={12} className="shrink-0 text-[#ffd21f]" aria-label="Locked" />}
                  </p>
                  <p className={`truncate text-lg font-bold leading-tight text-white ${pig ? "[@media(max-height:430px)]:text-base" : ""}`}>{programmeTitle(info.prog)}</p>
                  <p className="text-xs font-bold text-[#ffe14d]">
                    {formatTimeOfDay(info.prog.startMs)} - {formatTimeOfDay(info.prog.endMs)}
                  </p>
                  {info.prog.media && <p className={`truncate text-xs text-[#a9c3ee] ${pig ? "[@media(max-height:430px)]:hidden" : ""}`}>{episodeLine(info.prog.media)}</p>}
                </>
              ) : (
                <p className="text-sm text-[#a9c3ee]">No channels yet. Make one in Channels.</p>
              )}
            </div>
          </div>
        </div>
        </div>
        {pig && (
          <div
            data-pig-slot
            onClick={onPig}
            aria-label="Back to watching"
            className="aspect-video w-[min(36vw,52vh)] shrink-0 cursor-pointer rounded-lg border-2 border-[#4a7bd4] bg-black shadow-[inset_0_0_0_1px_rgba(0,0,0,0.6)]"
          />
        )}
      </div>

      {/* Time header */}
      <div className="flex items-stretch gap-1">
        <div className="ps-titlebar flex w-24 shrink-0 items-center justify-center rounded-md text-[11px] font-bold uppercase text-white">
          {new Date(start).toLocaleDateString(undefined, { weekday: "short", day: "numeric" })}
        </div>
        <div className="ps-titlebar relative flex flex-1 overflow-hidden rounded-md">
          {Array.from({ length: slots }, (_, k) => (
            <span key={k} className="flex-1 border-l border-[#0a1f55] px-1.5 py-1 text-[11px] font-bold text-white first:border-l-0">
              {formatTimeOfDay(start + k * SLOT)}
            </span>
          ))}
          {page > 0 && <ChevronLeft size={14} className="absolute left-0 top-1/2 -translate-y-1/2 text-[#ffd21f]" />}
          <ChevronRight size={14} className="absolute right-0 top-1/2 -translate-y-1/2 text-[#ffd21f]" />
        </div>
      </div>

      <div ref={gridRef} data-guide-grid className={`flex flex-col gap-1 ${pig ? "min-h-0 flex-1 overflow-y-auto overscroll-contain" : ""}`}>
        {rows.length === 0 && <p className="ps-inset p-3 text-center text-xs text-[#a9c3ee]">The guide fills in once you have channels.</p>}
        {rows.map(({ c, progs }) => (
          <div key={c.id} data-guide-row={c.id} data-nav-row className="flex items-stretch gap-1">
            <div className={`ps-inset flex w-24 shrink-0 items-center gap-1.5 px-1.5 ${c.id === activeId ? "!border-[#ffd21f]" : ""}`}>
              <span className="text-sm font-bold tabular-nums text-[#ffe14d]">{pad2(c.number)}</span>
              <span className="min-w-0 truncate text-[11px] font-bold text-white">{c.name}</span>
              {isLocked?.(c) && <Lock size={11} className="ml-auto shrink-0 text-[#ffd21f]" aria-label="Locked" />}
            </div>
            <div className="relative h-12 flex-1 overflow-hidden rounded-md bg-[#061436]">
              {progs.length === 0 && <span className="absolute inset-0 flex items-center px-2 text-[11px] text-[#6f8cc4]">No programmes</span>}
              {progs.map((p) => {
                const left = (Math.max(p.startMs, start) - start) / span;
                const right = (Math.min(p.endMs, end) - start) / span;
                const isNow = p.startMs <= now && now < p.endMs;
                return (
                  <button
                    key={p.startMs}
                    data-prog
                    data-start={p.startMs}
                    data-on={isNow || undefined}
                    data-nav-default={(isNow && (c.id === activeId || (!activeId && c === rows[0].c))) || undefined}
                    onFocus={() => setFocused({ channel: c, prog: p })}
                    onClick={() => (p.startMs > now + 60000 && p.kind === "show" ? setActing({ channel: c, prog: p }) : onTune(c))}
                    className="ps-row !absolute inset-y-0 flex min-w-0 flex-col justify-center overflow-hidden !rounded-md px-1.5 text-left"
                    style={{ left: `${left * 100}%`, width: `calc(${(right - left) * 100}% - 2px)` }}
                    aria-label={`${c.name}: ${programmeTitle(p)} at ${formatTimeOfDay(p.startMs)}`}
                  >
                    <span className="ps-label flex min-w-0 items-center gap-1 truncate text-xs leading-tight">
                      {reminded.has(reminderKey(c, p)) && <Bell size={10} className="shrink-0" aria-label="Reminder set" />}
                      <span className="truncate">{programmeTitle(p)}</span>
                    </span>
                    <span className="ps-hint truncate text-[10px] leading-tight">
                      {formatTimeOfDay(p.startMs)}
                      {p.media && episodeMeta(p.media) ? ` · ${episodeMeta(p.media).code}` : ""}
                    </span>
                  </button>
                );
              })}
              {now >= start && now < end && (
                <span className="pointer-events-none absolute inset-y-0 w-0.5 bg-[#e2231a] shadow-[0_0_6px_#e2231a]" style={{ left: `${((now - start) / span) * 100}%` }} />
              )}
            </div>
          </div>
        ))}
      </div>
      {acting && (
        <ProgrammeActions
          channel={acting.channel}
          prog={acting.prog}
          reminded={reminded.has(reminderKey(acting.channel, acting.prog))}
          onTune={() => {
            setActing(null);
            onTune(acting.channel);
          }}
          onRemind={() => {
            onRemind?.(acting.channel, acting.prog);
            const key = `[data-guide-row="${acting.channel.id}"] [data-prog][data-start="${acting.prog.startMs}"]`;
            setActing(null);
            requestAnimationFrame(() => focusEl(gridRef.current?.querySelector(key)));
          }}
          onClose={() => {
            const key = `[data-guide-row="${acting.channel.id}"] [data-prog][data-start="${acting.prog.startMs}"]`;
            setActing(null);
            requestAnimationFrame(() => focusEl(gridRef.current?.querySelector(key)));
          }}
        />
      )}
    </div>
  );
}
