import React, { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Check, Trash2, ListOrdered, Shuffle } from "lucide-react";
import LineupEditor from "@/components/LineupEditor";
import BlockEditor from "@/components/BlockEditor";
import TimetableEditor from "@/components/TimetableEditor";
import { MultiPicker } from "@/components/tv/Picker";
import { Cycler, NavRow, Stepper, SectionLabel, ConfirmButton, TextRow, Toggle } from "@/components/tv/controls";
import { useBackHandler } from "@/components/tv/backStack";
import { generateLineup, formatClock, showEpisodes, dayIndex, newSeed } from "@/lib/schedule";
import { focusFirst } from "@/lib/spatialNav";

const PLAYLIST_EPOCH = new Date("2000-01-01T00:00:00Z").getTime();
const isRecent = (epoch) => epoch > Date.UTC(2001, 0, 1);

// Block channels walk their schedule forward from the epoch (cycle lengths vary
// with the random picks), so they start today. Playlists keep the fixed 2000 epoch.
function pickEpoch(initial, isBlocks) {
  if (isBlocks) return isRecent(initial?.epoch) ? initial.epoch : new Date().setHours(0, 0, 0, 0);
  return isRecent(initial?.epoch) ? PLAYLIST_EPOCH : initial?.epoch || PLAYLIST_EPOCH;
}

const listLabel = (list, none) => (list.length === 0 ? none : list.length === 1 ? list[0] : `${list.length} picked`);

const MODES = [
  { value: "playlist", label: "Playlist" },
  { value: "blocks", label: "Blocks" },
  { value: "timetable", label: "Timetable" },
  { value: "weather", label: "Weather" },
];
const MODE_HINT = {
  playlist: "Fixed episode list that loops",
  blocks: "Set order of shows, random episodes",
  timetable: "Shows booked at set times of day",
  weather: "Local forecast around the clock, with music",
};
const FILLER = [
  { value: "testcard", label: "Test card" },
  { value: "ads", label: "Ads and promos" },
];
const ORDERS = [
  { value: false, label: "In order" },
  { value: true, label: "Shuffle" },
];

export default function ChannelEditor({ initial, shows, media, nextNumber, onSave, onCancel, onDelete, hasPin = false }) {
  const rootRef = useRef(null);
  const [name, setName] = useState(initial?.name || "");
  const [logoText, setLogoText] = useState(initial?.logoText || "");
  const [number, setNumber] = useState(initial?.number ?? nextNumber);
  const [chShows, setChShows] = useState(initial?.shows || []);
  const [adShows, setAdShows] = useState(initial?.adShows || []);
  const [adsPerBreak, setAdsPerBreak] = useState(initial?.adsPerBreak ?? 2);
  const [lineup, setLineup] = useState(initial?.lineup || null);
  const [shuffle, setShuffle] = useState(initial?.shuffle ?? false);
  const [mode, setMode] = useState(initial?.weather ? "weather" : initial?.timetable ? "timetable" : initial?.blocks?.length ? "blocks" : "playlist");
  const [musicShow, setMusicShow] = useState(initial?.musicShow || "");
  const [blocks, setBlocks] = useState(initial?.blocks || []);
  const [slots, setSlots] = useState(initial?.timetable?.slots || []);
  const [filler, setFiller] = useState(initial?.timetable?.filler || "testcard");
  const [identShow, setIdentShow] = useState(initial?.identShow || "");
  const [promoShow, setPromoShow] = useState(initial?.promoShow || "");
  const [allDay, setAllDay] = useState(Boolean(initial?.allDay));
  const [locked, setLocked] = useState(Boolean(initial?.locked));
  const [fav, setFav] = useState(Boolean(initial?.fav));
  const [seed, setSeed] = useState(() => initial?.seed ?? newSeed());
  const [reshuffled, setReshuffled] = useState(false);
  const [picking, setPicking] = useState(null); // "shows" | "ads" | null
  const [lineupOpen, setLineupOpen] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [leaveArmed, setLeaveArmed] = useState(false);
  const isBlocks = mode === "blocks";
  const isTimetable = mode === "timetable";
  const isWeather = mode === "weather";
  const canSave = isWeather ? true : isTimetable ? slots.some((sl) => sl.show) : isBlocks ? blocks.length > 0 : chShows.length > 0;

  const showOptions = useMemo(
    () => shows.map((s) => ({ value: s, label: s, hint: `${showEpisodes(media, s).length} episodes` })),
    [shows, media]
  );
  const folderOptions = useMemo(() => [{ value: "", label: "None" }, ...shows.map((s) => ({ value: s, label: s }))], [shows]);

  // Every edit marks the form dirty; changing what the playlist draws from
  // drops the saved lineup so it's rebuilt to include the new picks.
  const edit = (setter, { resetLineup = false } = {}) => (v) => {
    setter(v);
    setDirty(true);
    if (resetLineup) setLineup(null);
  };

  useEffect(() => {
    requestAnimationFrame(() => focusFirst(rootRef.current));
  }, []);

  useEffect(() => {
    if (!leaveArmed) return undefined;
    const t = setTimeout(() => setLeaveArmed(false), 3000);
    return () => clearTimeout(t);
  }, [leaveArmed]);

  // B: leave the editor. With unsaved changes, the first press only warns.
  useBackHandler(() => {
    if (dirty && !leaveArmed) {
      setLeaveArmed(true);
      return true;
    }
    onCancel();
    return true;
  });

  const draft = () => ({ shows: chShows, adShows, adsPerBreak: Number(adsPerBreak), shuffle, seed });
  // A new random mix: playlists get a fresh lineup, blocks and timetables new picks.
  const reshuffle = () => {
    const s2 = newSeed();
    setSeed(s2);
    if (!isBlocks && !isTimetable && !isWeather && chShows.length) setLineup(generateLineup({ ...draft(), seed: s2 }, media));
    setDirty(true);
    setReshuffled(true);
  };
  const openLineup = () => {
    if (!lineup) setLineup(generateLineup(draft(), media));
    setLineupOpen(true);
  };

  const save = () => {
    if (!canSave) return;
    const n = Number(number) || nextNumber;
    onSave({
      ...initial,
      name: name.trim() || `Channel ${n}`,
      logoText: logoText.trim(),
      number: n,
      shows: chShows,
      adShows,
      adsPerBreak: Number(adsPerBreak),
      shuffle,
      // Block channels pick episodes per pass; playlists freeze their lineup on save.
      blocks: isBlocks ? blocks : [],
      lineup: isBlocks || isTimetable || isWeather ? null : lineup || generateLineup(draft(), media),
      weather: isWeather,
      musicShow: isWeather ? musicShow : "",
      epoch: pickEpoch(initial, isBlocks),
      // Timetables count airings from the day the channel started, so "in order"
      // slots carry on through the episodes day by day.
      timetable: isTimetable ? { startDay: initial?.timetable?.startDay ?? dayIndex(Date.now()), filler, slots: slots.filter((sl) => sl.show) } : null,
      identShow,
      promoShow,
      allDay,
      locked,
      fav,
      seed,
    });
  };

  const lineupTotal = useMemo(() => {
    if (!lineup) return 0;
    const byId = new Map(media.map((m) => [m.id, m]));
    return lineup.reduce((t, e) => t + (byId.get(e.mediaId)?.duration || 0), 0);
  }, [lineup, media]);

  return (
    <div ref={rootRef} className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <button onClick={onCancel} className="ps-btn flex min-h-10 items-center gap-1.5 px-3 text-sm" aria-label="Back to channels">
          <ArrowLeft size={15} /> Back
        </button>
        <h3 className="ps-section min-w-0 flex-1 truncate text-center">{initial ? "Edit channel" : "New channel"}</h3>
        <button onClick={save} disabled={!canSave} className="ps-btn-primary flex min-h-10 items-center gap-1.5 px-4 text-xs uppercase disabled:opacity-40">
          <Check size={14} /> Save
        </button>
      </div>
      {leaveArmed && (
        <p role="status" className="ps-inset px-3 py-2 text-xs font-bold text-[#ffe14d]">
          Unsaved changes. Press Back again to discard them, or Save.
        </p>
      )}
      {!canSave && (
        <p className="px-1 text-[11px] text-[#a9c3ee]">{isTimetable ? "Book at least one time slot to save." : isBlocks ? "Add at least one block to save." : "Pick at least one show to save."}</p>
      )}

      <TextRow label="Name" value={name} placeholder={`Channel ${number}`} onChange={edit(setName)} navDefault />
      <TextRow label="Logo" value={logoText} placeholder={(name || `Channel ${number}`).toUpperCase()} onChange={edit(setLogoText)} maxLength={18} />
      <Stepper label="Channel number" value={Number(number) || 1} min={1} max={999} onChange={edit(setNumber)} format={(v) => String(v).padStart(2, "0")} />
      <Cycler
        label="Type"
        hint={MODE_HINT[mode]}
        value={mode}
        options={MODES}
        onChange={edit(setMode)}
      />

      {isWeather ? (
        <>
          <SectionLabel hint="The forecast for the place set in System (Dubbo unless you change it). Downloads when there's internet, then works offline.">Weather</SectionLabel>
          <Cycler label="Music" hint={musicShow ? "Plays the music in this folder" : "Gentle built-in tune"} value={musicShow} options={[{ value: "", label: "Built-in" }, ...shows.map((x) => ({ value: x, label: x }))]} onChange={edit(setMusicShow)} />
        </>
      ) : isTimetable ? (
        <>
          <TimetableEditor slots={slots} shows={shows} media={media} onChange={edit(setSlots)} />
          <Cycler label="Between slots" hint={filler === "ads" ? "Ads and promos fill the gaps" : "The test card until the next slot"} value={filler} options={FILLER} onChange={edit(setFiller)} />
          <NavRow label="Ad folders" hint="For the gaps and the breaks inside episodes" value={listLabel(adShows, "None")} onClick={() => setPicking("ads")} navKey="pick-ads" />
          {adShows.length > 0 && <Stepper label="Ads per break" value={Number(adsPerBreak) || 1} min={1} max={10} onChange={edit(setAdsPerBreak)} />}
        </>
      ) : isBlocks ? (
        <>
          <BlockEditor blocks={blocks} shows={shows} media={media} onChange={edit(setBlocks)} />
          <SectionLabel hint="Played in the breaks you mark inside episodes (Library, open a show, Breaks). Blank uses your ad blocks.">Mid-episode breaks</SectionLabel>
          <NavRow label="Ad folders" value={listLabel(adShows, "Ad blocks")} onClick={() => setPicking("ads")} navKey="pick-ads" />
          <Stepper label="Ads per break" value={Number(adsPerBreak) || 1} min={1} max={10} onChange={edit(setAdsPerBreak)} />
        </>
      ) : (
        <>
          <SectionLabel>What's on</SectionLabel>
          <NavRow label="Shows" hint="Episodes rotate between the shows you pick" value={listLabel(chShows, "None")} onClick={() => setPicking("shows")} navKey="pick-shows" />
          <Cycler label="Episode order" hint={shuffle ? "Random across all seasons" : "Season by season"} value={shuffle} options={ORDERS} onChange={edit(setShuffle, { resetLineup: true })} />
          <NavRow label="Ad breaks" hint="Ads between episodes and in each episode's breaks" value={listLabel(adShows, "Off")} onClick={() => setPicking("ads")} navKey="pick-ads" />
          {adShows.length > 0 && (
            <Stepper label="Ads per break" value={Number(adsPerBreak) || 1} min={1} max={10} onChange={edit(setAdsPerBreak, { resetLineup: true })} />
          )}
          {chShows.length > 0 && (
            <NavRow
              label="Lineup"
              icon={<ListOrdered size={16} className="text-[#a9c3ee]" />}
              hint={lineup ? `Loops every ${formatClock(lineupTotal)}` : "Built from your picks when you save"}
              value={lineup ? `${lineup.length} items` : "Preview"}
              onClick={openLineup}
              navKey="lineup"
            />
          )}
        </>
      )}

      <SectionLabel hint="Your own clips, picked at random: an idents folder plays before each show, a promos folder in the breaks (needs Promos on in Broadcast).">Station extras</SectionLabel>
      <Cycler label="Idents folder" hint={identShow ? undefined : "None: the built-in animated ident (if on)"} value={identShow} options={folderOptions} onChange={edit(setIdentShow)} />
      <Cycler label="Promos folder" hint={promoShow ? undefined : "None: built-in 'Tonight at' cards"} value={promoShow} options={folderOptions} onChange={edit(setPromoShow)} />
      <Toggle label="24-hour channel" hint="Stays on air during the night closedown" checked={allDay} onChange={edit(setAllDay)} />
      <Toggle label="Lock channel" hint={hasPin ? "Needs the parental PIN to watch" : "Set a PIN in System to make this work"} checked={locked} onChange={edit(setLocked)} />
      <Toggle label="Favourite" hint="Star it: channel up / down can skip to favourites only (System)" checked={fav} onChange={edit(setFav)} />

      <SectionLabel hint="Mixes the episodes again. Every show is spread evenly through the loop, so shows with only a few episodes don't come round too often.">Mix</SectionLabel>
      <button data-nav-key="reshuffle" onClick={reshuffle} disabled={!canSave} className="ps-btn flex min-h-11 items-center justify-center gap-2 text-sm disabled:opacity-40">
        <Shuffle size={15} /> {reshuffled ? "Reshuffled. Save to keep it" : "Reshuffle this channel"}
      </button>

      {initial && onDelete && (
        <ConfirmButton
          label="Delete channel"
          confirmLabel="Press again to delete"
          onConfirm={() => onDelete(initial)}
          className="ps-btn mt-3 flex min-h-11 items-center justify-center gap-2 text-sm"
        >
          {(armed) => (
            <>
              <Trash2 size={14} /> {armed ? "Press again to delete" : "Delete channel"}
            </>
          )}
        </ConfirmButton>
      )}

      {picking && (
        <MultiPicker
          title={picking === "shows" ? "Shows" : "Ad folders"}
          hint={picking === "shows" ? "Episodes play in order, rotating between these." : "Played between episodes and in mid-episode breaks."}
          options={showOptions}
          values={picking === "shows" ? chShows : adShows}
          onChange={edit(picking === "shows" ? setChShows : setAdShows, { resetLineup: !isBlocks })}
          onClose={() => {
            const key = picking === "shows" ? "pick-shows" : "pick-ads";
            setPicking(null);
            requestAnimationFrame(() => rootRef.current?.querySelector(`[data-nav-key="${key}"]`)?.focus());
          }}
        />
      )}
      {lineupOpen && lineup && (
        <LineupEditor
          lineup={lineup}
          media={media}
          onChange={edit(setLineup)}
          onRebuild={() => {
            setLineup(generateLineup(draft(), media));
            setDirty(true);
          }}
          onClose={() => {
            setLineupOpen(false);
            requestAnimationFrame(() => rootRef.current?.querySelector('[data-nav-key="lineup"]')?.focus());
          }}
        />
      )}
    </div>
  );
}
