import React, { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { Bell, Tv, X } from "lucide-react";
import { useBackHandler } from "@/components/tv/backStack";
import { focusEl } from "@/lib/spatialNav";
import { formatTimeOfDay } from "@/lib/schedule";

const pad2 = (n) => String(n ?? "").padStart(2, "0");

// "Starting now" pop-up for a reminder set from the guide.
export default function ReminderPopup({ reminder, onWatch, onDismiss }) {
  const ref = useRef(null);
  useBackHandler(() => {
    onDismiss();
    return true;
  });
  useEffect(() => {
    requestAnimationFrame(() => focusEl(ref.current?.querySelector("[data-watch]")));
    const t = setTimeout(onDismiss, 45000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reminder.id]);
  const soon = reminder.startMs > Date.now() + 5000;
  return createPortal(
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[85] flex justify-center px-3">
      <div ref={ref} data-nav-modal role="alertdialog" aria-label="Reminder" data-testid="reminder" className="ps-panel pointer-events-auto w-full max-w-lg overflow-hidden">
        <div className="ps-titlebar flex items-center gap-2 px-3 py-1.5">
          <Bell size={14} className="text-[#ffd21f]" />
          <span className="text-xs font-bold uppercase tracking-wider text-white">{soon ? `Starts at ${formatTimeOfDay(reminder.startMs)}` : "Starting now"}</span>
        </div>
        <div className="flex items-center gap-3 px-3 py-2.5">
          <span className="ps-btn-primary shrink-0 px-2 text-lg tabular-nums">{pad2(reminder.number)}</span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-base font-bold text-white">{reminder.title}</span>
            <span className="block truncate text-xs text-[#a9c3ee]">{reminder.channelName}</span>
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2 px-3 pb-3" data-nav-row>
          <button data-watch onClick={onWatch} className="ps-btn-primary flex min-h-11 items-center justify-center gap-2 text-sm">
            <Tv size={15} /> Watch
          </button>
          <button onClick={onDismiss} className="ps-btn flex min-h-11 items-center justify-center gap-2 text-sm">
            <X size={15} /> Not now
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
}
