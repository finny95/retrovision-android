import React, { useEffect, useRef } from "react";
import * as THREE from "three";

const vertexShader = `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const fragmentShader = `
precision highp float;
uniform sampler2D uTexture;
uniform float uTime;
uniform vec2 uResolution;
uniform float uCurvature;
uniform float uScanlineIntensity;
uniform float uScanlineDensity;
uniform float uVignette;
uniform float uAberration;
uniform float uBrightness;
uniform float uContrast;
uniform float uSaturation;
uniform float uGlow;
uniform float uNoise;
uniform float uMaskIntensity;
uniform float uHasFrame;
uniform float uPixelRatio;
uniform float uVideoAspect;
uniform float uStatic;
uniform float uVhs;
uniform sampler2D uGfx;
uniform float uGfxOn;
// Power on/off: x = picture height, y = width (1 = full), z = extra brightness, w = centre dot glow.
uniform vec4 uPower;
// Reception fault: x = strength (0 = clean), y = random seed.
uniform vec2 uGlitch;
varying vec2 vUv;

vec2 curveScreen(vec2 uv) {
  uv = uv * 2.0 - 1.0;
  // 0.3 keeps the default "Retro" bulge to about a tenth at the corners;
  // the slider goes up to 3 for a strong fishbowl.
  vec2 off = uv.yx * uCurvature * 0.3;
  uv += uv * off * off;
  uv = uv * 0.5 + 0.5;
  return uv;
}

float rand(vec2 st) {
  return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
}

void main() {
  // Switching on or off squeezes the whole picture towards the centre.
  vec2 base = 0.5 + (vUv - 0.5) / max(uPower.xy, vec2(0.002));
  float outside = step(1.0, max(abs(base.x - 0.5), abs(base.y - 0.5)) * 2.0);
  vec2 uv = curveScreen(base);

  // letterbox the video inside the screen, keeping its aspect ratio
  float screenAspect = uResolution.x / uResolution.y;
  vec2 vuv = uv - 0.5;
  if (screenAspect > uVideoAspect) vuv.x *= screenAspect / uVideoAspect;
  else vuv.y *= uVideoAspect / screenAspect;
  vuv += 0.5;

  // VHS wear: wobbly lines, a tracking band near the bottom, colour bleed.
  float vt = mod(floor(uTime * 30.0), 997.0);
  float bandPos = 0.05 + 0.02 * sin(uTime * 0.6);
  float inBand = uVhs * (1.0 - smoothstep(0.0, 0.03, abs(vuv.y - bandPos)));
  if (uVhs > 0.001) {
    float ln = floor(vuv.y * 240.0);
    vuv.x += (rand(vec2(ln * 0.13, vt * 0.07)) - 0.5) * 0.004 * uVhs;
    vuv.x += sin(vuv.y * 28.0 + uTime * 1.7) * 0.0012 * uVhs;
    vuv.x += inBand * (rand(vec2(ln * 0.31, vt)) - 0.5) * 0.05;
  }

  // Weak signal: blocks of the picture smear and pixelate, some lines tear.
  if (uGlitch.x > 0.001) {
    vec2 blk = floor(vuv * vec2(24.0, 14.0));
    float pick = rand(blk + uGlitch.y);
    if (pick < uGlitch.x * 0.55) {
      vec2 cellUv = (blk + floor(fract(vuv * vec2(24.0, 14.0)) * 4.0) / 4.0) / vec2(24.0, 14.0);
      vuv = cellUv + (vec2(rand(blk * 1.7 + uGlitch.y), rand(blk * 2.3 + uGlitch.y)) - 0.5) * 0.06 * uGlitch.x;
    }
    float row = floor(vuv.y * 90.0);
    if (rand(vec2(row, uGlitch.y)) < uGlitch.x * 0.15) vuv.x += (rand(vec2(row * 0.7, uGlitch.y)) - 0.5) * 0.08;
  }

  vec3 col = vec3(0.0);
  if (uHasFrame > 0.5 && vuv.x >= 0.0 && vuv.x <= 1.0 && vuv.y >= 0.0 && vuv.y <= 1.0
      && uv.x >= 0.0 && uv.x <= 1.0 && uv.y >= 0.0 && uv.y <= 1.0) {
    float aberr = uAberration * 0.008;
    float r = texture2D(uTexture, vec2(vuv.x + aberr, vuv.y)).r;
    float g = texture2D(uTexture, vec2(vuv.x, vuv.y)).g;
    float b = texture2D(uTexture, vec2(vuv.x - aberr, vuv.y)).b;
    col = vec3(r, g, b);
    if (uVhs > 0.001) {
      float sp = 0.006 * uVhs;
      vec3 bl = (texture2D(uTexture, vuv - vec2(sp, 0.0)).rgb + col + texture2D(uTexture, vuv + vec2(sp, 0.0)).rgb + texture2D(uTexture, vuv + vec2(sp * 2.0, 0.0)).rgb) / 4.0;
      float y = dot(col, vec3(0.299, 0.587, 0.114));
      float yb = dot(bl, vec3(0.299, 0.587, 0.114));
      col = mix(col, vec3(mix(y, yb, 0.5)) + (bl - vec3(yb)), uVhs);
      col += inBand * (rand(vec2(vuv.x * 80.0, vt)) - 0.3) * 0.35;
    }

    col = (col - 0.5) * uContrast + 0.5;
    col *= uBrightness;

    float gray = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(gray), col, uSaturation);
  }

  // Channel graphics (bumpers, logo, "Next" strip) sit on the picture, under
  // the tube effects below, like anything else the channel sends.
  if (uGfxOn > 0.5 && uv.x >= 0.0 && uv.x <= 1.0 && uv.y >= 0.0 && uv.y <= 1.0) {
    vec4 gx = texture2D(uGfx, uv);
    col = mix(col, gx.rgb, gx.a);
  }

  // Between channels: snow, tearing lines and a slow rolling band, like an
  // old set that has lost its signal. Frame counter is wrapped to keep the
  // hash precise on phone GPUs.
  if (uStatic > 0.001 && uv.x >= 0.0 && uv.x <= 1.0 && uv.y >= 0.0 && uv.y <= 1.0) {
    float t = mod(floor(uTime * 30.0), 997.0);
    vec2 cell = floor(uv * vec2(320.0, 240.0));
    float n = rand(cell * 0.731 + vec2(t * 1.37, t * 0.91));
    float tear = rand(vec2(floor(uv.y * 240.0) * 0.37, t * 0.53));
    n = mix(n, tear, 0.22);
    float band = abs(fract(uv.y * 0.85 - uTime * 0.35) - 0.5);
    float roll = 0.72 + 0.28 * smoothstep(0.02, 0.12, band);
    vec3 snow = vec3(n * n * 1.1 + 0.04) * roll;
    col = mix(col, snow, uStatic);
  }

  // scanlines: uScanlineDensity = number of lines across the screen height.
  // Clamp so lines are never thinner than ~3 device pixels (avoids moire).
  float lines = min(uScanlineDensity, uResolution.y / 3.0);
  float phase = fract(uv.y * lines);
  float scanline = smoothstep(0.0, 0.5, phase) * (1.0 - smoothstep(0.5, 1.0, phase));
  scanline = pow(clamp(scanline * 2.0, 0.0, 1.0), 0.8);
  col *= 1.0 - uScanlineIntensity * (1.0 - scanline);

  // RGB phosphor mask: triads sized to ~3 CSS pixels regardless of DPI
  float px = floor(vUv.x * uResolution.x / 3.0 * 3.0 / max(uPixelRatio, 1.0));
  float triad = mod(px, 3.0);
  vec3 mask;
  if (triad < 1.0) mask = vec3(1.0, 0.82, 0.82);
  else if (triad < 2.0) mask = vec3(0.82, 1.0, 0.82);
  else mask = vec3(0.82, 0.82, 1.0);
  col *= mix(vec3(1.0), mask, uMaskIntensity);

  // vignette
  vec2 vc = vUv - 0.5;
  float vig = 1.0 - dot(vc, vc) * uVignette * 2.6;
  vig = clamp(vig, 0.0, 1.0);
  col *= vig;

  // bloom-ish glow
  col += col * uGlow * 0.18;

  // animated noise / static
  col += (rand(vUv + uTime * 0.01) - 0.5) * uNoise;

  // faint CRT tint
  col *= vec3(0.97, 1.0, 1.03);

  // Power on/off: black outside the squeezed picture, a bright flash as it
  // opens or closes, and the glowing dot left in the middle at the end.
  col = mix(col, vec3(0.0), outside);
  col = col * (1.0 + uPower.z) + vec3(0.85, 0.9, 1.0) * uPower.z * 0.35 * (1.0 - outside);
  float aspect = uResolution.x / max(uResolution.y, 1.0);
  vec2 dc = (vUv - 0.5) * vec2(aspect, 1.0);
  col += vec3(0.9, 0.95, 1.0) * uPower.w * exp(-dot(dc, dc) * 900.0);

  gl_FragColor = vec4(col, 1.0);
}
`;

// staticLevel: 0 = picture, 1 = full static (channel change), in between = faint snow.
// Power animation: picture height / width / flash / dot over time (seconds).
function powerFrame(mode, t) {
  const clamp = (v) => Math.max(0, Math.min(1, v));
  const ease = (v) => 1 - Math.pow(1 - clamp(v), 3);
  if (mode === "on") {
    // A bright line grows across, opens out to the full picture, then settles.
    const sx = ease(t / 0.18);
    const sy = t < 0.18 ? 0.004 : 0.004 + ease((t - 0.18) / 0.35) * 0.996;
    const flash = t < 0.18 ? 2.5 : Math.max(0, 1.4 * (1 - (t - 0.18) / 0.6));
    return { v: [sy, Math.max(0.01, sx), flash, 0], done: t > 0.8 };
  }
  if (mode === "off") {
    // Collapses to a line, the line shrinks to a dot, the dot fades.
    if (t < 0.2) return { v: [Math.max(0.004, 1 - ease(t / 0.2)), 1, 1.5 * (t / 0.2), 0], done: false };
    if (t < 0.38) return { v: [0.004, Math.max(0.004, 1 - ease((t - 0.2) / 0.18)), 2.5, 0.6], done: false };
    return { v: [0.002, 0.002, 0, Math.max(0, 1 - (t - 0.38) / 0.6)], done: t > 1 };
  }
  return { v: [1, 1, 0, 0], done: true };
}

// Random reception faults. Odds of a fault starting, per second, by setting.
const FAULT_ODDS = { perfect: 0, good: 1 / 600, fair: 1 / 150, poor: 1 / 40 };

// power: "on" | "off". Changing it plays the switch-on / switch-off animation;
// warmUp plays the switch-on as the player first appears.
export default function CRTPlayer({ videoRef, settings, hasFrame, staticLevel = 0, gfxRef = null, power = "on", warmUp = false }) {
  // since: null = start timing at the first frame actually drawn.
  const powerRef = useRef({ mode: warmUp ? "on" : null, since: null, state: power });
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const containerRef = useRef(null);
  const materialRef = useRef(null);
  const rendererRef = useRef(null);
  const textureRef = useRef(null);
  const staticTargetRef = useRef(staticLevel);
  staticTargetRef.current = staticLevel;

  useEffect(() => {
    const container = containerRef.current;
    const video = videoRef.current;
    if (!container || !video) return;

    const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.style.display = "block";
    rendererRef.current = renderer;

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 10);
    camera.position.z = 1;

    const texture = new THREE.VideoTexture(video);
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.colorSpace = THREE.SRGBColorSpace;
    textureRef.current = texture;

    // Channel graphics canvas (see useBroadcastGfx).
    const gfx = gfxRef?.current;
    const gfxTexture = gfx ? new THREE.CanvasTexture(gfx.canvas) : null;
    if (gfxTexture) {
      gfxTexture.minFilter = THREE.LinearFilter;
      gfxTexture.magFilter = THREE.LinearFilter;
      gfxTexture.generateMipmaps = false;
      // Plain RGBA texture: canvas colours go straight through (and it avoids the
      // sRGB upload path some Android emulators' GL can't handle).
      gfxTexture.colorSpace = THREE.NoColorSpace;
    }

    const material = new THREE.ShaderMaterial({
      uniforms: {
        uTexture: { value: texture },
        uTime: { value: 0 },
        uResolution: { value: new THREE.Vector2(1, 1) },
        uCurvature: { value: settings.curvature },
        uScanlineIntensity: { value: settings.scanlineIntensity },
        uScanlineDensity: { value: settings.scanlineDensity },
        uVignette: { value: settings.vignette },
        uAberration: { value: settings.aberration },
        uBrightness: { value: settings.brightness },
        uContrast: { value: settings.contrast },
        uSaturation: { value: settings.saturation },
        uGlow: { value: settings.glow },
        uNoise: { value: settings.noise },
        uMaskIntensity: { value: settings.maskIntensity },
        uHasFrame: { value: hasFrame ? 1 : 0 },
        uPixelRatio: { value: renderer.getPixelRatio() },
        uVideoAspect: { value: 16 / 9 },
        uStatic: { value: staticLevel },
        uVhs: { value: settings.vhs || 0 },
        uGfx: { value: gfxTexture || texture },
        uGfxOn: { value: 0 },
        uPower: { value: new THREE.Vector4(1, 1, 0, 0) },
        uGlitch: { value: new THREE.Vector2(0, 0) },
      },
      vertexShader,
      fragmentShader,
    });
    materialRef.current = material;

    const geometry = new THREE.PlaneGeometry(2, 2);
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    const resize = () => {
      const w = container.clientWidth || 1;
      const h = container.clientHeight || 1;
      renderer.setSize(w, h, false);
      material.uniforms.uResolution.value.set(w, h);
      gfx?.resize?.(w, h);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(container);

    const clock = new THREE.Clock();
    let raf;
    let lastDraw = 0;
    let lastTick = 0;
    let level = staticLevel;
    let fault = null; // { start, dur, seed }
    let lastFaultCheck = 0;
    const animate = (now = 0) => {
      raf = requestAnimationFrame(animate);
      // Power animation (and the dark screen after switching off).
      const pw = powerRef.current;
      let powerBusy = false;
      if (pw.mode) {
        if (pw.since == null) pw.since = performance.now();
        const f = powerFrame(pw.mode, (performance.now() - pw.since) / 1000);
        material.uniforms.uPower.value.set(...f.v);
        if (f.done && pw.mode === "on") pw.mode = null;
        powerBusy = !f.done;
      } else material.uniforms.uPower.value.set(1, 1, 0, 0);
      // Reception faults, only over a moving picture.
      const odds = FAULT_ODDS[settingsRef.current.reception] || 0;
      const playing = !video.paused && !video.ended && video.readyState >= 2;
      if (odds && playing && !fault && now - lastFaultCheck > 1000) {
        lastFaultCheck = now;
        if (Math.random() < odds) fault = { start: now, dur: 250 + Math.random() * 1100, seed: Math.random() * 100 };
      }
      if (fault) {
        const k = (now - fault.start) / fault.dur;
        if (k >= 1 || !odds) {
          fault = null;
          material.uniforms.uGlitch.value.set(0, 0);
        } else {
          if (Math.random() < 0.3) fault.seed = Math.random() * 100;
          material.uniforms.uGlitch.value.set(Math.sin(Math.PI * k) * (0.6 + 0.4 * Math.random()), fault.seed);
        }
      }
      // Static snaps on at once and fades out over a quarter second.
      const dt = lastTick ? Math.min(0.1, (now - lastTick) / 1000) : 0;
      lastTick = now;
      const target = staticTargetRef.current;
      level = target >= level ? target : Math.max(target, level - dt / 0.25);
      // Moving picture or full static: draw every frame. Paused or nothing loaded:
      // ~15 fps is plenty, and frees the GPU so menus stay smooth on phones.
      const g = gfxRef?.current;
      const gfxChanged = Boolean(g?.dirty);
      const moving =
        (!video.paused && !video.ended && video.readyState >= 2) || level > 0.5 || level !== target || Boolean(g?.animating) || powerBusy || Boolean(fault);
      if (!moving && !gfxChanged && now - lastDraw < 66) return;
      lastDraw = now;
      if (g && gfxTexture && g.dirty) {
        g.dirty = false;
        gfxTexture.needsUpdate = true;
        material.uniforms.uGfxOn.value = g.visible ? 1 : 0;
      }
      material.uniforms.uStatic.value = level;
      material.uniforms.uTime.value = clock.getElapsedTime();
      if (video.videoWidth && video.videoHeight) {
        material.uniforms.uVideoAspect.value = video.videoWidth / video.videoHeight;
      }
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      geometry.dispose();
      material.dispose();
      texture.dispose();
      gfxTexture?.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Switch on / off when the power prop changes.
  useEffect(() => {
    const pw = powerRef.current;
    if (pw.state === power) return;
    pw.state = power;
    pw.mode = power === "off" ? "off" : "on";
    pw.since = performance.now();
  }, [power]);

  useEffect(() => {
    const m = materialRef.current;
    if (!m) return;
    const u = m.uniforms;
    u.uCurvature.value = settings.curvature;
    u.uScanlineIntensity.value = settings.scanlineIntensity;
    u.uScanlineDensity.value = settings.scanlineDensity;
    u.uVignette.value = settings.vignette;
    u.uAberration.value = settings.aberration;
    u.uBrightness.value = settings.brightness;
    u.uContrast.value = settings.contrast;
    u.uSaturation.value = settings.saturation;
    u.uGlow.value = settings.glow;
    u.uNoise.value = settings.noise;
    u.uMaskIntensity.value = settings.maskIntensity;
    u.uVhs.value = settings.vhs || 0;
  }, [settings]);

  useEffect(() => {
    const m = materialRef.current;
    if (m) m.uniforms.uHasFrame.value = hasFrame ? 1 : 0;
  }, [hasFrame]);

  return <div ref={containerRef} className="absolute inset-0 h-full w-full" />;
}