import React, { memo, useMemo } from "react";
import { RotateCcw } from "lucide-react";
import { FIELDS, PRESETS, RETRO, formatSetting } from "@/lib/crtSettings";
import { Cycler, SliderRow, SectionLabel, Toggle } from "@/components/tv/controls";

const RECEPTION = [
  { value: "perfect", label: "Perfect" },
  { value: "good", label: "Good (rare blips)" },
  { value: "fair", label: "Fair" },
  { value: "poor", label: "Poor (stormy night)" },
];

const same = (a, b) => FIELDS.every((f) => Math.abs((a[f.key] ?? 0) - (b[f.key] ?? 0)) < 1e-6);

// One setting per row: Up/Down picks the setting, Left/Right changes it.
function PictureTab({ settings, onChange }) {
  const look = useMemo(() => Object.keys(PRESETS).find((k) => same(settings, PRESETS[k])) || "Custom", [settings]);
  const options = useMemo(() => {
    const list = Object.keys(PRESETS).map((k) => ({ value: k, label: k }));
    return look === "Custom" ? [...list, { value: "Custom", label: "Custom" }] : list;
  }, [look]);

  return (
    <div className="flex flex-col gap-2">
      <Cycler
        label="Look"
        hint="Pick a style, then fine-tune below"
        value={look}
        options={options}
        onChange={(v) => PRESETS[v] && onChange({ ...settings, ...PRESETS[v] })}
      />
      <SectionLabel hint="Up / Down picks a setting · Left / Right changes it">Fine-tune</SectionLabel>
      {FIELDS.map((f) => (
        <SliderRow
          key={f.key}
          label={f.label}
          value={settings[f.key]}
          min={f.min}
          max={f.max}
          step={f.step}
          display={formatSetting(f, settings[f.key])}
          onChange={(v) => onChange({ ...settings, [f.key]: v })}
        />
      ))}
      <SectionLabel hint="Now and then the picture breaks up into blocks for a moment, like a weak signal on a stormy night.">Reception</SectionLabel>
      <Cycler label="Signal" value={settings.reception || "perfect"} options={RECEPTION} onChange={(v) => onChange({ ...settings, reception: v })} />
      <Toggle label="Switch on / off effect" hint="The picture opens from a line when it starts, and shrinks to a dot when it turns off" checked={settings.powerFx !== false} onChange={(v) => onChange({ ...settings, powerFx: v })} />
      <button
        onClick={() => onChange({ ...RETRO, reception: settings.reception, powerFx: settings.powerFx })}
        className="ps-btn mt-1 flex min-h-11 items-center justify-center gap-2 text-sm"
      >
        <RotateCcw size={14} /> Reset picture
      </button>
    </div>
  );
}

export default memo(PictureTab);
