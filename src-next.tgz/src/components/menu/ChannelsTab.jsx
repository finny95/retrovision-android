import React, { useEffect, useState } from "react";
import { Plus, Pencil, HardDrive, Lock, CalendarClock, Star, Shuffle, CloudSun } from "lucide-react";
import { ConfirmButton } from "@/components/tv/controls";
import ChannelEditor from "@/components/ChannelEditor";
import { nowNext, programmeTitle, formatTimeOfDay } from "@/lib/schedule";

export function useNow(ms) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return now;
}

const pad2 = (n) => String(n).padStart(2, "0");

function ChannelList({ channels, media, activeId, onTune, onNew, onEdit, onGoLibrary, isLocked, onToggleFav, onReshuffleAll }) {
  const now = useNow(10000);
  return (
    <div className="flex flex-col gap-2">
      <button
        onClick={onNew}
        data-nav-key="new-channel"
        data-nav-default={channels.length === 0 || undefined}
        className="ps-btn flex min-h-11 items-center justify-center gap-2 text-sm"
      >
        <Plus size={15} /> New channel
      </button>

      {channels.length === 0 && (
        <div className="ps-inset p-4 text-center text-sm text-white">
          <p className="font-bold">No channels yet.</p>
          <p className="mt-1 text-xs text-[#a9c3ee]">Add your show folders in Library, then build a channel from them.</p>
          {media.length === 0 && (
            <button onClick={onGoLibrary} className="ps-btn mx-auto mt-3 flex min-h-10 items-center gap-2 px-4 text-xs">
              <HardDrive size={14} /> Go to Library
            </button>
          )}
        </div>
      )}

      {channels.map((c) => {
        const nn = nowNext(c, media, now);
        const active = activeId === c.id;
        return (
          <div key={c.id} className="flex items-stretch gap-2">
            <button
              onClick={() => onTune(c)}
              data-nav-key={`ch:${c.id}`}
              data-nav-default={active || undefined}
              data-on={active || undefined}
              className="ps-row flex min-w-0 flex-1 items-center gap-3 px-3 py-2 text-left"
            >
              <span className="ps-inset flex h-10 w-12 shrink-0 items-center justify-center text-lg font-bold tabular-nums text-[#ffe14d]">{pad2(c.number)}</span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="ps-label truncate text-sm">{c.name}</span>
                  {active && <span className="shrink-0 rounded bg-[#e2231a] px-1.5 py-px text-[9px] font-bold uppercase tracking-wider text-white">On now</span>}
                  {c.timetable && <CalendarClock size={12} className="shrink-0 text-[#a9c3ee]" aria-label="Timetable" />}
                  {c.weather && <CloudSun size={12} className="shrink-0 text-[#a9c3ee]" aria-label="Weather" />}
                  {isLocked?.(c) && <Lock size={12} className="shrink-0 text-[#ffd21f]" aria-label="Locked" />}
                </span>
                {nn ? (
                  <>
                    <span className="ps-hint block truncate text-xs">
                      <span className="ps-value">{formatTimeOfDay(nn.now.startMs)}</span> {programmeTitle(nn.now)}
                    </span>
                    {nn.next && (
                      <span className="ps-hint block truncate text-[11px]">
                        {formatTimeOfDay(nn.next.startMs)} {programmeTitle(nn.next)}
                      </span>
                    )}
                  </>
                ) : (
                  <span className="ps-hint block text-[11px]">No episodes found</span>
                )}
              </span>
            </button>
            <button
              onClick={() => onToggleFav?.(c)}
              data-fav={c.fav || undefined}
              className="ps-btn flex w-11 shrink-0 items-center justify-center !rounded-[10px]"
              aria-label={c.fav ? `Unstar ${c.name}` : `Star ${c.name}`}
              aria-pressed={Boolean(c.fav)}
            >
              <Star size={16} className={c.fav ? "fill-[#ffd21f] text-[#ffd21f]" : ""} />
            </button>
            <button onClick={() => onEdit(c)} className="ps-btn flex w-12 shrink-0 items-center justify-center !rounded-[10px]" aria-label={`Edit ${c.name}`}>
              <Pencil size={16} />
            </button>
          </div>
        );
      })}
      {channels.length > 1 && (
        <ConfirmButton
          label="Reshuffle all channels"
          confirmLabel="Press again: new mix on every channel"
          onConfirm={onReshuffleAll}
          className="ps-btn mt-2 flex min-h-11 items-center justify-center gap-2 text-sm"
        >
          {(armed) => (
            <>
              <Shuffle size={14} /> {armed ? "Press again: new mix on every channel" : "Reshuffle all channels"}
            </>
          )}
        </ConfirmButton>
      )}
    </div>
  );
}

export default function ChannelsTab({ channels, media, shows, activeId, editing, onEdit, onTune, onSave, onDelete, onGoLibrary, isLocked, hasPin, onToggleFav, onReshuffleAll }) {
  if (editing) {
    return (
      <ChannelEditor
        key={editing === "new" ? "new" : editing.id}
        initial={editing === "new" ? null : editing}
        shows={shows}
        media={media}
        nextNumber={Math.max(0, ...channels.map((c) => c.number)) + 1}
        hasPin={hasPin}
        onSave={onSave}
        onCancel={() => onEdit(null)}
        onDelete={onDelete}
      />
    );
  }
  return (
    <ChannelList
      channels={channels}
      media={media}
      activeId={activeId}
      onTune={onTune}
      onNew={() => onEdit("new")}
      onEdit={onEdit}
      onGoLibrary={onGoLibrary}
      isLocked={isLocked}
      onToggleFav={onToggleFav}
      onReshuffleAll={onReshuffleAll}
    />
  );
}
