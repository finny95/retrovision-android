import React, { memo, useEffect, useRef, useState } from "react";
import { Download, Upload, Lock, KeyRound, Moon, RefreshCw, MapPin, FolderSync, RotateCcw, Trash2, Smartphone, AlarmClock } from "lucide-react";
import { Cycler, Toggle, SectionLabel, ConfirmButton, NavRow, TextRow, Stepper } from "@/components/tv/controls";
import qrcode from "qrcode-generator";
import { Modal } from "@/components/tv/Picker";
import { useBackHandler } from "@/components/tv/backStack";
import { DEFAULT_PLACE, searchPlaces } from "@/lib/weather";
import PinPad from "@/components/PinPad";
import { saveBackup, parseBackup, restoreBackup } from "@/lib/backup";
import { nativeCaps, setPipEnabled } from "@/native/capabilities";
import { isNative } from "@/native/platform";
import { formatClock } from "@/lib/schedule";
import { SLEEP_STEPS } from "@/hooks/useSleepTimer";
import { focusFirst } from "@/lib/spatialNav";

const SLEEP = SLEEP_STEPS.map((m) => ({ value: m, label: m ? `${m} min` : "Off" }));
const LOCKS = [
  { value: "off", label: "Off" },
  { value: "MA15+", label: "MA15+" },
  { value: "M", label: "M and above" },
];
const btn = "ps-btn flex min-h-11 items-center justify-center gap-2 px-3 text-sm";
const WAKE_DAYS = [
  { value: "all", label: "Every day" },
  { value: "weekdays", label: "Weekdays" },
  { value: "weekends", label: "Weekends" },
];
const clockLabel = (min) => {
  const h = Math.floor(min / 60);
  return `${h % 12 || 12}:${String(min % 60).padStart(2, "0")}${h >= 12 ? "pm" : "am"}`;
};
const qrDataUrl = (text) => {
  const qr = qrcode(0, "M");
  qr.addData(text);
  qr.make();
  return qr.createDataURL(5, 2);
};

// Wake timer (Android app): the box switches on at a set time on a chosen channel.
function WakeTimer({ channels }) {
  const [w, setW] = useState(null);
  const [note, setNote] = useState("");
  useEffect(() => {
    import("@/native/mediaFolder").then(({ MediaFolder }) => MediaFolder.getWake().then(setW)).catch(() => setW(null));
  }, []);
  if (!w) return null;
  const save = async (patch) => {
    const next = { ...w, ...patch };
    setW(next);
    try {
      const { MediaFolder } = await import("@/native/mediaFolder");
      setW(await MediaFolder.setWake(next));
    } catch (e) {
      setNote(`Couldn't set it: ${e?.message || e}`);
    }
  };
  const opts = channels.length ? channels.map((c) => ({ value: c.number, label: `${String(c.number).padStart(2, "0")} ${c.name}` })) : [{ value: 0, label: "No channels yet" }];
  const nextAt = w.next > 0 ? new Date(w.next) : null;
  return (
    <>
      <SectionLabel hint="Switches the screen on and opens on a channel, like a morning cartoons wake-up. Leave the app open or in the background.">Wake timer</SectionLabel>
      <Toggle
        label="Wake up the TV"
        hint={w.enabled && nextAt ? `Next: ${nextAt.toLocaleDateString(undefined, { weekday: "long" })} ${clockLabel(nextAt.getHours() * 60 + nextAt.getMinutes())}` : "Off"}
        checked={w.enabled}
        onChange={(v) => save({ enabled: v, channel: w.channel || channels[0]?.number || 0 })}
      />
      {w.enabled && (
        <>
          <Stepper label="Time" value={w.hour * 60 + w.minute} min={0} max={1435} step={5} format={clockLabel} onChange={(v) => save({ hour: Math.floor(v / 60), minute: v % 60 })} />
          <Cycler label="Days" value={w.days} options={WAKE_DAYS} onChange={(v) => save({ days: v })} />
          <Cycler label="Channel" value={w.channel || opts[0].value} options={opts} onChange={(v) => save({ channel: v })} />
          {(!w.overlay || !w.notifications || !w.fullScreen) && (
            <>
              <p className="ps-inset px-3 py-2 text-[11px] leading-snug text-[#ffe14d]">
                {!w.overlay
                  ? "For the surest start, allow RetroVision to \"display over other apps\". Otherwise it uses an alarm-style notification, which some TV boxes don't show."
                  : "Notifications are off for RetroVision, so the wake-up may not show."}
              </p>
              {!w.overlay && (
                <button
                  onClick={() =>
                    import("@/native/mediaFolder")
                      .then(({ MediaFolder }) => MediaFolder.openOverlaySettings())
                      .catch(() => setNote("This device has no setting for that. The notification way is used instead."))
                  }
                  className={btn}
                >
                  <AlarmClock size={14} /> Open the setting
                </button>
              )}
            </>
          )}
          {note && <p className="px-1 text-[11px] text-[#ffe14d]">{note}</p>}
        </>
      )}
    </>
  );
}

// Phone remote (Android app): a phone on the same Wi-Fi becomes the remote.
function PhoneRemote({ enabled, info, onToggle, onNewCode }) {
  const link = info?.url ? `${info.url}/?code=${info.code}` : "";
  return (
    <>
      <SectionLabel hint="Use your phone as the remote: same Wi-Fi as this box, open the address in the phone's browser (or scan the code) and type the 4 digits. Nothing goes over the internet.">
        Phone remote
      </SectionLabel>
      <Toggle label="Phone remote" hint={enabled ? (info?.running ? "On" : info?.error || "Starting…") : "Off"} checked={enabled} onChange={onToggle} />
      {enabled && info?.running && (
        <div className="ps-inset flex items-center gap-3 p-3" data-testid="remote-info">
          {link && <img src={qrDataUrl(link)} alt="Scan with your phone" className="h-28 w-28 shrink-0 rounded bg-white p-1" />}
          <div className="min-w-0 text-xs text-[#cfe0ff]">
            <p className="flex items-center gap-1.5 font-bold text-white">
              <Smartphone size={14} /> On your phone, open
            </p>
            <p className="mt-1 break-all text-sm font-bold text-[#ffe14d]">{info.url || "No Wi-Fi address"}</p>
            <p className="mt-2">Code</p>
            <p className="text-2xl font-bold tracking-[0.3em] text-white" data-testid="remote-code">{info.code}</p>
          </div>
        </div>
      )}
      {enabled && info?.running && (
        <ConfirmButton label="New code" confirmLabel="Press again: phones need the new code" onConfirm={onNewCode} className={btn} />
      )}
    </>
  );
}

const SURF = [
  { value: false, label: "All channels" },
  { value: true, label: "Favourites only" },
];

// Search for a town for the weather.
function PlacePicker({ current, onPick, onClose }) {
  const bodyRef = useRef(null);
  const [q, setQ] = useState("");
  const [results, setResults] = useState(null);
  const [error, setError] = useState("");
  useBackHandler(() => {
    onClose();
    return true;
  });
  useEffect(() => {
    requestAnimationFrame(() => bodyRef.current?.querySelector("button")?.focus());
  }, []);
  useEffect(() => {
    if (q.trim().length < 2) {
      setResults(null);
      return undefined;
    }
    let alive = true;
    const t = setTimeout(() => {
      setError("");
      searchPlaces(q.trim())
        .then((r) => alive && setResults(r))
        .catch(() => alive && setError("Couldn't search. Check the internet connection."));
    }, 400);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [q]);
  return (
    <Modal title="Weather location" subtitle={`Now: ${current.name}${current.region ? `, ${current.region}` : ""}`} onClose={onClose} bodyRef={bodyRef} footer="A: choose · B: close">
      <TextRow label="Town" value={q} placeholder="Type a town or suburb" onChange={setQ} maxLength={40} navDefault />
      {error && <p className="ps-inset px-3 py-2 text-xs text-[#ffe14d]">{error}</p>}
      {results?.length === 0 && <p className="px-3 py-2 text-xs text-[#a9c3ee]">No places found.</p>}
      {results?.map((r) => (
        <button key={`${r.lat},${r.lon}`} onClick={() => onPick(r)} className="ps-row flex min-h-11 flex-col items-start justify-center px-3 py-1.5 text-left">
          <span className="ps-label text-sm">{r.name}</span>
          <span className="ps-hint text-[11px]">{r.region}</span>
        </button>
      ))}
      <button onClick={() => onPick(DEFAULT_PLACE)} className="ps-btn mt-1 flex min-h-10 items-center justify-center text-xs">
        Use {DEFAULT_PLACE.name}
      </button>
    </Modal>
  );
}

// Everything about the box itself: sleep timer, captions, parental lock,
// picture-in-picture, backup / restore.
function SystemTab({ prefs, update, library, sleep, infoStatus, onRefreshInfo, onResetSettings, onStartFresh, onEraseAll, weather, channels = [], remoteInfo, onNewRemoteCode }) {
  const [placing, setPlacing] = useState(false);
  const [freshStatus, setFreshStatus] = useState("");
  const place = prefs.weatherPlace || DEFAULT_PLACE;
  const [pin, setPin] = useState(null); // null | { mode, title, then }
  const [adminOk, setAdminOk] = useState(false);
  const [caps, setCaps] = useState({ features: [], pipEnabled: false });
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef(null);
  const pendingRestore = useRef(null);
  const parental = prefs.parental;
  const hasPin = Boolean(parental.pin);
  const canChange = !hasPin || adminOk;

  useEffect(() => {
    nativeCaps().then(setCaps);
  }, []);

  const setParental = (patch) => update((p) => ({ parental: { ...p.parental, ...patch } }));
  const askPin = (title, then) => setPin({ mode: "check", title, then });
  // Big changes need the parental PIN when one is set.
  const guarded = (title, then) => (hasPin && !adminOk ? askPin(title, then) : then());
  const parentalRef = useRef(null);
  const refocus = () => requestAnimationFrame(() => parentalRef.current && focusFirst(parentalRef.current));

  const doBackup = async () => {
    setBusy(true);
    setStatus("");
    try {
      setStatus(await saveBackup(library));
    } catch (e) {
      setStatus(e?.code === "CANCELLED" || /cancel/i.test(e?.message || "") ? "Backup cancelled" : `Couldn't save the backup: ${e?.message || e}`);
    }
    setBusy(false);
  };

  const finishRestore = async (data) => {
    setBusy(true);
    try {
      const { channels, unmatched } = await restoreBackup(data, library);
      setStatus(`Restored ${channels} channel${channels === 1 ? "" : "s"}${unmatched ? ` (${unmatched} lineup items aren't in this library)` : ""}. Restarting…`);
      setTimeout(() => window.location.reload(), 1200);
    } catch (e) {
      setStatus(`Couldn't restore: ${e?.message || e}`);
      setBusy(false);
    }
  };

  const onFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const data = parseBackup(await file.text());
      if (hasPin && !adminOk) {
        pendingRestore.current = data;
        askPin("Restore backup", () => finishRestore(pendingRestore.current));
      } else finishRestore(data);
    } catch (err) {
      setStatus(err.message);
    }
  };

  const sleepMins = sleep.minutes;
  const sleepHint = sleep.remaining
    ? `Turns off in ${formatClock(sleep.remaining / 1000)}${isNative() ? ", then the app closes so the device can sleep" : ""}`
    : isNative()
      ? "Fades out, then closes the app so the device can sleep. RT or S while watching."
      : "Fades out and stops. S while watching.";

  return (
    <div className="flex flex-col gap-2">
      <SectionLabel>Sleep timer</SectionLabel>
      <Cycler label="Sleep timer" hint={sleepHint} value={sleepMins} options={SLEEP} onChange={(m) => sleep.setMinutes(m)} />

      <SectionLabel>Channel surfing</SectionLabel>
      <Cycler label="Channel up / down" hint="Star channels in the Channels tab" value={Boolean(prefs.surfFavs)} options={SURF} onChange={(v) => update({ surfFavs: v })} />

      <SectionLabel hint="For the weather channel and teletext pages 200 and 201.">Weather</SectionLabel>
      <NavRow
        label="Location"
        icon={<MapPin size={16} className="text-[#a9c3ee]" />}
        hint={weather?.at ? `Forecast updated ${new Date(weather.at).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}` : "Downloads when there's internet"}
        value={place.name}
        navKey="weather-place"
        onClick={() => setPlacing(true)}
      />

      <SectionLabel hint="Subtitle files (.srt or .vtt) with the same name as the video, in the same folder. Relink or rescan the folder to pick up new ones.">
        Captions
      </SectionLabel>
      <Toggle label="Closed captions" hint="C on a keyboard toggles them" checked={prefs.captions} onChange={(v) => update({ captions: v })} />

      <SectionLabel hint="Episode names and posters looked up online (TVmaze) from the show folder names. Kept on this device, so they work offline afterwards.">
        Episode info
      </SectionLabel>
      <Toggle label="Look up episode titles" hint={infoStatus || undefined} checked={prefs.episodeInfo} onChange={(v) => update({ episodeInfo: v })} />
      {prefs.episodeInfo && (
        <button onClick={onRefreshInfo} className={btn}>
          <RefreshCw size={14} /> Look up again
        </button>
      )}

      <SectionLabel hint="Lock channels (in each channel's settings) and shows above a classification behind a 4-digit PIN.">Parental lock</SectionLabel>
      <div ref={parentalRef} className="flex flex-col gap-2">
      {!hasPin ? (
        <NavRow
          label="Set a PIN"
          icon={<KeyRound size={16} className="text-[#a9c3ee]" />}
          navKey="pin-set"
          onClick={() => setPin({ mode: "new", title: "New PIN", then: (p) => { setParental({ pin: p }); setAdminOk(true); } })}
        />
      ) : !canChange ? (
        <NavRow label="Unlock settings" hint="Enter the PIN to change the lock" icon={<Lock size={16} className="text-[#ffd21f]" />} navKey="pin-unlock" onClick={() => askPin("Parental lock", () => setAdminOk(true))} />
      ) : (
        <>
          <Cycler label="Lock shows rated" hint="Set ratings per show in Library" value={parental.lockRating} options={LOCKS} onChange={(v) => setParental({ lockRating: v })} />
          <NavRow label="Change PIN" icon={<KeyRound size={16} className="text-[#a9c3ee]" />} navKey="pin-change" onClick={() => setPin({ mode: "new", title: "New PIN", then: (p) => setParental({ pin: p }) })} />
          <ConfirmButton label="Remove PIN and locks" confirmLabel="Press again to remove" onConfirm={() => { setParental({ pin: "", lockRating: "off" }); setAdminOk(false); refocus(); }} className={btn} />
        </>
      )}
      </div>

      {caps.features?.includes("pip") && (
        <>
          <SectionLabel>Picture-in-picture</SectionLabel>
          <Toggle
            label="Keep playing in a small window"
            hint="When you press Home while something is on"
            checked={Boolean(caps.pipEnabled)}
            onChange={(v) => {
              setCaps((c) => ({ ...c, pipEnabled: v }));
              setPipEnabled(v).catch(() => setCaps((c) => ({ ...c, pipEnabled: !v })));
            }}
          />
        </>
      )}

      {caps.features?.includes("wake") && <WakeTimer channels={channels} />}
      {caps.features?.includes("remote") && (
        <PhoneRemote enabled={Boolean(prefs.remoteOn)} info={remoteInfo} onToggle={(v) => update({ remoteOn: v })} onNewCode={onNewRemoteCode} />
      )}

      <SectionLabel hint="Channels, timetables, breaks, ratings and every setting, as one small file. The video files aren't included: link the same folders on the other device first.">
        Backup
      </SectionLabel>
      <button onClick={doBackup} disabled={busy} className={btn}>
        <Download size={14} /> Save a backup
      </button>
      <button onClick={() => fileRef.current?.click()} disabled={busy} className={btn}>
        <Upload size={14} /> Restore from a backup
      </button>
      <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" tabIndex={-1} onChange={onFile} />
      {status && (
        <p role="status" className="ps-inset px-3 py-2 text-xs font-bold text-[#ffe14d]">
          {status}
        </p>
      )}

      <SectionLabel hint="Start fresh forgets every show and links one folder again (nothing is deleted from the folder). Keep your channels and they're rebuilt from it with a new mix.">
        Start again
      </SectionLabel>
      <ConfirmButton
        label="Start fresh, keep my channels"
        confirmLabel="Press again, then pick the folder"
        onConfirm={() => guarded("Start fresh", async () => setFreshStatus((await onStartFresh(true)) || ""))}
        className={btn}
      >
        {(armed) => (
          <>
            <FolderSync size={14} /> {armed ? "Press again, then pick the folder" : "Start fresh, keep my channels"}
          </>
        )}
      </ConfirmButton>
      <ConfirmButton
        label="Start fresh, delete channels too"
        confirmLabel="Press again, then pick the folder"
        onConfirm={() => guarded("Start fresh", async () => setFreshStatus((await onStartFresh(false)) || ""))}
        className={btn}
      >
        {(armed) => (
          <>
            <FolderSync size={14} /> {armed ? "Press again, then pick the folder" : "Start fresh, delete channels too"}
          </>
        )}
      </ConfirmButton>
      {freshStatus && freshStatus !== "cancelled" && (
        <p role="status" className="ps-inset px-3 py-2 text-xs font-bold text-[#ffe14d]">
          {freshStatus}
        </p>
      )}
      <ConfirmButton label="Reset all settings" confirmLabel="Press again: settings back to new" onConfirm={() => guarded("Reset settings", onResetSettings)} className={btn}>
        {(armed) => (
          <>
            <RotateCcw size={14} /> {armed ? "Press again: settings back to new" : "Reset all settings"}
          </>
        )}
      </ConfirmButton>
      <p className="px-1 text-[11px] text-[#a9c3ee]">Resetting settings keeps your channels, shows and parental PIN.</p>
      <ConfirmButton label="Erase everything" confirmLabel="Press again: erase all channels, shows and settings" onConfirm={() => guarded("Erase everything", onEraseAll)} className={btn}>
        {(armed) => (
          <>
            <Trash2 size={14} /> {armed ? "Press again: erase all of it" : "Erase everything"}
          </>
        )}
      </ConfirmButton>

      <SectionLabel>About</SectionLabel>
      <p className="ps-inset flex items-center gap-2 px-3 py-2.5 text-xs text-[#a9c3ee]">
        <Moon size={14} className="shrink-0 text-[#ffd21f]" />
        <span>
          Cathode Tube{import.meta.env.VITE_OTA_VERSION ? ` · build ${import.meta.env.VITE_OTA_VERSION}` : ""}
          {isNative() && caps.features?.length ? ` · app features: ${caps.features.join(", ")}` : ""}
        </span>
      </p>

      {placing && (
        <PlacePicker
          current={place}
          onPick={(pl) => {
            update({ weatherPlace: pl });
            setPlacing(false);
            requestAnimationFrame(() => document.querySelector('[data-nav-key="weather-place"]')?.focus());
          }}
          onClose={() => {
            setPlacing(false);
            requestAnimationFrame(() => document.querySelector('[data-nav-key="weather-place"]')?.focus());
          }}
        />
      )}
      {pin && (
        <PinPad
          mode={pin.mode}
          title={pin.title}
          check={(p) => p === parental.pin}
          onDone={(p) => {
            const then = pin.then;
            setPin(null);
            then(p);
            refocus();
          }}
          onClose={() => {
            setPin(null);
            pendingRestore.current = null;
            refocus();
          }}
        />
      )}
    </div>
  );
}

export default memo(SystemTab);
