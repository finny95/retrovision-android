import React from "react";
import { VolumeX, Volume2, Lock, Moon, Pause, Rewind } from "lucide-react";
import { formatClock, formatTimeOfDay, programmeTitle } from "@/lib/schedule";
import { Key } from "@/components/tv/controls";
import { episodeLine } from "@/lib/episodeInfo";

// Old-TV on-screen display, drawn over the picture: channel number in the top
// corner, volume bar, MUTE, and an info banner with what's on.

const GLOW = {
  color: "#9dffab",
  textShadow:
    "0 0 4px rgba(140,255,160,0.9), 0 0 14px rgba(110,255,140,0.45), 2px 2px 0 rgba(0,0,0,0.75)",
};
const font = "font-['VT323',ui-monospace,monospace]";
const pad2 = (n) => String(n ?? "").padStart(2, "0");

export function ChannelBug({ channel, compact = false }) {
  if (!channel) return null;
  return (
    <div
      className={`${font} pointer-events-none absolute right-[4%] top-[5%] z-20 max-w-[60%] text-right uppercase leading-none`}
      style={GLOW}
      data-testid="osd-channel"
    >
      <div className={`${compact ? "text-[clamp(2rem,7vmin,3.5rem)]" : "text-[clamp(2.6rem,11vmin,6rem)]"} tracking-wider`}>CH {pad2(channel.number)}</div>
      <div className={`mt-1 truncate ${compact ? "text-[clamp(0.9rem,3vmin,1.4rem)]" : "text-[clamp(1.1rem,4.2vmin,2.2rem)]"} tracking-wide`}>{channel.name}</div>
    </div>
  );
}

const SEGMENTS = 20;

export function VolumeBar({ volume, muted }) {
  const lit = muted ? 0 : Math.round(volume * SEGMENTS);
  return (
    <div
      className={`${font} pointer-events-none absolute inset-x-0 bottom-[9%] z-20 flex justify-center`}
      data-testid="osd-volume"
    >
      <div className="flex items-center gap-[0.6em] rounded bg-black/35 px-[0.6em] py-[0.2em] text-[clamp(1.2rem,5vmin,2.6rem)] uppercase leading-none" style={GLOW}>
        <span>{muted ? "Mute" : "Volume"}</span>
        <span className="flex h-[0.7em] items-stretch gap-[0.12em]" aria-hidden>
          {Array.from({ length: SEGMENTS }, (_, i) => (
            <span
              key={i}
              className="w-[0.32em]"
              style={{ background: i < lit ? GLOW.color : "rgba(157,255,171,0.16)", boxShadow: i < lit ? "0 0 6px rgba(140,255,160,0.6)" : "none" }}
            />
          ))}
        </span>
        <span className="w-[1.6em] text-right tabular-nums">{muted ? "--" : Math.round(volume * 100)}</span>
      </div>
    </div>
  );
}

export function MuteTag() {
  return (
    <div className={`${font} pointer-events-none absolute left-[4%] top-[5%] z-20 flex items-center gap-2 text-[clamp(1.2rem,5vmin,2.4rem)] uppercase leading-none`} style={GLOW}>
      <VolumeX className="h-[1em] w-[1em]" strokeWidth={2.5} /> Mute
    </div>
  );
}

// Pay-TV "mini guide" banner: channel, now (with progress) and next.
export function InfoBanner({ channel, nn, nowMs, file, label, boostDb, hints, compact = false, note = null }) {
  const now = nn?.now;
  const next = nn?.next;
  let pct = 0;
  let left = null;
  if (now) {
    pct = Math.min(100, ((nowMs - now.startMs) / Math.max(1, now.endMs - now.startMs)) * 100);
    left = (now.endMs - nowMs) / 1000;
  } else if (file?.duration) {
    pct = Math.min(100, (file.time / file.duration) * 100);
    left = file.duration - file.time;
  }
  const title = now ? programmeTitle(now) : label;
  const sub = now?.media ? episodeLine(now.media) : file?.sub || "";
  return (
    <div className={`ps-panel pointer-events-none absolute z-10 overflow-hidden ${compact ? "inset-x-[3%] bottom-[4%]" : "inset-x-[5%] bottom-[6%]"}`} data-testid="osd-info">
      <div className="ps-titlebar flex items-center gap-2 px-3 py-1">
        {channel ? (
          <>
            <span className="ps-btn-primary px-2 text-sm tabular-nums">{pad2(channel.number)}</span>
            <span className="min-w-0 truncate text-sm font-bold italic uppercase text-white">{channel.logoText || channel.name}</span>
          </>
        ) : (
          <span className="text-sm font-bold uppercase text-white">Now playing</span>
        )}
        {boostDb > 0 && (
          <span className="ml-1 flex shrink-0 items-center gap-1 text-[11px] font-bold text-[#ffe14d]">
            <Volume2 size={12} /> +{boostDb} dB
          </span>
        )}
        <span className="ml-auto shrink-0 text-sm font-bold text-white">{formatTimeOfDay(nowMs)}</span>
      </div>
      <div className={`grid grid-cols-[auto_1fr] items-center gap-x-3 gap-y-0.5 px-3 ${compact ? "py-1.5" : "py-2"}`}>
        <span className="text-[11px] font-bold uppercase text-[#ffd21f]">Now</span>
        <span className="flex min-w-0 items-center gap-2">
          {now && <span className="shrink-0 text-xs font-bold text-[#a9c3ee]">{formatTimeOfDay(now.startMs)}</span>}
          <span className="min-w-0 truncate text-sm font-bold text-white sm:text-base">{title}</span>
        </span>
        <span />
        <span className="flex min-w-0 items-center gap-2">
          <span className="ps-inset relative h-2 flex-1 overflow-hidden !rounded-full">
            <span className="absolute inset-y-0 left-0 bg-gradient-to-b from-[#fff27a] to-[#f5b800]" style={{ width: `${pct}%` }} />
          </span>
          {left != null && <span className="shrink-0 text-[11px] font-bold text-[#a9c3ee]">{formatClock(left)} left</span>}
        </span>
        {sub && (
          <>
            <span />
            <span className="truncate text-xs text-[#a9c3ee]">{sub}</span>
          </>
        )}
        {note && (
          <>
            <span />
            <span className="truncate text-[11px] font-bold text-[#ffe14d]" data-testid="osd-note">{note}</span>
          </>
        )}
        {next && (
          <>
            <span className="text-[11px] font-bold uppercase text-[#8fc4ff]">Next</span>
            <span className="flex min-w-0 items-center gap-2">
              <span className="shrink-0 text-xs font-bold text-[#a9c3ee]">{formatTimeOfDay(next.startMs)}</span>
              <span className="min-w-0 truncate text-sm text-white">{programmeTitle(next)}</span>
            </span>
          </>
        )}
      </div>
      {hints && !compact && (
        <p className="flex flex-wrap gap-x-4 gap-y-1 border-t border-[#2d5bb8] bg-[#071741] px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-[#a9c3ee]">
          {hints.map(([k, v]) => (
            <span key={k} className="flex items-center gap-1">
              <Key>{k}</Key> {v}
            </span>
          ))}
        </p>
      )}
    </div>
  );
}


// Centre message: "No signal", load problems.
export function ScreenMessage({ children, icon }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center px-6 text-center">
      <span className={`${font} flex flex-col items-center gap-1 rounded bg-black/55 px-3 py-1 text-[clamp(1.2rem,5vmin,2.2rem)] uppercase leading-tight`} style={GLOW}>
        {icon}
        <span>{children}</span>
      </span>
    </div>
  );
}

// Typing a channel number on the remote: "CH 1-".
export function NumberEntry({ digits, missing = false, compact = false }) {
  return (
    <div className={`${font} pointer-events-none absolute right-[4%] top-[5%] z-20 text-right uppercase leading-none`} style={GLOW} data-testid="osd-number">
      <div className={`${compact ? "text-[clamp(2rem,7vmin,3.5rem)]" : "text-[clamp(2.6rem,11vmin,6rem)]"} tracking-wider`}>
        CH {missing ? digits : digits.padEnd(2, "-")}
      </div>
      {missing && <div className={`mt-1 ${compact ? "text-[clamp(0.9rem,3vmin,1.4rem)]" : "text-[clamp(1.1rem,4.2vmin,2.2rem)]"}`}>No channel</div>}
    </div>
  );
}

// Small status tag under the corner (sleep timer, captions on / off).
export function CornerTag({ children, icon, lower = false }) {
  return (
    <div
      className={`${font} pointer-events-none absolute left-[4%] z-20 flex items-center gap-2 text-[clamp(1.1rem,4.5vmin,2.2rem)] uppercase leading-none ${lower ? "top-[14%]" : "top-[5%]"}`}
      style={GLOW}
      data-testid="osd-tag"
    >
      {icon}
      {children}
    </div>
  );
}

export const SleepIcon = () => <Moon className="h-[0.9em] w-[0.9em]" strokeWidth={2.5} />;

// Parental lock over the picture.
export function LockScreen({ reason, hint }) {
  return (
    <div className="absolute inset-0 z-[15] flex flex-col items-center justify-center gap-2 bg-[#020a24] px-6 text-center" data-testid="lock-screen">
      <span className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-[#ffd21f] bg-[#0b2a7a]">
        <Lock size={26} className="text-[#ffd21f]" />
      </span>
      <p className="text-base font-bold uppercase tracking-wide text-white">{reason}</p>
      <p className="text-xs font-bold uppercase tracking-wider text-[#a9c3ee]">{hint}</p>
    </div>
  );
}

// Sleep timer ran out (in a browser; the app closes itself instead).
export function AsleepScreen({ hint }) {
  return (
    <div className="absolute inset-0 z-[16] flex flex-col items-center justify-center gap-2 bg-black text-center" data-testid="asleep">
      <span className={`${font} text-[clamp(1.6rem,7vmin,3rem)] uppercase`} style={GLOW}>Goodnight</span>
      <span className="text-[11px] font-bold uppercase tracking-wider text-[#6f8cc4]">{hint}</span>
    </div>
  );
}

// Start over / paused live TV: how far behind live the channel is.
export function TimeshiftTag({ paused, behindMs }) {
  return (
    <div className={`${font} pointer-events-none absolute left-1/2 top-[5%] z-20 flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded bg-black/40 px-[0.5em] text-[clamp(1.1rem,4.5vmin,2.2rem)] uppercase leading-none`} style={GLOW} data-testid="osd-timeshift">
      {paused ? <Pause className="h-[0.9em] w-[0.9em]" strokeWidth={3} /> : <Rewind className="h-[0.9em] w-[0.9em]" strokeWidth={3} />}
      {paused ? "Paused" : `-${formatClock(behindMs / 1000)}`}
    </div>
  );
}
