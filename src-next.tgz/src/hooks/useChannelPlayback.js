import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { whatsOn } from "@/lib/schedule";

// Keeps the <video> in sync with a channel's real-time schedule.
// The schedule is a list of items: episode parts (between break points), ads and
// bumpers ("coming up next" cards, drawn by the app instead of a video). Tunes in
// at the live offset, stops each part exactly at its break point, and moves on
// to whatever is next. Re-syncs if the player drifts from the wall clock.
// onEmpty runs when the channel has nothing playable, so the old picture doesn't linger.
// shiftMs: how far behind live this channel is (start over / paused live TV).
// paused: live TV paused; nothing re-tunes until it's resumed.
export default function useChannelPlayback({ videoRef, channel, media, playBlob, onEmpty, scheduleKey, loadedIdRef, shiftMs = 0, paused = false }) {
  const shiftRef = useRef(shiftMs);
  shiftRef.current = shiftMs;
  const pausedRef = useRef(paused);
  pausedRef.current = paused;
  const at = () => Date.now() - shiftRef.current;
  const [nowPlaying, setNowPlaying] = useState(null);
  const [bumper, setBumper] = useState(null);
  const keyRef = useRef(null);
  const itemRef = useRef(null);
  const pendingSeekRef = useRef(null);
  const timerRef = useRef(null);

  const tune = useCallback(() => {
    clearTimeout(timerRef.current);
    if (!channel || pausedRef.current) return;
    const on = whatsOn(channel, media, at());
    const v = videoRef.current;
    if (!on) {
      setNowPlaying(null);
      setBumper(null);
      keyRef.current = null;
      itemRef.current = null;
      onEmpty?.();
      return;
    }
    const it = on.current;
    keyRef.current = on.key;
    itemRef.current = it;
    setNowPlaying(on);
    if (it.kind === "bumper") {
      v?.pause();
      const now = Date.now();
      setBumper({ ...it, key: on.key, startedAt: now - on.offset * 1000, endsAt: now + on.remaining * 1000 });
      timerRef.current = setTimeout(() => tune(), Math.max(50, on.remaining * 1000 + 40));
      return;
    }
    setBumper(null);
    const target = (it.from || 0) + on.offset;
    if (v && loadedIdRef?.current === it.media.id && v.getAttribute("src") && v.readyState >= 1) {
      if (Math.abs(v.currentTime - target) > 1.5) v.currentTime = target;
      v.play().catch(() => {});
    } else {
      pendingSeekRef.current = target;
      playBlob(it.media, it.media.name, it.media.id, it.media.type);
    }
  }, [channel, media, playBlob, onEmpty, videoRef, loadedIdRef]);

  // Tune when the channel or its lineup changes, when the library changes in a way
  // that affects the schedule, or when broadcast settings change (scheduleKey).
  const libraryKey = useMemo(
    () => media.map((m) => `${m.id}:${m.show}:${m.season}:${m.duration}:${(m.breaks || []).join(",")}`).join("|"),
    [media]
  );
  useEffect(() => {
    if (!channel) {
      setNowPlaying(null);
      setBumper(null);
      keyRef.current = null;
      itemRef.current = null;
    }
    tune();
    return () => clearTimeout(timerRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channel?.id, channel?.blocks, channel?.lineup, channel?.shows, channel?.adShows, channel?.adsPerBreak, channel?.timetable, channel?.identShow, channel?.promoShow, channel?.allDay, channel?.weather, channel?.musicShow, channel?.seed, libraryKey, scheduleKey, shiftMs, paused]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v || !channel) return undefined;

    const applySeek = () => {
      if (pendingSeekRef.current != null && isFinite(v.duration)) {
        v.currentTime = Math.min(pendingSeekRef.current, Math.max(0, v.duration - 0.25));
      }
      pendingSeekRef.current = null;
    };
    // At the end of a part (or an ad), hold until the schedule moves on, so the
    // picture never runs past a break point.
    const atEnd = () => {
      if (pausedRef.current) return;
      const on = whatsOn(channel, media, at());
      if (on && on.key === keyRef.current) {
        v.pause();
        clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => tune(), Math.max(30, on.remaining * 1000 + 30));
      } else tune();
    };
    const onTime = () => {
      const it = itemRef.current;
      if (!it || it.kind === "bumper" || it.to == null || v.seeking || v.paused) return;
      if (v.currentTime >= it.to - 0.15 && it.to < (v.duration || Infinity) - 0.3) atEnd();
    };
    const onEnded = () => atEnd();

    v.addEventListener("loadedmetadata", applySeek);
    v.addEventListener("timeupdate", onTime);
    v.addEventListener("ended", onEnded);

    // Drift check: if the schedule says something else is on, re-sync.
    const timer = setInterval(() => {
      if (pausedRef.current) return;
      const on = whatsOn(channel, media, at());
      if (!on) return;
      if (on.key !== keyRef.current) {
        tune();
        return;
      }
      setNowPlaying(on);
      const it = on.current;
      // Only correct drift once the picture is actually playing. Correcting while the
      // file is still loading or seeking restarts the seek, and on slower storage that
      // loops forever (stuck on "Loading signal").
      if (it.kind !== "bumper" && !v.paused && !v.seeking && v.readyState >= 3) {
        const want = (it.from || 0) + on.offset;
        if (Math.abs(v.currentTime - want) > 3) v.currentTime = want;
      }
    }, 2000);

    return () => {
      v.removeEventListener("loadedmetadata", applySeek);
      v.removeEventListener("timeupdate", onTime);
      v.removeEventListener("ended", onEnded);
      clearInterval(timer);
    };
  }, [channel, media, tune, videoRef]);

  return { nowPlaying, bumper };
}
