import { useEffect, useRef } from "react";
import { drawBumper, drawDog, drawNextStrip, drawRatingBug } from "@/lib/broadcastGfx";
import { programmeTitle } from "@/lib/schedule";

// Owns the canvas of channel graphics the CRT shader lays over the picture.
// Redraws only when what's on it changes (or every frame while animating), and
// tells CRTPlayer through gfxRef: { canvas, dirty, animating, visible, resize }.
export default function useBroadcastGfx({ videoRef, state }) {
  const stateRef = useRef(state);
  stateRef.current = state;
  const gfxRef = useRef(null);
  if (!gfxRef.current) {
    const canvas = document.createElement("canvas");
    canvas.width = 960;
    canvas.height = 540;
    gfxRef.current = {
      canvas,
      dirty: true,
      animating: false,
      visible: false,
      resize(w, h) {
        const ch = Math.max(240, Math.round((960 * h) / Math.max(1, w)));
        if (canvas.height === ch) return false;
        canvas.height = ch;
        this.sig = "";
        this.dirty = true;
        return true;
      },
      sig: "",
    };
  }

  useEffect(() => {
    let raf;
    let fontsReady = false;
    Promise.all([document.fonts?.load?.("700 40px Arimo"), document.fonts?.load?.("italic 700 40px Arimo")]).then(() => {
      fontsReady = true;
      gfxRef.current.sig = "";
    }).catch(() => {});
    const ctx = gfxRef.current.canvas.getContext("2d");
    let stripAt = 0;
    let lastStripKey = "";

    const frame = () => {
      raf = requestAnimationFrame(frame);
      const g = gfxRef.current;
      const s = stateRef.current;
      const { canvas } = g;
      const w = canvas.width;
      const h = canvas.height;
      const now = Date.now();
      const b = s.bumper;
      const bc = s.settings;

      if (b) {
        g.animating = true;
        ctx.clearRect(0, 0, w, h);
        drawBumper(ctx, w, h, b, (now - b.startedAt) / 1000, s.channel);
        g.visible = true;
        g.dirty = true;
        g.sig = `bumper:${b.key}`;
        return;
      }
      g.animating = false;

      // Overlays over a programme: logo, classification bug, "Next" strip.
      const it = s.item;
      const v = videoRef.current;
      const parts = [];
      let bugAlpha = 0;
      let strip = 0;
      if (s.channel && it && it.kind === "show" && v) {
        const into = v.currentTime - (it.from || 0);
        if (bc.dog) parts.push(`dog:${bc.dogCorner}:${bc.dogOpacity}:${s.channel.id}:${s.channel.logoText || s.channel.name}`);
        const rating = s.ratings?.[it.media?.show];
        if (bc.ratingBug && rating && it.part === 0 && into >= 0 && into < bc.ratingBugSecs) {
          bugAlpha = clampFade(into, bc.ratingBugSecs);
          parts.push(`bug:${rating}:${Math.round(bugAlpha * 10)}`);
        }
        const left = (it.to ?? v.duration) - v.currentTime;
        if (bc.nextStrip && s.next && it.part === (it.parts || 1) - 1 && left > 0 && left < bc.nextStripSecs) {
          const key = `${it.media?.id}:${s.next.startMs}`;
          if (key !== lastStripKey) {
            lastStripKey = key;
            stripAt = now;
          }
          strip = Math.min(1, (now - stripAt) / 600);
          parts.push(`strip:${key}:${Math.round(strip * 20)}`);
        }
      }
      const sig = `${fontsReady}|${w}x${h}|${parts.join("|")}`;
      if (sig === g.sig) return;
      g.sig = sig;
      ctx.clearRect(0, 0, w, h);
      if (!parts.length) {
        g.visible = false;
        g.dirty = true;
        return;
      }
      if (bc.dog) drawDog(ctx, w, h, s.channel, bc.dogCorner, bc.dogOpacity);
      if (bugAlpha > 0) drawRatingBug(ctx, w, h, s.ratings[it.media.show], bugAlpha);
      if (strip > 0) drawNextStrip(ctx, w, h, programmeTitle(s.next), s.channel, strip);
      g.visible = true;
      g.dirty = true;
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [videoRef]);

  return gfxRef;
}

function clampFade(t, total) {
  return Math.max(0, Math.min(1, Math.min(t / 0.4, (total - t) / 0.6)));
}
