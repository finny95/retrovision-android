import React, { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { Check, X } from "lucide-react";
import { useBackHandler } from "@/components/tv/backStack";
import { focusEl } from "@/lib/spatialNav";

// Full list of choices for a setting, opened from a Cycler. Controller: Up/Down
// to move, A to choose, B to close.
export default function Picker({ title, options, value, onPick, onClose }) {
  const listRef = useRef(null);
  useBackHandler(() => {
    onClose();
    return true;
  });

  useEffect(() => {
    const el = listRef.current?.querySelector('[aria-selected="true"]') || listRef.current?.querySelector("button");
    focusEl(el);
  }, []);

  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        data-nav-modal
        role="dialog"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        className="flex max-h-[80vh] w-full max-w-sm flex-col overflow-hidden rounded-2xl border border-white/10 bg-neutral-950 shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-neutral-300">{title}</p>
          <button tabIndex={-1} onClick={onClose} className="rounded p-1 text-neutral-500 hover:text-white" aria-label="Close">
            <X size={16} />
          </button>
        </div>
        <div ref={listRef} className="flex flex-col gap-1 overflow-y-auto p-2" role="listbox">
          {options.map((o) => {
            const on = o.value === value;
            return (
              <button
                key={String(o.value)}
                role="option"
                aria-selected={on}
                onClick={() => onPick(o.value)}
                className={`flex min-h-11 items-center justify-between gap-3 rounded-xl px-3 py-2 text-left text-sm transition ${
                  on ? "bg-amber-400/15 text-amber-200" : "text-neutral-200 hover:bg-white/5"
                }`}
              >
                <span className="truncate">{o.label}</span>
                {on && <Check size={15} className="shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>,
    document.body
  );
}

// Pick several (e.g. which shows a channel plays). A toggles, B or Done closes.
export function MultiPicker({ title, hint, options, values, onChange, onClose }) {
  const listRef = useRef(null);
  useBackHandler(() => {
    onClose();
    return true;
  });
  useEffect(() => {
    focusEl(listRef.current?.querySelector('[role="option"]') || listRef.current?.querySelector("button"));
  }, []);
  const toggle = (v) => onChange(values.includes(v) ? values.filter((x) => x !== v) : [...values, v]);

  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        data-nav-modal
        role="dialog"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        className="flex max-h-[85vh] w-full max-w-md flex-col overflow-hidden rounded-2xl border border-white/10 bg-neutral-950 shadow-2xl"
      >
        <div className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-3">
          <div className="min-w-0">
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-neutral-300">
              {title} <span className="text-amber-300">· {values.length} picked</span>
            </p>
            {hint && <p className="mt-0.5 text-[11px] text-neutral-500">{hint}</p>}
          </div>
          <button tabIndex={-1} onClick={onClose} className="shrink-0 rounded-full bg-amber-400 px-3 py-1.5 font-mono text-[11px] uppercase tracking-wider text-neutral-950">
            Done
          </button>
        </div>
        <div ref={listRef} className="flex flex-col gap-1 overflow-y-auto p-2" role="listbox" aria-multiselectable>
          {options.length === 0 && <p className="p-4 text-center text-sm text-neutral-500">Nothing to pick yet. Add shows in Library first.</p>}
          {options.map((o) => {
            const on = values.includes(o.value);
            return (
              <button
                key={String(o.value)}
                role="option"
                aria-selected={on}
                onClick={() => toggle(o.value)}
                className={`flex min-h-11 items-center gap-3 rounded-xl px-3 py-2 text-left text-sm transition ${
                  on ? "bg-amber-400/15 text-amber-100" : "text-neutral-200 hover:bg-white/5"
                }`}
              >
                <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border ${on ? "border-amber-400 bg-amber-400 text-neutral-950" : "border-white/25"}`}>
                  {on && <Check size={13} strokeWidth={3} />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate">{o.label}</span>
                  {o.hint && <span className="block truncate text-[11px] text-neutral-500">{o.hint}</span>}
                </span>
              </button>
            );
          })}
        </div>
        <p className="border-t border-white/10 px-4 py-2 font-mono text-[10px] uppercase tracking-wider text-neutral-500">A: pick / unpick · B: done</p>
      </div>
    </div>,
    document.body
  );
}
