import React from "react";
import { Tv, HardDrive, SlidersHorizontal, Volume2, X } from "lucide-react";
import { Key } from "@/components/tv/controls";

export const TABS = [
  { id: "channels", label: "Channels", icon: Tv },
  { id: "library", label: "Library", icon: HardDrive },
  { id: "picture", label: "Picture", icon: SlidersHorizontal },
  { id: "sound", label: "Sound", icon: Volume2 },
];

// The menu: four tabs, one focus scope. variant:
//   "overlay" - slides over the picture (TV / handheld landscape)
//   "column"  - fixed side column (desktop)
//   "inline"  - under the screen (phone portrait)
export default function MenuPanel({ variant, tab, onTab, onClose, showHints, controller = true, header, children }) {
  const overlay = variant === "overlay";
  const shell = {
    overlay: "fixed inset-y-0 right-0 z-40 flex w-[min(26rem,94vw)] flex-col border-l border-white/10 bg-neutral-950/[0.97] shadow-[-30px_0_60px_-20px_rgba(0,0,0,0.9)]",
    column: "flex h-full min-h-0 flex-col overflow-hidden rounded-2xl border border-white/10 bg-neutral-900/60 backdrop-blur",
    inline: "flex flex-col rounded-2xl border border-white/10 bg-neutral-900/60 backdrop-blur",
  }[variant];

  return (
    <section data-nav-scope data-menu-panel className={shell} aria-label="Menu">
      {header}
      <div
        role="tablist"
        className={`flex items-center gap-1 border-b border-white/10 px-2 py-2 ${variant === "inline" ? "sticky top-0 z-10 rounded-t-2xl bg-neutral-950/95 backdrop-blur" : ""}`}
      >
        {showHints && controller && <span className="hidden shrink-0 pl-1 sm:inline"><Key>LB</Key></span>}
        {TABS.map((t) => {
          const Icon = t.icon;
          const on = t.id === tab;
          return (
            <button
              key={t.id}
              role="tab"
              aria-selected={on}
              data-tab={t.id}
              onClick={() => onTab(t.id)}
              className={`flex min-h-10 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 rounded-xl px-1 py-1 transition focus:bg-amber-400/15 ${overlay ? "" : "sm:flex-row sm:gap-1.5"} ${
                on ? "bg-white/[0.08] text-amber-300" : "text-neutral-400 hover:text-neutral-100"
              }`}
            >
              <Icon size={15} className="shrink-0" />
              <span className={`truncate text-[11px] font-medium ${overlay ? "" : "sm:text-xs"}`}>{t.label}</span>
            </button>
          );
        })}
        {showHints && controller && <span className="hidden shrink-0 pr-1 sm:inline"><Key>RB</Key></span>}
        {overlay && (
          <button tabIndex={-1} onClick={onClose} className="ml-1 shrink-0 rounded-full p-2 text-neutral-500 hover:text-white" aria-label="Close menu">
            <X size={16} />
          </button>
        )}
      </div>

      <div data-menu-content className={`${variant === "inline" ? "" : "min-h-0 flex-1 overflow-y-auto overscroll-contain"} p-3`}>
        {children}
      </div>

      {showHints && (
        <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 border-t border-white/10 px-3 py-2 font-mono text-[10px] uppercase tracking-wider text-neutral-500">
          <span><Key>✥</Key> Move</span>
          <span><Key>◀▶</Key> Change</span>
          <span><Key>{controller ? "A" : "OK"}</Key> Select</span>
          <span><Key>{controller ? "B" : "Back"}</Key> Back</span>
          {controller && <span><Key>Start</Key> {overlay ? "Close" : "Watch"}</span>}
        </div>
      )}
    </section>
  );
}
