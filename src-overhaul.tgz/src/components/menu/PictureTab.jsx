import React, { memo, useMemo } from "react";
import { RotateCcw } from "lucide-react";
import { FIELDS, PRESETS, RETRO, formatSetting } from "@/lib/crtSettings";
import { Cycler, SliderRow, SectionLabel } from "@/components/tv/controls";

const same = (a, b) => FIELDS.every((f) => Math.abs((a[f.key] ?? 0) - (b[f.key] ?? 0)) < 1e-6);

// One setting per row: Up/Down picks the setting, Left/Right changes it.
function PictureTab({ settings, onChange }) {
  const look = useMemo(() => Object.keys(PRESETS).find((k) => same(settings, PRESETS[k])) || "Custom", [settings]);
  const options = useMemo(() => {
    const list = Object.keys(PRESETS).map((k) => ({ value: k, label: k }));
    return look === "Custom" ? [...list, { value: "Custom", label: "Custom" }] : list;
  }, [look]);

  return (
    <div className="flex flex-col gap-2">
      <Cycler
        label="Look"
        hint="Pick a style, then fine-tune below"
        value={look}
        options={options}
        onChange={(v) => PRESETS[v] && onChange({ ...settings, ...PRESETS[v] })}
      />
      <SectionLabel hint="Up / Down picks a setting · Left / Right changes it">Fine-tune</SectionLabel>
      {FIELDS.map((f) => (
        <SliderRow
          key={f.key}
          label={f.label}
          value={settings[f.key]}
          min={f.min}
          max={f.max}
          step={f.step}
          display={formatSetting(f, settings[f.key])}
          onChange={(v) => onChange({ ...settings, [f.key]: v })}
        />
      ))}
      <button
        onClick={() => onChange({ ...RETRO })}
        className="mt-1 flex min-h-11 items-center justify-center gap-2 rounded-xl border border-white/10 text-sm text-neutral-300 transition hover:text-white focus:border-amber-400 focus:bg-amber-400/10"
      >
        <RotateCcw size={14} /> Reset picture
      </button>
    </div>
  );
}

export default memo(PictureTab);
