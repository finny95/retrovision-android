import React, { useEffect, useState } from "react";
import { Plus, Pencil, Radio, HardDrive } from "lucide-react";
import ChannelEditor from "@/components/ChannelEditor";
import { whatsOn, formatClock } from "@/lib/schedule";

function useNow(ms) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return now;
}

const pad2 = (n) => String(n).padStart(2, "0");

function ChannelList({ channels, media, activeId, onTune, onNew, onEdit, onGoLibrary }) {
  const now = useNow(5000);
  return (
    <div className="flex flex-col gap-2">
      <button
        onClick={onNew}
        data-nav-key="new-channel"
        data-nav-default={channels.length === 0 || undefined}
        className="flex min-h-11 items-center justify-center gap-2 rounded-xl border border-dashed border-amber-400/40 text-sm text-amber-200 transition hover:bg-amber-400/10 focus:border-amber-400 focus:bg-amber-400/10"
      >
        <Plus size={15} /> New channel
      </button>

      {channels.length === 0 && (
        <div className="rounded-xl border border-white/10 p-4 text-center text-sm text-neutral-400">
          <p>No channels yet.</p>
          <p className="mt-1 text-xs text-neutral-500">Add your show folders in Library, then build a channel from them.</p>
          {media.length === 0 && (
            <button onClick={onGoLibrary} className="mx-auto mt-3 flex min-h-10 items-center gap-2 rounded-full border border-white/15 px-4 text-xs text-neutral-200 focus:border-amber-400/70">
              <HardDrive size={14} /> Go to Library
            </button>
          )}
        </div>
      )}

      {channels.map((c) => {
        const on = whatsOn(c, media, now);
        const active = activeId === c.id;
        return (
          <div key={c.id} className="flex items-stretch gap-2">
            <button
              onClick={() => onTune(c)}
              data-nav-key={`ch:${c.id}`}
              data-nav-default={active || undefined}
              className={`flex min-w-0 flex-1 items-center gap-3 rounded-xl border px-3 py-2 text-left transition focus:border-amber-400 focus:bg-amber-400/10 ${
                active ? "border-amber-400/50 bg-amber-400/[0.07]" : "border-white/10 bg-white/[0.03] hover:border-white/25"
              }`}
            >
              <span className="w-12 shrink-0 font-['VT323',ui-monospace,monospace] text-3xl leading-none tabular-nums text-[#9dffab]">{pad2(c.number)}</span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="truncate text-sm font-medium text-neutral-100">{c.name}</span>
                  {active && (
                    <span className="flex shrink-0 items-center gap-1 rounded bg-red-500/20 px-1.5 py-px font-mono text-[9px] uppercase tracking-wider text-red-300">
                      <Radio size={9} /> On
                    </span>
                  )}
                </span>
                {on ? (
                  <>
                    <span className="block truncate text-xs text-neutral-400">
                      {on.current.kind === "ad" ? "Ad break · " : ""}
                      {on.current.media.name}
                    </span>
                    <span className="block truncate font-mono text-[10px] text-neutral-600">
                      {formatClock(on.remaining)} left · Next: {on.upcoming[0]?.media.name}
                    </span>
                  </>
                ) : (
                  <span className="block font-mono text-[10px] text-neutral-600">No episodes found</span>
                )}
              </span>
            </button>
            <button
              onClick={() => onEdit(c)}
              className="flex w-12 shrink-0 items-center justify-center rounded-xl border border-white/10 text-neutral-400 transition hover:text-white focus:border-amber-400 focus:text-amber-200"
              aria-label={`Edit ${c.name}`}
            >
              <Pencil size={16} />
            </button>
          </div>
        );
      })}
    </div>
  );
}

export default function ChannelsTab({ channels, media, shows, activeId, editing, onEdit, onTune, onSave, onDelete, onGoLibrary }) {
  if (editing) {
    return (
      <ChannelEditor
        key={editing === "new" ? "new" : editing.id}
        initial={editing === "new" ? null : editing}
        shows={shows}
        media={media}
        nextNumber={Math.max(0, ...channels.map((c) => c.number)) + 1}
        onSave={onSave}
        onCancel={() => onEdit(null)}
        onDelete={onDelete}
      />
    );
  }
  return (
    <ChannelList
      channels={channels}
      media={media}
      activeId={activeId}
      onTune={onTune}
      onNew={() => onEdit("new")}
      onEdit={onEdit}
      onGoLibrary={onGoLibrary}
    />
  );
}
