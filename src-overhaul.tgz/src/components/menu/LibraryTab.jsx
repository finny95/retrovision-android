import React, { memo, useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Link2, FilePlus, FolderPlus, Play, Trash2, Film, Music, Folder, Volume2, Zap } from "lucide-react";
import { canLinkFolders } from "@/lib/linkedFolder";
import { isNative } from "@/native/platform";
import { formatClock } from "@/lib/schedule";
import { useBackHandler } from "@/components/tv/backStack";
import { Cycler, SliderRow, ConfirmButton, SectionLabel } from "@/components/tv/controls";
import { focusFirst, refocus } from "@/lib/spatialNav";

export const LOOSE = "__loose__";
const PAGE = 50;
const order = new Intl.Collator(undefined, { numeric: true, sensitivity: "base" });
const keyOf = (m) => m.show || LOOSE;
export const showTitle = (key) => (key === LOOSE ? "Loose files" : key);
export const boostLabel = (db) => (db > 0 ? `+${db} dB` : "Off");

function formatSize(bytes) {
  if (bytes > 1e9) return `${(bytes / 1e9).toFixed(1)} GB`;
  if (bytes > 1e6) return `${(bytes / 1e6).toFixed(0)} MB`;
  return `${Math.max(1, Math.round((bytes || 0) / 1e3))} KB`;
}

const actionCls =
  "flex min-h-11 items-center justify-center gap-2 rounded-xl border border-white/15 px-3 py-2 text-sm text-neutral-200 transition hover:border-amber-400/60 focus:border-amber-400 focus:bg-amber-400/10 disabled:opacity-40";

function ShowList({ groups, total, playingShow, boost, importing, onOpenShow, onAddFiles, onLink, onQuickPlay }) {
  const fileRef = useRef(null);
  const folderRef = useRef(null);
  const quickRef = useRef(null);
  const pick = (e) => {
    onAddFiles(Array.from(e.target.files || []));
    e.target.value = "";
  };
  const linkable = canLinkFolders();

  return (
    <div className="flex flex-col gap-2">
      <div className="grid grid-cols-2 gap-2">
        {linkable && (
          <button onClick={onLink} disabled={Boolean(importing)} data-nav-default={groups.length === 0 || undefined} className={`${actionCls} col-span-2 border-amber-400/40 text-amber-200`}>
            <Link2 size={15} /> Link a shows folder
          </button>
        )}
        <button onClick={() => fileRef.current?.click()} disabled={Boolean(importing)} className={actionCls}>
          <FilePlus size={15} /> Add files
        </button>
        {!isNative() ? (
          <button onClick={() => folderRef.current?.click()} disabled={Boolean(importing)} className={actionCls}>
            <FolderPlus size={15} /> Copy a folder
          </button>
        ) : null}
        <button onClick={() => quickRef.current?.click()} className={`${actionCls} ${isNative() ? "" : "col-span-2"}`}>
          <Zap size={15} /> Quick play
        </button>
        <input ref={fileRef} type="file" accept="video/*,audio/*" multiple className="hidden" onChange={pick} tabIndex={-1} />
        <input ref={folderRef} type="file" webkitdirectory="" multiple className="hidden" onChange={pick} tabIndex={-1} />
        <input
          ref={quickRef}
          type="file"
          accept="video/*,audio/*"
          className="hidden"
          tabIndex={-1}
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onQuickPlay(f);
            e.target.value = "";
          }}
        />
      </div>
      {linkable && groups.length === 0 && (
        <p className="px-1 text-[11px] leading-snug text-neutral-500">
          Pick the folder that holds your shows (Show / Season / episodes). Nothing is copied: files stay where they are.
        </p>
      )}
      {importing && (
        <p role="status" className="rounded-lg bg-amber-400/10 px-3 py-2 font-mono text-[11px] uppercase tracking-wider text-amber-200">
          Adding {importing.done} of {importing.total}…
        </p>
      )}

      {groups.length > 0 && (
        <SectionLabel>
          {groups.filter((g) => g.key !== LOOSE).length} shows · {total} files
        </SectionLabel>
      )}
      {groups.map((g) => {
        const db = g.key === LOOSE ? 0 : boost[g.key] || 0;
        const playing = playingShow === g.key;
        return (
          <button
            key={g.key}
            onClick={() => onOpenShow(g.key)}
            data-nav-key={`show:${g.key}`}
            className={`flex min-h-12 items-center gap-3 rounded-xl border px-3 py-2 text-left transition focus:border-amber-400 focus:bg-amber-400/10 ${
              playing ? "border-amber-400/40 bg-amber-400/[0.05]" : "border-white/10 bg-white/[0.03] hover:border-white/25"
            }`}
          >
            <Folder size={16} className="shrink-0 text-amber-300/80" />
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm text-neutral-100">{showTitle(g.key)}</span>
              <span className="block truncate font-mono text-[10px] text-neutral-500">
                {g.seasons > 1 ? `${g.seasons} seasons · ` : ""}
                {g.count} {g.count === 1 ? "file" : "files"}
              </span>
            </span>
            {db > 0 && (
              <span className="flex shrink-0 items-center gap-1 rounded bg-emerald-400/10 px-1.5 py-0.5 font-mono text-[10px] text-emerald-300">
                <Volume2 size={10} /> +{db}
              </span>
            )}
            {playing && <Play size={13} className="shrink-0 text-amber-300" />}
          </button>
        );
      })}
    </div>
  );
}

function ShowPage({ showKey, files, activeId, boostDb, onBack, onBoost, onPlay, onPlayShow, onRemove, onRemoveShow }) {
  const rootRef = useRef(null);
  const [season, setSeason] = useState("");
  const [shown, setShown] = useState(PAGE);
  const seasons = useMemo(() => [...new Set(files.map((m) => m.season).filter(Boolean))].sort(order.compare), [files]);
  const list = useMemo(() => (season ? files.filter((m) => m.season === season) : files), [files, season]);
  const totalTime = useMemo(() => files.reduce((t, m) => t + (m.duration || 0), 0), [files]);

  useBackHandler(() => {
    onBack();
    return true;
  });
  useEffect(() => {
    requestAnimationFrame(() => focusFirst(rootRef.current));
  }, [showKey]);
  useEffect(() => setShown(PAGE), [season]);

  return (
    <div ref={rootRef} className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <button onClick={onBack} className="flex min-h-10 shrink-0 items-center gap-1.5 rounded-full border border-white/15 px-3 text-sm text-neutral-200 focus:border-amber-400/70" aria-label="Back to shows">
          <ArrowLeft size={15} /> Shows
        </button>
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-sm font-medium text-neutral-100">{showTitle(showKey)}</h3>
          <p className="truncate font-mono text-[10px] text-neutral-500">
            {files.length} files{totalTime ? ` · ${formatClock(totalTime)}` : ""}
          </p>
        </div>
      </div>

      <button
        data-nav-default
        onClick={() => onPlayShow(list)}
        disabled={!list.length}
        className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-amber-400 px-3 text-sm font-medium text-neutral-950 transition hover:bg-amber-300 focus:ring-2 focus:ring-amber-200 disabled:opacity-40"
      >
        <Play size={15} /> Play {season || "from the start"}
      </button>

      {showKey !== LOOSE && (
        <SliderRow
          label="Audio boost"
          hint="For quiet shows. Remembered for every episode."
          value={boostDb}
          min={0}
          max={12}
          step={1}
          onChange={(v) => onBoost(showKey, v)}
          display={boostLabel(boostDb)}
        />
      )}

      {seasons.length > 1 && (
        <Cycler label="Season" value={season} options={[{ value: "", label: `All (${seasons.length})` }, ...seasons.map((s) => ({ value: s, label: s }))]} onChange={setSeason} />
      )}

      <SectionLabel>
        {season || "Episodes"} · {list.length}
      </SectionLabel>
      {list.slice(0, shown).map((m) => {
        const active = m.id === activeId;
        return (
          <div key={m.id} className="flex items-stretch gap-2" data-episode={m.id}>
            <button
              onClick={() => onPlay(m, list)}
              className={`flex min-w-0 flex-1 items-center gap-3 rounded-xl border px-3 py-2 text-left transition focus:border-amber-400 focus:bg-amber-400/10 ${
                active ? "border-amber-400/50 bg-amber-400/[0.07]" : "border-white/10 bg-white/[0.03] hover:border-white/25"
              }`}
            >
              {m.type?.startsWith("audio") ? <Music size={14} className="shrink-0 text-amber-300" /> : <Film size={14} className="shrink-0 text-amber-300" />}
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm text-neutral-200">{m.name}</span>
                <span className="block truncate font-mono text-[10px] text-neutral-500">
                  {[!season && m.season, m.duration ? formatClock(m.duration) : "Unreadable", formatSize(m.size)].filter(Boolean).join(" · ")}
                </span>
              </span>
              {active && <Play size={13} className="shrink-0 text-amber-300" />}
            </button>
            <ConfirmButton
              label={`Remove ${m.name}`}
              confirmLabel={`Press again to remove ${m.name}`}
              onConfirm={() => {
                const i = list.indexOf(m);
                const next = list[i + 1] || list[i - 1];
                onRemove(m);
                if (next) refocus(`[data-episode="${next.id}"] button`, "[data-nav-default]");
              }}
              className="flex w-12 shrink-0 items-center justify-center rounded-xl border border-white/10 text-neutral-500 transition hover:text-red-300 focus:border-red-400/60 focus:text-red-200"
            >
              {(armed) => (armed ? <span className="text-[10px] leading-tight">Again</span> : <Trash2 size={15} />)}
            </ConfirmButton>
          </div>
        );
      })}
      {list.length > shown && (
        <button onClick={() => setShown((n) => n + PAGE * 2)} className="min-h-10 rounded-xl border border-dashed border-white/15 font-mono text-[10px] uppercase tracking-wider text-neutral-400 focus:border-amber-400/70">
          Show more ({list.length - shown} left)
        </button>
      )}

      <ConfirmButton
        label={showKey === LOOSE ? "Remove these files from the library" : "Remove show from library"}
        confirmLabel="Press again to remove"
        onConfirm={() => onRemoveShow(files)}
        className="mt-3 flex min-h-11 items-center justify-center gap-2 rounded-xl border border-white/10 text-sm text-neutral-400 transition hover:text-red-300 focus:border-red-400/60 focus:text-red-200"
      >
        {(armed) => (
          <>
            <Trash2 size={14} /> {armed ? "Press again to remove" : showKey === LOOSE ? "Remove these files from the library" : "Remove show from library"}
          </>
        )}
      </ConfirmButton>
      <p className="px-1 text-center text-[10px] text-neutral-600">Linked files stay on your device. This only takes them out of the app.</p>
    </div>
  );
}

function LibraryTab({ media, activeId, playingShow, importing, boost, openShow, onOpenShow, onBoost, onPlay, onPlayList, onRemove, onRemoveMany, onAddFiles, onLink, onQuickPlay }) {
  const byShow = useMemo(() => {
    const map = new Map();
    for (const m of media) {
      const k = keyOf(m);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(m);
    }
    for (const list of map.values()) list.sort((a, b) => order.compare(a.season || "", b.season || "") || order.compare(a.name, b.name));
    return map;
  }, [media]);

  const groups = useMemo(
    () =>
      [...byShow.entries()]
        .map(([key, list]) => ({ key, count: list.length, seasons: new Set(list.map((m) => m.season).filter(Boolean)).size }))
        .sort((a, b) => (a.key === LOOSE) - (b.key === LOOSE) || order.compare(a.key, b.key)),
    [byShow]
  );

  const files = openShow ? byShow.get(openShow) : null;
  // The show was removed (or emptied): fall back to the list.
  useEffect(() => {
    if (openShow && !files) onOpenShow(null);
  }, [openShow, files, onOpenShow]);

  if (openShow && files) {
    return (
      <ShowPage
        showKey={openShow}
        files={files}
        activeId={activeId}
        boostDb={openShow === LOOSE ? 0 : boost[openShow] || 0}
        onBack={() => onOpenShow(null)}
        onBoost={onBoost}
        onPlay={onPlay}
        onPlayShow={onPlayList}
        onRemove={onRemove}
        onRemoveShow={onRemoveMany}
      />
    );
  }
  return (
    <ShowList
      groups={groups}
      total={media.length}
      playingShow={playingShow}
      boost={boost}
      importing={importing}
      onOpenShow={onOpenShow}
      onAddFiles={onAddFiles}
      onLink={onLink}
      onQuickPlay={onQuickPlay}
    />
  );
}

export default memo(LibraryTab);
