import React, { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ArrowUp, ArrowDown, X, RefreshCw, Tv, Megaphone } from "lucide-react";
import { formatClock } from "@/lib/schedule";
import { useBackHandler } from "@/components/tv/backStack";
import { focusEl, refocus } from "@/lib/spatialNav";

// Long lineups (every episode of several shows) are drawn a page at a time.
const PAGE = 60;

const iconBtn =
  "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-white/10 text-neutral-400 transition hover:text-white focus:border-amber-400/70 focus:text-amber-200 disabled:opacity-25";

// Full-screen list of a playlist channel's saved lineup. B or Done closes.
export default function LineupEditor({ lineup, media, onChange, onRebuild, onClose }) {
  const [shown, setShown] = useState(PAGE);
  const boxRef = useRef(null);
  const byId = useMemo(() => new Map(media.map((m) => [m.id, m])), [media]);
  const total = useMemo(() => lineup.reduce((n, e) => n + (byId.get(e.mediaId)?.duration || 0), 0), [lineup, byId]);

  useBackHandler(() => {
    onClose();
    return true;
  });
  useEffect(() => {
    focusEl(boxRef.current?.querySelector("[data-nav-default]"));
  }, []);

  const move = (i, dir) => {
    const j = i + dir;
    if (j < 0 || j >= lineup.length) return;
    const next = [...lineup];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
    refocus(`[data-lineup-row="${j}"] [data-act="${dir < 0 ? "up" : "down"}"]`);
  };
  const remove = (i) => {
    onChange(lineup.filter((_, k) => k !== i));
    const at = Math.min(i, lineup.length - 2);
    refocus(`[data-lineup-row="${at}"] [data-act="remove"]`, "[data-nav-default]");
  };

  return createPortal(
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/75 p-3 backdrop-blur-sm" onClick={onClose}>
      <div
        ref={boxRef}
        data-nav-modal
        role="dialog"
        aria-label="Lineup"
        onClick={(e) => e.stopPropagation()}
        className="flex max-h-[92vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl border border-white/10 bg-neutral-950 shadow-2xl"
      >
        <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
          <div className="min-w-0 flex-1">
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-neutral-300">Lineup · {lineup.length} items</p>
            <p className="text-[11px] text-neutral-500">Loops every {formatClock(total)}. Stays exactly as you set it.</p>
          </div>
          <button
            onClick={onRebuild}
            className="flex min-h-9 items-center gap-1.5 rounded-full border border-white/15 px-3 font-mono text-[10px] uppercase tracking-wider text-neutral-300 transition hover:border-amber-400/60 focus:border-amber-400/70"
          >
            <RefreshCw size={12} /> Rebuild
          </button>
          <button
            data-nav-default
            onClick={onClose}
            className="min-h-9 rounded-full bg-amber-400 px-3 font-mono text-[10px] uppercase tracking-wider text-neutral-950"
          >
            Done
          </button>
        </div>
        <ul className="flex flex-col gap-1 overflow-y-auto p-2">
          {lineup.slice(0, shown).map((e, i) => {
            const m = byId.get(e.mediaId);
            return (
              <li key={`${e.mediaId}-${i}`} data-lineup-row={i} className={`flex items-center gap-1.5 rounded-xl border px-2 py-1.5 ${m ? "border-white/5" : "border-red-500/40 bg-red-500/5"}`}>
                <span className="w-8 shrink-0 text-right font-mono text-[10px] text-neutral-600">{i + 1}</span>
                {e.kind === "ad" ? <Megaphone size={13} className="shrink-0 text-sky-300" /> : <Tv size={13} className="shrink-0 text-amber-300" />}
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-xs text-neutral-200">{m ? m.name : "Missing file (skipped)"}</span>
                  {m && (
                    <span className="block truncate font-mono text-[10px] text-neutral-600">
                      {[m.show, m.season].filter(Boolean).join(" / ")} · {formatClock(m.duration)}
                    </span>
                  )}
                </span>
                <button data-act="up" onClick={() => move(i, -1)} disabled={i === 0} className={iconBtn} aria-label="Move up">
                  <ArrowUp size={14} />
                </button>
                <button data-act="down" onClick={() => move(i, 1)} disabled={i === lineup.length - 1} className={iconBtn} aria-label="Move down">
                  <ArrowDown size={14} />
                </button>
                <button data-act="remove" onClick={() => remove(i)} className={`${iconBtn} hover:text-red-300 focus:text-red-300`} aria-label="Remove from lineup">
                  <X size={14} />
                </button>
              </li>
            );
          })}
          {lineup.length > shown && (
            <li>
              <button
                onClick={() => setShown((n) => n + PAGE * 2)}
                className="min-h-10 w-full rounded-xl border border-dashed border-white/15 px-2 py-1.5 font-mono text-[10px] uppercase tracking-wider text-neutral-400 hover:border-amber-400/60 focus:border-amber-400/70"
              >
                Show more ({lineup.length - shown} left)
              </button>
            </li>
          )}
        </ul>
      </div>
    </div>,
    document.body
  );
}
