import React, { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Check, Trash2, ListOrdered } from "lucide-react";
import LineupEditor from "@/components/LineupEditor";
import BlockEditor from "@/components/BlockEditor";
import { MultiPicker } from "@/components/tv/Picker";
import { Cycler, NavRow, Stepper, SectionLabel, ConfirmButton, TextRow } from "@/components/tv/controls";
import { useBackHandler } from "@/components/tv/backStack";
import { generateLineup, formatClock, showEpisodes } from "@/lib/schedule";
import { focusFirst } from "@/lib/spatialNav";

const PLAYLIST_EPOCH = new Date("2000-01-01T00:00:00Z").getTime();
const isRecent = (epoch) => epoch > Date.UTC(2001, 0, 1);

// Block channels walk their schedule forward from the epoch (cycle lengths vary
// with the random picks), so they start today. Playlists keep the fixed 2000 epoch.
function pickEpoch(initial, isBlocks) {
  if (isBlocks) return isRecent(initial?.epoch) ? initial.epoch : new Date().setHours(0, 0, 0, 0);
  return isRecent(initial?.epoch) ? PLAYLIST_EPOCH : initial?.epoch || PLAYLIST_EPOCH;
}

const listLabel = (list, none) => (list.length === 0 ? none : list.length === 1 ? list[0] : `${list.length} picked`);

const MODES = [
  { value: "playlist", label: "Playlist" },
  { value: "blocks", label: "Blocks" },
];
const ORDERS = [
  { value: false, label: "In order" },
  { value: true, label: "Shuffle" },
];

export default function ChannelEditor({ initial, shows, media, nextNumber, onSave, onCancel, onDelete }) {
  const rootRef = useRef(null);
  const [name, setName] = useState(initial?.name || "");
  const [number, setNumber] = useState(initial?.number ?? nextNumber);
  const [chShows, setChShows] = useState(initial?.shows || []);
  const [adShows, setAdShows] = useState(initial?.adShows || []);
  const [adsPerBreak, setAdsPerBreak] = useState(initial?.adsPerBreak ?? 2);
  const [lineup, setLineup] = useState(initial?.lineup || null);
  const [shuffle, setShuffle] = useState(initial?.shuffle ?? false);
  const [mode, setMode] = useState(initial?.blocks?.length ? "blocks" : "playlist");
  const [blocks, setBlocks] = useState(initial?.blocks || []);
  const [picking, setPicking] = useState(null); // "shows" | "ads" | null
  const [lineupOpen, setLineupOpen] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [leaveArmed, setLeaveArmed] = useState(false);
  const isBlocks = mode === "blocks";
  const canSave = isBlocks ? blocks.length > 0 : chShows.length > 0;

  const showOptions = useMemo(
    () => shows.map((s) => ({ value: s, label: s, hint: `${showEpisodes(media, s).length} episodes` })),
    [shows, media]
  );

  // Every edit marks the form dirty; changing what the playlist draws from
  // drops the saved lineup so it's rebuilt to include the new picks.
  const edit = (setter, { resetLineup = false } = {}) => (v) => {
    setter(v);
    setDirty(true);
    if (resetLineup) setLineup(null);
  };

  useEffect(() => {
    requestAnimationFrame(() => focusFirst(rootRef.current));
  }, []);

  useEffect(() => {
    if (!leaveArmed) return undefined;
    const t = setTimeout(() => setLeaveArmed(false), 3000);
    return () => clearTimeout(t);
  }, [leaveArmed]);

  // B: leave the editor. With unsaved changes, the first press only warns.
  useBackHandler(() => {
    if (dirty && !leaveArmed) {
      setLeaveArmed(true);
      return true;
    }
    onCancel();
    return true;
  });

  const draft = () => ({ shows: chShows, adShows, adsPerBreak: Number(adsPerBreak), shuffle });
  const openLineup = () => {
    if (!lineup) setLineup(generateLineup(draft(), media));
    setLineupOpen(true);
  };

  const save = () => {
    if (!canSave) return;
    const n = Number(number) || nextNumber;
    onSave({
      ...initial,
      name: name.trim() || `Channel ${n}`,
      number: n,
      shows: chShows,
      adShows,
      adsPerBreak: Number(adsPerBreak),
      shuffle,
      // Block channels pick episodes per pass; playlists freeze their lineup on save.
      blocks: isBlocks ? blocks : [],
      lineup: isBlocks ? null : lineup || generateLineup(draft(), media),
      epoch: pickEpoch(initial, isBlocks),
    });
  };

  const lineupTotal = useMemo(() => {
    if (!lineup) return 0;
    const byId = new Map(media.map((m) => [m.id, m]));
    return lineup.reduce((t, e) => t + (byId.get(e.mediaId)?.duration || 0), 0);
  }, [lineup, media]);

  return (
    <div ref={rootRef} className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <button onClick={onCancel} className="flex min-h-10 items-center gap-1.5 rounded-full border border-white/15 px-3 text-sm text-neutral-200 focus:border-amber-400/70" aria-label="Back to channels">
          <ArrowLeft size={15} /> Back
        </button>
        <h3 className="min-w-0 flex-1 truncate text-center font-mono text-[11px] uppercase tracking-[0.2em] text-neutral-300">
          {initial ? "Edit channel" : "New channel"}
        </h3>
        <button
          onClick={save}
          disabled={!canSave}
          className="flex min-h-10 items-center gap-1.5 rounded-full bg-amber-400 px-4 font-mono text-[11px] uppercase tracking-wider text-neutral-950 transition hover:bg-amber-300 disabled:opacity-40"
        >
          <Check size={14} /> Save
        </button>
      </div>
      {leaveArmed && (
        <p role="status" className="rounded-lg bg-amber-400/10 px-3 py-2 text-xs text-amber-200">
          Unsaved changes. Press Back again to discard them, or Save.
        </p>
      )}
      {!canSave && (
        <p className="px-1 text-[11px] text-neutral-500">{isBlocks ? "Add at least one block to save." : "Pick at least one show to save."}</p>
      )}

      <TextRow label="Name" value={name} placeholder={`Channel ${number}`} onChange={edit(setName)} navDefault />
      <Stepper label="Channel number" value={Number(number) || 1} min={1} max={999} onChange={edit(setNumber)} format={(v) => String(v).padStart(2, "0")} />
      <Cycler
        label="Type"
        hint={isBlocks ? "Set order of shows, random episodes" : "Fixed episode list that loops"}
        value={mode}
        options={MODES}
        onChange={edit(setMode)}
      />

      {isBlocks ? (
        <BlockEditor blocks={blocks} shows={shows} media={media} onChange={edit(setBlocks)} />
      ) : (
        <>
          <SectionLabel>What's on</SectionLabel>
          <NavRow label="Shows" hint="Episodes rotate between the shows you pick" value={listLabel(chShows, "None")} onClick={() => setPicking("shows")} navKey="pick-shows" />
          <Cycler label="Episode order" hint={shuffle ? "Random across all seasons" : "Season by season"} value={shuffle} options={ORDERS} onChange={edit(setShuffle, { resetLineup: true })} />
          <NavRow label="Ad breaks" hint="Folders of ads to play between episodes" value={listLabel(adShows, "Off")} onClick={() => setPicking("ads")} navKey="pick-ads" />
          {adShows.length > 0 && (
            <Stepper label="Ads per break" value={Number(adsPerBreak) || 1} min={1} max={10} onChange={edit(setAdsPerBreak, { resetLineup: true })} />
          )}
          {chShows.length > 0 && (
            <NavRow
              label="Lineup"
              icon={<ListOrdered size={16} className="text-neutral-400" />}
              hint={lineup ? `Loops every ${formatClock(lineupTotal)}` : "Built from your picks when you save"}
              value={lineup ? `${lineup.length} items` : "Preview"}
              onClick={openLineup}
              navKey="lineup"
            />
          )}
        </>
      )}

      {initial && onDelete && (
        <ConfirmButton
          label="Delete channel"
          confirmLabel="Press again to delete"
          onConfirm={() => onDelete(initial)}
          className="mt-3 flex min-h-11 items-center justify-center gap-2 rounded-xl border border-white/10 text-sm text-neutral-400 transition hover:text-red-300 focus:border-red-400/60 focus:text-red-200"
        >
          {(armed) => (
            <>
              <Trash2 size={14} /> {armed ? "Press again to delete" : "Delete channel"}
            </>
          )}
        </ConfirmButton>
      )}

      {picking && (
        <MultiPicker
          title={picking === "shows" ? "Shows" : "Ad folders"}
          hint={picking === "shows" ? "Episodes play in order, rotating between these." : "Mixed in between episodes."}
          options={showOptions}
          values={picking === "shows" ? chShows : adShows}
          onChange={edit(picking === "shows" ? setChShows : setAdShows, { resetLineup: true })}
          onClose={() => {
            const key = picking === "shows" ? "pick-shows" : "pick-ads";
            setPicking(null);
            requestAnimationFrame(() => rootRef.current?.querySelector(`[data-nav-key="${key}"]`)?.focus());
          }}
        />
      )}
      {lineupOpen && lineup && (
        <LineupEditor
          lineup={lineup}
          media={media}
          onChange={edit(setLineup)}
          onRebuild={() => {
            setLineup(generateLineup(draft(), media));
            setDirty(true);
          }}
          onClose={() => {
            setLineupOpen(false);
            requestAnimationFrame(() => rootRef.current?.querySelector('[data-nav-key="lineup"]')?.focus());
          }}
        />
      )}
    </div>
  );
}
