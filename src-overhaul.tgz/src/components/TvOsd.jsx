import React from "react";
import { VolumeX, Volume2 } from "lucide-react";
import { formatClock } from "@/lib/schedule";

// Old-TV on-screen display, drawn over the picture: channel number in the top
// corner, volume bar, MUTE, and an info banner with what's on.

const GLOW = {
  color: "#9dffab",
  textShadow:
    "0 0 4px rgba(140,255,160,0.9), 0 0 14px rgba(110,255,140,0.45), 2px 2px 0 rgba(0,0,0,0.75)",
};
const font = "font-['VT323',ui-monospace,monospace]";
const pad2 = (n) => String(n ?? "").padStart(2, "0");

export function ChannelBug({ channel, compact = false }) {
  if (!channel) return null;
  return (
    <div
      className={`${font} pointer-events-none absolute right-[4%] top-[5%] z-20 max-w-[60%] text-right uppercase leading-none`}
      style={GLOW}
      data-testid="osd-channel"
    >
      <div className={`${compact ? "text-[clamp(2rem,7vmin,3.5rem)]" : "text-[clamp(2.6rem,11vmin,6rem)]"} tracking-wider`}>CH {pad2(channel.number)}</div>
      <div className={`mt-1 truncate ${compact ? "text-[clamp(0.9rem,3vmin,1.4rem)]" : "text-[clamp(1.1rem,4.2vmin,2.2rem)]"} tracking-wide`}>{channel.name}</div>
    </div>
  );
}

const SEGMENTS = 20;

export function VolumeBar({ volume, muted }) {
  const lit = muted ? 0 : Math.round(volume * SEGMENTS);
  return (
    <div
      className={`${font} pointer-events-none absolute inset-x-0 bottom-[9%] z-20 flex justify-center`}
      data-testid="osd-volume"
    >
      <div className="flex items-center gap-[0.6em] rounded bg-black/35 px-[0.6em] py-[0.2em] text-[clamp(1.2rem,5vmin,2.6rem)] uppercase leading-none" style={GLOW}>
        <span>{muted ? "Mute" : "Volume"}</span>
        <span className="flex h-[0.7em] items-stretch gap-[0.12em]" aria-hidden>
          {Array.from({ length: SEGMENTS }, (_, i) => (
            <span
              key={i}
              className="w-[0.32em]"
              style={{ background: i < lit ? GLOW.color : "rgba(157,255,171,0.16)", boxShadow: i < lit ? "0 0 6px rgba(140,255,160,0.6)" : "none" }}
            />
          ))}
        </span>
        <span className="w-[1.6em] text-right tabular-nums">{muted ? "--" : Math.round(volume * 100)}</span>
      </div>
    </div>
  );
}

export function MuteTag() {
  return (
    <div className={`${font} pointer-events-none absolute left-[4%] top-[5%] z-20 flex items-center gap-2 text-[clamp(1.2rem,5vmin,2.4rem)] uppercase leading-none`} style={GLOW}>
      <VolumeX className="h-[1em] w-[1em]" strokeWidth={2.5} /> Mute
    </div>
  );
}

// Lower-third banner: channel, what's on, progress, what's next.
export function InfoBanner({ channel, nowPlaying, label, boostDb, hints }) {
  const cur = nowPlaying?.current;
  const m = cur?.media;
  const pct = cur?.duration ? Math.min(100, (nowPlaying.offset / cur.duration) * 100) : 0;
  const next = nowPlaying?.upcoming?.[0]?.media;
  const sub = m ? [m.show, m.season].filter(Boolean).join(" · ") : "";
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-black/90 via-black/70 to-transparent px-[4%] pb-[3%] pt-[8%]" data-testid="osd-info">
      <div className="flex items-end gap-4">
        {channel && (
          <div className={`${font} shrink-0 text-[clamp(2rem,9vmin,4.5rem)] leading-none`} style={GLOW}>
            {pad2(channel.number)}
          </div>
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate font-mono text-[11px] uppercase tracking-[0.2em] text-amber-300/90">
            {channel ? channel.name : "Now playing"}
            {cur?.kind === "ad" && <span className="ml-2 text-sky-300">· Ad break</span>}
            {boostDb > 0 && (
              <span className="ml-2 inline-flex items-center gap-1 text-emerald-300">
                <Volume2 size={11} /> +{boostDb} dB
              </span>
            )}
          </p>
          <p className="truncate text-[clamp(0.95rem,3.6vmin,1.4rem)] font-medium text-white">{m ? m.name : label}</p>
          {sub && <p className="truncate text-xs text-neutral-400">{sub}</p>}
          {cur && (
            <div className="mt-2 flex items-center gap-3">
              <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/15">
                <div className="h-full rounded-full bg-amber-400" style={{ width: `${pct}%` }} />
              </div>
              <span className="shrink-0 font-mono text-[11px] tabular-nums text-neutral-300">{formatClock(nowPlaying.remaining)} left</span>
            </div>
          )}
          {next && <p className="mt-1 truncate font-mono text-[11px] text-neutral-400">Next: {next.name}</p>}
        </div>
      </div>
      {hints && (
        <p className="mt-2 flex flex-wrap gap-x-4 gap-y-1 font-mono text-[10px] uppercase tracking-wider text-neutral-400">
          {hints.map(([k, v]) => (
            <span key={k}>
              <span className="mr-1 rounded border border-white/25 px-1 py-px text-neutral-200">{k}</span>
              {v}
            </span>
          ))}
        </p>
      )}
    </div>
  );
}

// Centre message: "No signal", load problems.
export function ScreenMessage({ children, icon }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center px-6 text-center">
      <span className={`${font} flex flex-col items-center gap-1 rounded bg-black/55 px-3 py-1 text-[clamp(1.2rem,5vmin,2.2rem)] uppercase leading-tight`} style={GLOW}>
        {icon}
        <span>{children}</span>
      </span>
    </div>
  );
}
