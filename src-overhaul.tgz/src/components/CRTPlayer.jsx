import React, { useEffect, useRef } from "react";
import * as THREE from "three";

const vertexShader = `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`;

const fragmentShader = `
precision highp float;
uniform sampler2D uTexture;
uniform float uTime;
uniform vec2 uResolution;
uniform float uCurvature;
uniform float uScanlineIntensity;
uniform float uScanlineDensity;
uniform float uVignette;
uniform float uAberration;
uniform float uBrightness;
uniform float uContrast;
uniform float uSaturation;
uniform float uGlow;
uniform float uNoise;
uniform float uMaskIntensity;
uniform float uHasFrame;
uniform float uPixelRatio;
uniform float uVideoAspect;
uniform float uStatic;
varying vec2 vUv;

vec2 curveScreen(vec2 uv) {
  uv = uv * 2.0 - 1.0;
  // 0.3 keeps the default "Retro" bulge to about a tenth at the corners;
  // the slider goes up to 3 for a strong fishbowl.
  vec2 off = uv.yx * uCurvature * 0.3;
  uv += uv * off * off;
  uv = uv * 0.5 + 0.5;
  return uv;
}

float rand(vec2 st) {
  return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
}

void main() {
  vec2 uv = curveScreen(vUv);

  // letterbox the video inside the screen, keeping its aspect ratio
  float screenAspect = uResolution.x / uResolution.y;
  vec2 vuv = uv - 0.5;
  if (screenAspect > uVideoAspect) vuv.x *= screenAspect / uVideoAspect;
  else vuv.y *= uVideoAspect / screenAspect;
  vuv += 0.5;

  vec3 col = vec3(0.0);
  if (uHasFrame > 0.5 && vuv.x >= 0.0 && vuv.x <= 1.0 && vuv.y >= 0.0 && vuv.y <= 1.0
      && uv.x >= 0.0 && uv.x <= 1.0 && uv.y >= 0.0 && uv.y <= 1.0) {
    float aberr = uAberration * 0.008;
    float r = texture2D(uTexture, vec2(vuv.x + aberr, vuv.y)).r;
    float g = texture2D(uTexture, vec2(vuv.x, vuv.y)).g;
    float b = texture2D(uTexture, vec2(vuv.x - aberr, vuv.y)).b;
    col = vec3(r, g, b);

    col = (col - 0.5) * uContrast + 0.5;
    col *= uBrightness;

    float gray = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(gray), col, uSaturation);
  }

  // Between channels: snow, tearing lines and a slow rolling band, like an
  // old set that has lost its signal. Frame counter is wrapped to keep the
  // hash precise on phone GPUs.
  if (uStatic > 0.001 && uv.x >= 0.0 && uv.x <= 1.0 && uv.y >= 0.0 && uv.y <= 1.0) {
    float t = mod(floor(uTime * 30.0), 997.0);
    vec2 cell = floor(uv * vec2(320.0, 240.0));
    float n = rand(cell * 0.731 + vec2(t * 1.37, t * 0.91));
    float tear = rand(vec2(floor(uv.y * 240.0) * 0.37, t * 0.53));
    n = mix(n, tear, 0.22);
    float band = abs(fract(uv.y * 0.85 - uTime * 0.35) - 0.5);
    float roll = 0.72 + 0.28 * smoothstep(0.02, 0.12, band);
    vec3 snow = vec3(n * n * 1.1 + 0.04) * roll;
    col = mix(col, snow, uStatic);
  }

  // scanlines: uScanlineDensity = number of lines across the screen height.
  // Clamp so lines are never thinner than ~3 device pixels (avoids moire).
  float lines = min(uScanlineDensity, uResolution.y / 3.0);
  float phase = fract(uv.y * lines);
  float scanline = smoothstep(0.0, 0.5, phase) * (1.0 - smoothstep(0.5, 1.0, phase));
  scanline = pow(clamp(scanline * 2.0, 0.0, 1.0), 0.8);
  col *= 1.0 - uScanlineIntensity * (1.0 - scanline);

  // RGB phosphor mask: triads sized to ~3 CSS pixels regardless of DPI
  float px = floor(vUv.x * uResolution.x / 3.0 * 3.0 / max(uPixelRatio, 1.0));
  float triad = mod(px, 3.0);
  vec3 mask;
  if (triad < 1.0) mask = vec3(1.0, 0.82, 0.82);
  else if (triad < 2.0) mask = vec3(0.82, 1.0, 0.82);
  else mask = vec3(0.82, 0.82, 1.0);
  col *= mix(vec3(1.0), mask, uMaskIntensity);

  // vignette
  vec2 vc = vUv - 0.5;
  float vig = 1.0 - dot(vc, vc) * uVignette * 2.6;
  vig = clamp(vig, 0.0, 1.0);
  col *= vig;

  // bloom-ish glow
  col += col * uGlow * 0.18;

  // animated noise / static
  col += (rand(vUv + uTime * 0.01) - 0.5) * uNoise;

  // faint CRT tint
  col *= vec3(0.97, 1.0, 1.03);

  gl_FragColor = vec4(col, 1.0);
}
`;

// staticLevel: 0 = picture, 1 = full static (channel change), in between = faint snow.
export default function CRTPlayer({ videoRef, settings, hasFrame, staticLevel = 0 }) {
  const containerRef = useRef(null);
  const materialRef = useRef(null);
  const rendererRef = useRef(null);
  const textureRef = useRef(null);
  const staticTargetRef = useRef(staticLevel);
  staticTargetRef.current = staticLevel;

  useEffect(() => {
    const container = containerRef.current;
    const video = videoRef.current;
    if (!container || !video) return;

    const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    renderer.domElement.style.display = "block";
    rendererRef.current = renderer;

    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 10);
    camera.position.z = 1;

    const texture = new THREE.VideoTexture(video);
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.colorSpace = THREE.SRGBColorSpace;
    textureRef.current = texture;

    const material = new THREE.ShaderMaterial({
      uniforms: {
        uTexture: { value: texture },
        uTime: { value: 0 },
        uResolution: { value: new THREE.Vector2(1, 1) },
        uCurvature: { value: settings.curvature },
        uScanlineIntensity: { value: settings.scanlineIntensity },
        uScanlineDensity: { value: settings.scanlineDensity },
        uVignette: { value: settings.vignette },
        uAberration: { value: settings.aberration },
        uBrightness: { value: settings.brightness },
        uContrast: { value: settings.contrast },
        uSaturation: { value: settings.saturation },
        uGlow: { value: settings.glow },
        uNoise: { value: settings.noise },
        uMaskIntensity: { value: settings.maskIntensity },
        uHasFrame: { value: hasFrame ? 1 : 0 },
        uPixelRatio: { value: renderer.getPixelRatio() },
        uVideoAspect: { value: 16 / 9 },
        uStatic: { value: staticLevel },
      },
      vertexShader,
      fragmentShader,
    });
    materialRef.current = material;

    const geometry = new THREE.PlaneGeometry(2, 2);
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    const resize = () => {
      const w = container.clientWidth || 1;
      const h = container.clientHeight || 1;
      renderer.setSize(w, h, false);
      material.uniforms.uResolution.value.set(w, h);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(container);

    const clock = new THREE.Clock();
    let raf;
    let lastDraw = 0;
    let lastTick = 0;
    let level = staticLevel;
    const animate = (now = 0) => {
      raf = requestAnimationFrame(animate);
      // Static snaps on at once and fades out over a quarter second.
      const dt = lastTick ? Math.min(0.1, (now - lastTick) / 1000) : 0;
      lastTick = now;
      const target = staticTargetRef.current;
      level = target >= level ? target : Math.max(target, level - dt / 0.25);
      // Moving picture or full static: draw every frame. Paused or nothing loaded:
      // ~15 fps is plenty, and frees the GPU so menus stay smooth on phones.
      const moving = (!video.paused && !video.ended && video.readyState >= 2) || level > 0.5 || level !== target;
      if (!moving && now - lastDraw < 66) return;
      lastDraw = now;
      material.uniforms.uStatic.value = level;
      material.uniforms.uTime.value = clock.getElapsedTime();
      if (video.videoWidth && video.videoHeight) {
        material.uniforms.uVideoAspect.value = video.videoWidth / video.videoHeight;
      }
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      geometry.dispose();
      material.dispose();
      texture.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const m = materialRef.current;
    if (!m) return;
    const u = m.uniforms;
    u.uCurvature.value = settings.curvature;
    u.uScanlineIntensity.value = settings.scanlineIntensity;
    u.uScanlineDensity.value = settings.scanlineDensity;
    u.uVignette.value = settings.vignette;
    u.uAberration.value = settings.aberration;
    u.uBrightness.value = settings.brightness;
    u.uContrast.value = settings.contrast;
    u.uSaturation.value = settings.saturation;
    u.uGlow.value = settings.glow;
    u.uNoise.value = settings.noise;
    u.uMaskIntensity.value = settings.maskIntensity;
  }, [settings]);

  useEffect(() => {
    const m = materialRef.current;
    if (m) m.uniforms.uHasFrame.value = hasFrame ? 1 : 0;
  }, [hasFrame]);

  return <div ref={containerRef} className="absolute inset-0 h-full w-full" />;
}