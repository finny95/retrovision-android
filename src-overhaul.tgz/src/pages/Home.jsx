import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Monitor, WifiOff, Menu as MenuIcon, ChevronUp, ChevronDown, Volume1, Volume2, VolumeX, Play, Pause } from "lucide-react";
import CRTPlayer from "@/components/CRTPlayer";
import PlayerControls from "@/components/PlayerControls";
import MenuPanel, { TABS } from "@/components/menu/MenuPanel";
import ChannelsTab from "@/components/menu/ChannelsTab";
import LibraryTab, { LOOSE } from "@/components/menu/LibraryTab";
import PictureTab from "@/components/menu/PictureTab";
import SoundTab from "@/components/menu/SoundTab";
import { ChannelBug, VolumeBar, MuteTag, InfoBanner, ScreenMessage } from "@/components/TvOsd";
import InstallButton from "@/components/InstallButton";
import { Key } from "@/components/tv/controls";
import useChannelPlayback from "@/hooks/useChannelPlayback";
import useControls from "@/hooks/useControls";
import useLandscape from "@/hooks/useLandscape";
import useMedia from "@/hooks/useMedia";
import useAutoFullscreen from "@/hooks/useAutoFullscreen";
import useStableCallback from "@/hooks/useStableCallback";
import { BackStackContext, createBackStack } from "@/components/tv/backStack";
import { usePrefs, boostFor } from "@/lib/prefs";
import { unlockAudio, routePlayer, setBoostDb, startStatic, stopStatic } from "@/lib/audioEngine";
import { activeScope, adjust, focusEl, focusFirst, getFocusables, isAdjustable, moveFocus } from "@/lib/spatialNav";
import { pickLinkedFolder, describeHandle, getPlayable } from "@/lib/linkedFolder";
import { listShows, generateLineup, formatClock } from "@/lib/schedule";
import {
  addMedia, addLinkedMediaBatch, listMedia, removeMedia, parsePath,
  listChannels, saveChannel, removeChannel,
} from "@/lib/mediaDb";

// Shows something for `ms`, then hides it. Re-flashing restarts the timer.
function useFlash() {
  const [on, setOn] = useState(false);
  const timer = useRef(null);
  const flash = useCallback((ms) => {
    setOn(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setOn(false), ms);
  }, []);
  const hide = useCallback(() => {
    clearTimeout(timer.current);
    setOn(false);
  }, []);
  useEffect(() => () => clearTimeout(timer.current), []);
  return [on, flash, hide];
}

// Run after React has drawn the latest state.
const afterRender = (fn) => requestAnimationFrame(() => requestAnimationFrame(fn));
const clamp01 = (v) => Math.min(1, Math.max(0, Math.round(v * 100) / 100));
const pad2 = (n) => String(n).padStart(2, "0");
const isTab = (el) => el?.getAttribute?.("role") === "tab";

const WATCH_HINTS = [
  ["▲▼", "Channel"],
  ["◀▶", "Volume"],
  ["A", "Pause"],
  ["X", "Mute"],
  ["Start", "Menu"],
];
// TV remote / keyboard without a controller.
const REMOTE_HINTS = [
  ["▲▼", "Channel"],
  ["◀▶", "Volume"],
  ["OK", "Menu"],
  ["Back", "Close"],
];

export default function Home() {
  const videoRef = useRef(null);
  const stageRef = useRef(null);
  const objectUrlRef = useRef(null);
  const queueRef = useRef(null); // { list, index } while playing through a show
  const lastFocusRef = useRef(null);
  const lastBackRef = useRef(0);
  const switchRef = useRef({ at: 0, seq: 0 });
  const srcSeqRef = useRef(0);
  const backStack = useMemo(createBackStack, []);

  const [prefs, update] = usePrefs();
  const [src, setSrc] = useState("");
  const [srcSeq, setSrcSeq] = useState(0);
  const [label, setLabel] = useState("Nothing loaded");
  const [activeId, setActiveId] = useState(null);
  const [currentRec, setCurrentRec] = useState(null);
  const [isAudio, setIsAudio] = useState(false);
  const [library, setLibrary] = useState([]);
  const [hasFrame, setHasFrame] = useState(false);
  const [loadProblem, setLoadProblem] = useState(null);
  const [online, setOnline] = useState(navigator.onLine);
  const [importing, setImporting] = useState(null);
  const [channels, setChannels] = useState([]);
  const [channel, setChannel] = useState(null);
  const [editing, setEditing] = useState(null); // null | "new" | channel
  const [tab, setTab] = useState(TABS.some((t) => t.id === prefs.lastTab) ? prefs.lastTab : "channels");
  const [libShow, setLibShow] = useState(null);
  const [navMode, setNavMode] = useState("watch"); // where controller / keys go
  const [menuOpen, setMenuOpen] = useState(false); // TV layout overlay
  const [switching, setSwitching] = useState(false);
  const [bugOn, flashBug, hideBug] = useFlash();
  const [volOn, flashVol, hideVol] = useFlash();
  const [infoOn, flashInfo, hideInfo] = useFlash();
  const [touchOn, flashTouch, hideTouch] = useFlash();

  const tv = useLandscape(); // phone/handheld sideways or a TV: full-screen picture, menu slides over
  const wide = useMedia("(min-width: 1024px)");
  const variant = tv ? "overlay" : wide ? "column" : "inline";
  useAutoFullscreen(tv);

  const shows = listShows(library);
  const currentShow = currentRec?.show || null;
  const boostDb = boostFor(prefs, currentShow);

  // --- Library + channels -----------------------------------------------------
  useEffect(() => {
    Promise.all([listMedia(), listChannels()]).then(async ([m, list]) => {
      setLibrary(m);
      // Freeze channels saved before lineups existed so they stop reshuffling.
      const frozen = await Promise.all(
        list.map((c) => (c.lineup || c.blocks?.length ? c : saveChannel({ ...c, lineup: generateLineup(c, m) })))
      );
      setChannels(frozen.sort((a, b) => a.number - b.number));
    });
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, []);

  // --- Playback ---------------------------------------------------------------
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return undefined;
    setHasFrame(false);
    setLoadProblem(null);
    if (!src) {
      v.removeAttribute("src");
      v.load();
      return undefined;
    }
    const onLoaded = () => {
      setHasFrame(true);
      setLoadProblem(null);
    };
    // Say what went wrong instead of sitting on "Loading signal" forever.
    const onError = () =>
      setLoadProblem(v.error?.code === 4 ? "Can't play this file: its format isn't supported" : "Couldn't read this file. Try relinking the folder");
    const slow = setTimeout(() => {
      if (v.readyState < 2 && !v.error) setLoadProblem("Still tuning in… this file is slow to open");
    }, 15000);
    v.addEventListener("loadeddata", onLoaded);
    v.addEventListener("error", onError);
    v.load();
    v.play().catch(() => {});
    return () => {
      clearTimeout(slow);
      v.removeEventListener("loadeddata", onLoaded);
      v.removeEventListener("error", onError);
    };
  }, [src]);

  const bumpSrc = () => {
    srcSeqRef.current += 1;
    setSrcSeq(srcSeqRef.current);
  };

  const playBlob = useCallback(async (source, name, id, type) => {
    // `source` is a File/Blob or a library record (copied blob, linked file handle,
    // or in the Android app a linked file that resolves to a streaming URL).
    const playable = source instanceof Blob ? source : await getPlayable(source);
    if (!playable) {
      setLabel(`${name} (can't open: allow access or relink the folder)`);
      bumpSrc();
      return;
    }
    if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    const isUrl = typeof playable === "string";
    const url = isUrl ? playable : URL.createObjectURL(playable);
    objectUrlRef.current = isUrl ? null : url;
    setIsAudio(Boolean(type?.startsWith("audio")));
    setCurrentRec(source instanceof Blob ? null : source);
    setSrc(url);
    setLabel(name);
    setActiveId(id);
    bumpSrc();
  }, []);

  const clearPicture = useCallback((text = "Nothing loaded") => {
    if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    objectUrlRef.current = null;
    setSrc("");
    setLabel(text);
    setActiveId(null);
    setCurrentRec(null);
    bumpSrc();
  }, []);

  const onChannelEmpty = useStableCallback(() => clearPicture("No episodes on this channel"));
  const nowPlaying = useChannelPlayback({ videoRef, channel, media: library, playBlob, onEmpty: onChannelEmpty });

  // Files from the library play on through the show; a quick-play file repeats.
  useEffect(() => {
    const v = videoRef.current;
    if (!v || channel) return undefined;
    const onEnded = () => {
      const q = queueRef.current;
      const next = q?.list[q.index + 1];
      if (q && next) {
        queueRef.current = { list: q.list, index: q.index + 1 };
        playBlob(next, next.name, next.id, next.type);
      } else if (!q) {
        v.currentTime = 0;
        v.play().catch(() => {});
      }
    };
    v.addEventListener("ended", onEnded);
    return () => v.removeEventListener("ended", onEnded);
  }, [channel, playBlob]);

  // --- Sound: app volume, per-show boost, static hiss ---------------------------
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.volume = prefs.volume;
    v.muted = prefs.muted;
    if (prefs.muted) stopStatic();
  }, [prefs.volume, prefs.muted]);

  const boostRef = useRef(boostDb);
  boostRef.current = boostDb;
  useEffect(() => {
    setBoostDb(boostDb);
    // Only route through the boost chain once a show actually needs it.
    if (boostDb > 0) routePlayer(videoRef.current);
  }, [boostDb]);

  useEffect(() => {
    const unlock = () =>
      unlockAudio().then((ok) => {
        if (ok && boostRef.current > 0) routePlayer(videoRef.current);
      });
    unlock();
    const onVisible = () => document.visibilityState === "visible" && unlock();
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("keydown", unlock);
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);

  const changeVolume = (delta) => {
    update((p) => ({ volume: clamp01(p.volume + delta), muted: false }));
    flashVol(2200);
  };
  const toggleMute = () => {
    update((p) => ({ muted: !p.muted }));
    flashVol(2200);
  };
  const setShowBoost = useStableCallback((show, db) => update((p) => ({ boost: { ...p.boost, [show]: db } })));

  // --- Channel changes: static + channel number ---------------------------------
  const endSwitch = useStableCallback(() => {
    setSwitching(false);
    stopStatic();
    flashBug(3000);
    if (tv) flashInfo(5000);
  });

  useEffect(() => {
    if (!switching) return undefined;
    const s = switchRef.current;
    const elapsed = performance.now() - s.at;
    const ready = srcSeq > s.seq && (hasFrame || Boolean(loadProblem) || !src);
    // At least 0.7 s of snow so it reads as a channel change; never more than 8 s.
    const t = setTimeout(endSwitch, Math.max(0, (ready ? 700 : 8000) - elapsed));
    const hiss = setTimeout(stopStatic, Math.max(0, 2500 - elapsed));
    return () => {
      clearTimeout(t);
      clearTimeout(hiss);
    };
  }, [switching, srcSeq, hasFrame, loadProblem, src, endSwitch]);

  const changeChannel = (next) => {
    if (!next) return;
    queueRef.current = null;
    if (next.id === channel?.id) {
      flashBug(3500);
      if (tv) flashInfo(5000);
      return;
    }
    if (prefs.staticOnSwitch) {
      switchRef.current = { at: performance.now(), seq: srcSeqRef.current };
      setSwitching(true);
      videoRef.current?.pause();
      if (prefs.staticSound && !prefs.muted) startStatic(prefs.volume);
    } else if (tv) {
      flashInfo(5000);
    }
    hideTouch();
    flashBug(prefs.staticOnSwitch ? 8000 : 4000);
    setChannel(next);
  };

  const stepChannel = (dir) => {
    if (!channels.length) {
      flashInfo(4000);
      return;
    }
    const i = channels.findIndex((c) => c.id === channel?.id);
    const n = channels.length;
    const j = i === -1 ? (dir > 0 ? 0 : n - 1) : (i + dir + n) % n;
    changeChannel(channels[j]);
  };

  // --- Menu: open / close / tabs / focus -----------------------------------------
  const contentEl = () => document.querySelector("[data-menu-panel] [data-menu-content]");
  const focusContent = () => {
    const content = contentEl();
    if (content && focusFirst(content)) return;
    focusEl(document.querySelector('[data-menu-panel] [role="tab"][aria-selected="true"]'));
  };
  const restoreFocus = () => {
    const panel = document.querySelector("[data-menu-panel]");
    const last = lastFocusRef.current;
    if (panel && last?.isConnected && panel.contains(last) && getFocusables(panel).includes(last)) focusEl(last);
    else focusContent();
  };

  const openMenu = () => {
    setNavMode("menu");
    if (tv) setMenuOpen(true);
    hideInfo();
    hideTouch();
    afterRender(restoreFocus);
  };
  const closeMenu = () => {
    setNavMode("watch");
    setMenuOpen(false);
    if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur();
  };

  const switchTab = (id, focusTo = "content") => {
    setTab(id);
    update({ lastTab: id });
    afterRender(() =>
      focusTo === "tab" ? focusEl(document.querySelector(`[data-menu-panel] [data-tab="${id}"]`)) : focusContent()
    );
  };
  const cycleTab = (dir, focusTo) => {
    const i = TABS.findIndex((t) => t.id === tab);
    switchTab(TABS[(i + dir + TABS.length) % TABS.length].id, focusTo);
  };

  // Remember where focus was in the menu, and treat focusing it as "using the menu".
  useEffect(() => {
    const onFocusIn = (e) => {
      if (e.target?.closest?.("[data-menu-panel]")) {
        lastFocusRef.current = e.target;
        setNavMode("menu");
      }
    };
    const onPointer = () => document.documentElement.removeAttribute("data-nav-active");
    document.addEventListener("focusin", onFocusIn);
    window.addEventListener("pointerdown", onPointer, true);
    return () => {
      document.removeEventListener("focusin", onFocusIn);
      window.removeEventListener("pointerdown", onPointer, true);
    };
  }, []);

  // Leaving the channel editor puts focus back on that channel's row.
  const prevEditingRef = useRef(editing);
  useEffect(() => {
    const prev = prevEditingRef.current;
    prevEditingRef.current = editing;
    if (prev && !editing && navMode === "menu") {
      afterRender(() => {
        const key = prev === "new" ? "new-channel" : `ch:${prev.id}`;
        const el = document.querySelector(`[data-nav-key="${channel && prev === "new" ? `ch:${channel.id}` : key}"]`);
        if (el) focusEl(el);
        else focusContent();
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing]);

  // Same for leaving a show's page in Library.
  const openShow = useStableCallback((key) => {
    const prev = libShow;
    setLibShow(key);
    if (!key && prev) afterRender(() => focusEl(document.querySelector(`[data-nav-key="show:${CSS.escape(prev)}"]`)) || focusContent());
  });

  // --- Back (controller B, Escape, Android back) ----------------------------------
  const goBack = () => {
    // Some controllers send B both as a button and as Android "back": handle it once.
    if (Date.now() - lastBackRef.current < 400) return true;
    let handled = false;
    if (navMode === "menu") {
      if (!backStack.run()) closeMenu();
      handled = true;
    } else if (bugOn || volOn || infoOn || touchOn) {
      hideBug();
      hideVol();
      hideInfo();
      hideTouch();
      handled = true;
    }
    if (handled) lastBackRef.current = Date.now();
    return handled;
  };
  const goBackStable = useStableCallback(goBack);
  useEffect(() => {
    const onBack = (e) => {
      if (goBackStable()) e.preventDefault();
    };
    window.addEventListener("native-back", onBack);
    return () => window.removeEventListener("native-back", onBack);
  }, [goBackStable]);

  // --- Controller / keyboard -------------------------------------------------------
  const togglePlay = () => {
    const v = videoRef.current;
    if (!v?.src) return;
    if (v.paused) v.play().catch(() => {});
    else v.pause();
    flashInfo(3000);
  };
  const seek = (s) => {
    const v = videoRef.current;
    if (!v || channel || !isFinite(v.duration)) return;
    v.currentTime = Math.min(v.duration, Math.max(0, v.currentTime + s));
    flashInfo(2500);
  };

  const watchAction = (action, info) => {
    switch (action) {
      case "up":
      case "r1":
        stepChannel(1);
        return true;
      case "down":
      case "l1":
        stepChannel(-1);
        return true;
      case "left":
        changeVolume(-0.05);
        return true;
      case "right":
        changeVolume(0.05);
        return true;
      case "a":
        // A TV remote has no Start button, so its OK opens the menu. With a
        // controller connected, OK/Enter is the controller's A: play/pause.
        if (info?.source === "key" && !pad.connected) openMenu();
        else togglePlay();
        return true;
      case "play":
        togglePlay();
        return true;
      case "x":
        toggleMute();
        return true;
      case "y":
        // Toggle what's actually on screen (the volume bar hides the banner).
        if (infoOn && !volOn && !touchOn) hideInfo();
        else {
          hideVol();
          hideTouch();
          flashInfo(6000);
        }
        return true;
      case "l2":
        seek(-10);
        return true;
      case "r2":
        seek(10);
        return true;
      case "start":
      case "select":
        openMenu();
        return true;
      default:
        return false;
    }
  };

  const menuAction = (action, info) => {
    const scope = activeScope();
    const el = document.activeElement;
    const inScope = el && el !== document.body && scope.contains(el);
    const modal = scope.hasAttribute("data-nav-modal");
    switch (action) {
      case "up":
      case "down":
      case "left":
      case "right": {
        const horizontal = action === "left" || action === "right";
        const dir = action === "left" ? -1 : 1;
        if (horizontal && inScope && isTab(el)) {
          cycleTab(dir, "tab");
          return true;
        }
        if (horizontal && inScope && isAdjustable(el)) {
          adjust(el, dir);
          return true;
        }
        const moved = moveFocus(action, scope);
        // Coming up into the tab bar lands on the open tab, not whichever is nearest.
        if (moved && !modal && isTab(document.activeElement) && !isTab(el)) {
          focusEl(scope.querySelector('[role="tab"][aria-selected="true"]'));
        }
        return true;
      }
      case "a":
        if (info.source === "pad" || !inScope) {
          if (inScope) el.click();
          else focusFirst(scope);
        }
        return true;
      case "l1":
      case "r1":
        if (!modal) cycleTab(action === "r1" ? 1 : -1);
        return true;
      case "l2":
      case "r2":
        for (let i = 0; i < 6; i++) if (!moveFocus(action === "r2" ? "down" : "up", scope)) break;
        return true;
      case "start":
      case "select":
        if (!modal) closeMenu();
        return true;
      case "x":
        toggleMute();
        return true;
      case "play":
        togglePlay();
        return true;
      default:
        return false;
    }
  };

  const pad = useControls((action, info) => {
    if (info.source === "pad" || action !== "a") document.documentElement.setAttribute("data-nav-active", "");
    if (action === "b") return goBack();
    const inMenu = navMode === "menu" && (!tv || menuOpen);
    return inMenu ? menuAction(action, info) : watchAction(action, info);
  });

  // --- Library actions ----------------------------------------------------------
  const handleAdd = async (files) => {
    const playable = files.filter((f) => /^(video|audio)\//.test(f.type));
    if (!playable.length) return;
    const saved = new Array(playable.length);
    let next = 0;
    let done = 0;
    setImporting({ done: 0, total: playable.length });
    const worker = async () => {
      while (next < playable.length) {
        const i = next++;
        saved[i] = await addMedia(playable[i], parsePath(playable[i]));
        setImporting({ done: ++done, total: playable.length });
      }
    };
    await Promise.all(Array.from({ length: Math.min(4, playable.length) }, worker));
    setImporting(null);
    setLibrary(await listMedia());
    if (playable.length === 1) {
      setChannel(null);
      queueRef.current = null;
      playBlob(saved[0].blob, saved[0].name, saved[0].id, saved[0].type);
    }
  };

  // Link a folder in place: no copying, only file handles + durations are saved.
  const handleLink = async () => {
    let found;
    try {
      found = await pickLinkedFolder();
    } catch {
      return; // picker cancelled
    }
    if (!found.length) return;
    const records = new Array(found.length);
    let next = 0;
    let done = 0;
    setImporting({ done: 0, total: found.length });
    const worker = async () => {
      while (next < found.length) {
        const i = next++;
        try {
          records[i] = await describeHandle(found[i]);
        } catch {
          records[i] = null;
        }
        setImporting({ done: ++done, total: found.length });
      }
    };
    await Promise.all(Array.from({ length: Math.min(8, found.length) }, worker));
    await addLinkedMediaBatch(records.filter(Boolean));
    setImporting(null);
    setLibrary(await listMedia());
  };

  const handleRemoveMany = async (list) => {
    for (const m of list) await removeMedia(m.id);
    setLibrary(await listMedia());
    if (!channel && list.some((m) => m.id === activeId)) {
      queueRef.current = null;
      clearPicture();
    }
  };

  const playFile = (m, list) => {
    setChannel(null);
    const index = list ? list.indexOf(m) : -1;
    queueRef.current = index >= 0 ? { list, index } : null;
    playBlob(m, m.name, m.id, m.type);
    if (tv) closeMenu();
    else revealScreen();
  };

  const onAddFiles = useStableCallback(handleAdd);
  const onLinkFolder = useStableCallback(handleLink);
  const onRemoveMedia = useStableCallback((m) => handleRemoveMany([m]));
  const onRemoveMany = useStableCallback(handleRemoveMany);
  const onPlayMedia = useStableCallback((m, list) => playFile(m, list));
  const onPlayList = useStableCallback((list) => list.length && playFile(list[0], list));
  const onQuickPlay = useStableCallback((file) => {
    setChannel(null);
    queueRef.current = null;
    playBlob(file, file.name, null, file.type);
    if (tv) closeMenu();
  });
  const onPicture = useCallback((crt) => update({ crt }), [update]);

  // On a phone the list can be scrolled far below the screen: bring the picture back into view.
  const revealScreen = () => {
    const el = stageRef.current;
    if (!tv && el && el.getBoundingClientRect().bottom < 80) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  // --- Channel actions ----------------------------------------------------------
  const tuneTo = async (c) => {
    // Tapping a channel is a user gesture, so re-grant access to linked folders here.
    const linked = library.find((m) => m.handle);
    if (linked) await getPlayable(linked);
    changeChannel(c);
    if (tv) closeMenu();
    else revealScreen();
  };

  const handleSaveChannel = async (data) => {
    const saved = await saveChannel(data);
    const list = await listChannels();
    setChannels(list);
    const fresh = list.find((c) => c.id === saved.id) || saved;
    if (channel?.id === fresh.id) setChannel(fresh);
    else changeChannel(fresh);
    setEditing(null);
  };

  const handleDeleteChannel = async (c) => {
    await removeChannel(c.id);
    setChannels(await listChannels());
    setEditing(null);
    if (channel?.id === c.id) {
      setChannel(null);
      clearPicture();
    }
  };

  // --- Pointer on the picture ---------------------------------------------------
  const onStagePointer = () => {
    if (tv) {
      if (menuOpen) closeMenu();
      else flashTouch(4500);
    } else if (navMode === "menu") {
      closeMenu();
    }
  };

  // --- Render -------------------------------------------------------------------
  const showHints = tv || pad.connected;
  const playingShow = currentRec ? currentRec.show || LOOSE : null;
  const staticLevel = switching ? 1 : !src ? 0.45 : 0;

  let message = null;
  if (switching) message = loadProblem ? <ScreenMessage>{loadProblem}</ScreenMessage> : null;
  else if (!src)
    message = (
      <ScreenMessage>
        {channel ? "No episodes on this channel" : "No signal"}
        {!channel && (
          <span className="mt-1 block text-[0.6em] opacity-80">
            {!tv ? "Pick a channel or a show below" : pad.connected ? "Press Start for the menu" : "Press OK or tap for the menu"}
          </span>
        )}
      </ScreenMessage>
    );
  else if (!hasFrame) message = <ScreenMessage>{loadProblem || "Loading signal…"}</ScreenMessage>;
  else if (isAudio) message = <ScreenMessage>♪ {label}</ScreenMessage>;

  const tabContent = {
    channels: (
      <ChannelsTab
        channels={channels}
        media={library}
        shows={shows}
        activeId={channel?.id}
        editing={editing}
        onEdit={setEditing}
        onTune={tuneTo}
        onSave={handleSaveChannel}
        onDelete={handleDeleteChannel}
        onGoLibrary={() => switchTab("library")}
      />
    ),
    library: (
      <LibraryTab
        media={library}
        activeId={channel ? null : activeId}
        playingShow={channel ? null : playingShow}
        importing={importing}
        boost={prefs.boost}
        openShow={libShow}
        onOpenShow={openShow}
        onBoost={setShowBoost}
        onPlay={onPlayMedia}
        onPlayList={onPlayList}
        onRemove={onRemoveMedia}
        onRemoveMany={onRemoveMany}
        onAddFiles={onAddFiles}
        onLink={onLinkFolder}
        onQuickPlay={onQuickPlay}
      />
    ),
    picture: <PictureTab settings={prefs.crt} onChange={onPicture} />,
    sound: <SoundTab prefs={prefs} update={update} currentShow={currentShow} onBoost={setShowBoost} />,
  }[tab];

  const brand = (
    <div className="flex items-center gap-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-400/10 text-amber-400 ring-1 ring-amber-400/30">
        <Monitor size={18} />
      </div>
      <div>
        <h1 className="font-mono text-sm uppercase tracking-[0.25em] text-neutral-200">
          Cathode<span className="text-amber-400">·</span>Tube
        </h1>
        <p className="font-mono text-[10px] uppercase tracking-widest text-neutral-500">CRT media player</p>
      </div>
      {!online && (
        <span className="flex items-center gap-1 rounded-full bg-amber-400/10 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-amber-300">
          <WifiOff size={11} /> Offline
        </span>
      )}
    </div>
  );

  const touchBtn =
    "flex h-11 min-w-11 items-center justify-center gap-1.5 rounded-full bg-black/60 px-3 text-neutral-100 ring-1 ring-white/15 backdrop-blur active:bg-amber-400/30";

  return (
    <BackStackContext.Provider value={backStack}>
      <div className={tv ? "fixed inset-0 overflow-hidden bg-black text-neutral-100" : "min-h-screen bg-neutral-950 text-neutral-100"}>
        {!tv && (
          <div className="pointer-events-none fixed inset-0 opacity-60">
            <div className="absolute left-1/2 top-0 h-[40vh] w-[60vw] -translate-x-1/2 rounded-full bg-amber-500/10 blur-[120px]" />
          </div>
        )}

        <div className={tv ? "contents" : "relative mx-auto flex min-h-screen max-w-6xl flex-col gap-4 px-3 py-4 sm:px-6"}>
          {!tv && (
            <header className="flex items-center gap-3">
              {brand}
              <div className="ml-auto">
                <InstallButton />
              </div>
            </header>
          )}

          <div className={tv ? "contents" : "flex flex-1 flex-col gap-4 lg:grid lg:grid-cols-[minmax(0,1fr)_24rem] lg:items-start"}>
            <div className={tv ? "contents" : "flex flex-col gap-3 lg:sticky lg:top-4"}>
              <div
                ref={stageRef}
                onPointerDown={onStagePointer}
                className={
                  tv
                    ? "absolute inset-0 z-0 overflow-hidden bg-black"
                    : "relative overflow-hidden rounded-[24px] bg-black p-2 shadow-[0_0_0_1px_rgba(255,255,255,0.06),0_30px_80px_-20px_rgba(0,0,0,0.9)] sm:p-4"
                }
              >
                <div className={`relative w-full overflow-hidden bg-black ${tv ? "h-full" : "aspect-video rounded-[16px] ring-1 ring-white/5"}`}>
                  <CRTPlayer videoRef={videoRef} settings={prefs.crt} hasFrame={hasFrame} staticLevel={staticLevel} />
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/[0.06] via-transparent to-transparent" />
                  {message}
                  {bugOn && <ChannelBug channel={channel} compact={!tv} />}
                  {prefs.muted && !volOn && <MuteTag />}
                  {volOn && <VolumeBar volume={prefs.volume} muted={prefs.muted} />}
                  {infoOn && !touchOn && !volOn && (src || !channels.length) && (
                    <InfoBanner
                      channel={channel}
                      nowPlaying={channel ? nowPlaying : null}
                      label={channels.length || src ? label : "No channels yet. Press Start to open the menu and make one."}
                      boostDb={boostDb}
                      hints={pad.connected ? WATCH_HINTS : tv ? REMOTE_HINTS : null}
                    />
                  )}
                  {tv && touchOn && !menuOpen && (
                    <div className="absolute inset-x-0 bottom-0 z-30 flex items-center gap-2 bg-gradient-to-t from-black/85 to-transparent px-4 pb-4 pt-10" onPointerDown={(e) => e.stopPropagation()}>
                      <button className={touchBtn} onClick={openMenu} aria-label="Open menu">
                        <MenuIcon size={18} /> <span className="text-sm">Menu</span>
                      </button>
                      <button className={touchBtn} onClick={() => { stepChannel(-1); }} aria-label="Channel down">
                        <ChevronDown size={18} />
                      </button>
                      <button className={touchBtn} onClick={() => { stepChannel(1); }} aria-label="Channel up">
                        <ChevronUp size={18} />
                      </button>
                      <span className="min-w-0 flex-1 truncate px-2 text-sm text-neutral-200">
                        {channel && <span className="mr-2 font-['VT323',monospace] text-xl text-[#9dffab]">CH {pad2(channel.number)}</span>}
                        {label}
                      </span>
                      <button className={touchBtn} onClick={() => { changeVolume(-0.05); flashTouch(4500); }} aria-label="Volume down">
                        <Volume1 size={18} />
                      </button>
                      <button className={touchBtn} onClick={() => { changeVolume(0.05); flashTouch(4500); }} aria-label="Volume up">
                        <Volume2 size={18} />
                      </button>
                      <button className={touchBtn} onClick={() => { toggleMute(); flashTouch(4500); }} aria-label={prefs.muted ? "Unmute" : "Mute"}>
                        {prefs.muted ? <VolumeX size={18} /> : <Volume2 size={18} className="opacity-60" />}
                      </button>
                      <button className={touchBtn} onClick={() => { togglePlay(); flashTouch(4500); }} aria-label="Play or pause">
                        {videoRef.current && !videoRef.current.paused ? <Pause size={18} /> : <Play size={18} />}
                      </button>
                    </div>
                  )}
                  <video ref={videoRef} src={src || undefined} playsInline className="hidden" />
                </div>
              </div>

              {!tv && (
                <div className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-neutral-900/60 p-4 backdrop-blur">
                  <div className="flex min-w-0 items-center gap-3">
                    {channel && (
                      <span className="shrink-0 font-['VT323',ui-monospace,monospace] text-3xl leading-none text-[#9dffab]">CH {pad2(channel.number)}</span>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm text-neutral-100">{label}</p>
                      <p className="truncate font-mono text-[10px] uppercase tracking-wider text-neutral-500">
                        {channel ? channel.name : currentShow || "Now playing"}
                        {channel && nowPlaying?.current.kind === "ad" && " · Ad break"}
                        {channel && nowPlaying && ` · ${formatClock(nowPlaying.remaining)} left`}
                        {boostDb > 0 && ` · Boost +${boostDb} dB`}
                      </p>
                    </div>
                  </div>
                  <PlayerControls
                    videoRef={videoRef}
                    containerRef={stageRef}
                    disabled={!hasFrame}
                    live={Boolean(channel)}
                    volume={prefs.volume}
                    muted={prefs.muted}
                    onVolume={(v) => update({ volume: clamp01(v), muted: false })}
                    onToggleMute={() => update((p) => ({ muted: !p.muted }))}
                  />
                  {pad.connected && (
                    <p className="flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[10px] uppercase tracking-wider text-neutral-500">
                      {navMode === "menu" ? (
                        <>
                          <span className="text-amber-300">Controller: menu</span>
                          <span><Key>B</Key> / <Key>Start</Key> back to watching</span>
                        </>
                      ) : (
                        <>
                          <span className="text-amber-300">Controller: watching</span>
                          {WATCH_HINTS.map(([k, v]) => (
                            <span key={k}><Key>{k}</Key> {v}</span>
                          ))}
                        </>
                      )}
                    </p>
                  )}
                </div>
              )}
            </div>

            {(!tv || menuOpen) && (
              <MenuPanel
                variant={variant}
                tab={tab}
                onTab={(id) => switchTab(id, "tab")}
                onClose={closeMenu}
                showHints={showHints}
                controller={pad.connected}
              >
                {tabContent}
              </MenuPanel>
            )}
          </div>
        </div>
      </div>
    </BackStackContext.Provider>
  );
}
