import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { whatsOn } from "@/lib/schedule";

// Keeps the <video> in sync with a channel's real-time schedule.
// Tunes in at the live offset, and moves on to whatever is scheduled next when
// an item ends. Re-syncs if the player drifts from the wall clock.
// onEmpty runs when the channel has nothing playable, so the old picture doesn't linger.
export default function useChannelPlayback({ videoRef, channel, media, playBlob, onEmpty }) {
  const [nowPlaying, setNowPlaying] = useState(null);
  const itemRef = useRef(null);
  const pendingSeekRef = useRef(0);

  const tune = useCallback(() => {
    if (!channel) return;
    const on = whatsOn(channel, media);
    if (!on) {
      setNowPlaying(null);
      itemRef.current = null;
      onEmpty?.();
      return;
    }
    const { media: m } = on.current;
    pendingSeekRef.current = on.offset;
    itemRef.current = m.id;
    setNowPlaying(on);
    playBlob(m, m.name, m.id, m.type);
  }, [channel, media, playBlob, onEmpty]);

  // Tune when the channel or its lineup changes, or when the library's contents
  // change in a way that affects the schedule (not on every re-render).
  const libraryKey = useMemo(
    () => media.map((m) => `${m.id}:${m.show}:${m.season}:${m.duration}`).join("|"),
    [media]
  );
  useEffect(() => {
    if (!channel) setNowPlaying(null);
    tune();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channel?.id, channel?.blocks, channel?.lineup, channel?.shows, channel?.adShows, channel?.adsPerBreak, libraryKey]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v || !channel) return;

    const applySeek = () => {
      if (pendingSeekRef.current > 0 && isFinite(v.duration)) {
        v.currentTime = Math.min(pendingSeekRef.current, Math.max(0, v.duration - 0.25));
      }
      pendingSeekRef.current = 0;
    };
    const onEnded = () => tune();

    v.addEventListener("loadedmetadata", applySeek);
    v.addEventListener("ended", onEnded);

    // Drift check: if the schedule says something else is on, re-sync.
    const timer = setInterval(() => {
      const on = whatsOn(channel, media);
      if (!on) return;
      setNowPlaying(on);
      if (on.current.media.id !== itemRef.current) tune();
      // Only correct drift once the picture is actually playing. Correcting while the
      // file is still loading or seeking restarts the seek, and on slower storage that
      // loops forever (stuck on "Loading signal").
      else if (!v.paused && !v.seeking && v.readyState >= 3 && Math.abs(v.currentTime - on.offset) > 3) {
        v.currentTime = on.offset;
      }
    }, 2000);

    return () => {
      v.removeEventListener("loadedmetadata", applySeek);
      v.removeEventListener("ended", onEnded);
      clearInterval(timer);
    };
  }, [channel, media, tune, videoRef]);

  return nowPlaying;
}